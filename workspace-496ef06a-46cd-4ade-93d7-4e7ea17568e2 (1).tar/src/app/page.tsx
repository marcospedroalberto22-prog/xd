"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  Activity,
  BarChart3,
  BookOpen,
  Cable,
  Crosshair,
  CandlestickChart,
  LayoutDashboard,
  LineChart,
  Minus,
  MousePointer2,
  Pause,
  Play,
  Plus,
  Ruler,
  TrendingUp,
  Waves,
  Zap,
  ArrowDownLeft,
  ArrowUpRight,
  Target,
  RefreshCw,
  ChevronDown,
  Settings,
  Maximize2,
  Columns3,
  Columns4,
} from "lucide-react";
import { useTradingStore } from "@/lib/trading-store";
import { MARKETS, TIMEFRAMES } from "@/lib/trading-types";
import { formatPrice } from "@/lib/trading-utils";
import type { MarketKey, CandleType, ToolType } from "@/lib/trading-types";

import ChartPanel from "@/components/trading/ChartPanel";
import FootprintPanel from "@/components/trading/FootprintPanel";
import VolumeProfilePanel from "@/components/trading/VolumeProfilePanel";
import TpoPanel from "@/components/trading/TpoPanel";
import DomPanel from "@/components/trading/DomPanel";
import TapePanel from "@/components/trading/TapePanel";
import WatchlistPanel from "@/components/trading/WatchlistPanel";
import OrderEntryPanel from "@/components/trading/OrderEntryPanel";
import PositionsPanel from "@/components/trading/PositionsPanel";
import ConnectionsPanel from "@/components/trading/ConnectionsPanel";
import SignalsPanel from "@/components/trading/SignalsPanel";
import SessionStats from "@/components/trading/SessionStats";
import IndicatorPanel from "@/components/trading/IndicatorPanel";

// ─── Types ─────────────────────────────────────────────────────
type RightTab = "order" | "positions" | "connections" | "signals";

// ─── Main Trading Terminal ─────────────────────────────────────
export default function TradingTerminal() {
  const store = useTradingStore;
  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [showIndicatorPanel, setShowIndicatorPanel] = useState(false);

  // ── Store fields ──
  const market = useTradingStore((s) => s.market);
  const symbol = useTradingStore((s) => s.symbol);
  const timeframe = useTradingStore((s) => s.timeframe);
  const chartType = useTradingStore((s) => s.chartType);
  const tool = useTradingStore((s) => s.tool);
  const candles = useTradingStore((s) => s.candles);
  const isPlaying = useTradingStore((s) => s.isPlaying);
  const showFootprint = useTradingStore((s) => s.showFootprint);
  const showEma = useTradingStore((s) => s.showEma);
  const showBollinger = useTradingStore((s) => s.showBollinger);
  const showVwap = useTradingStore((s) => s.showVwap);
  const showVolumeBars = useTradingStore((s) => s.showVolumeBars);
  const showCVD = useTradingStore((s) => s.showCVD);
  const showHeatmap = useTradingStore((s) => s.showHeatmap);
  const showTpo = useTradingStore((s) => s.showTpo);
  const showRsi = useTradingStore((s) => s.showRsi);
  const showReplay = useTradingStore((s) => s.showReplay);
  const rightPanelTab = useTradingStore((s) => s.rightPanelTab);
  const bottomPanelTab = useTradingStore((s) => s.bottomPanelTab);

  const setMarket = useTradingStore((s) => s.setMarket);
  const setSymbol = useTradingStore((s) => s.setSymbol);
  const setTimeframe = useTradingStore((s) => s.setTimeframe);
  const setChartType = useTradingStore((s) => s.setChartType);
  const setTool = useTradingStore((s) => s.setTool);
  const toggleOverlay = useTradingStore((s) => s.toggleOverlay);
  const setIsPlaying = useTradingStore((s) => s.setIsPlaying);
  const clearDrawings = useTradingStore((s) => s.clearDrawings);
  const setRightPanelTab = useTradingStore((s) => s.setRightPanelTab);
  const setBottomPanelTab = useTradingStore((s) => s.setBottomPanelTab);
  const initData = useTradingStore((s) => s.initData);
  const tick = useTradingStore((s) => s.tick);

  // ── Initialize data on mount ──
  const initialized = useRef(false);
  useEffect(() => {
    if (!initialized.current) {
      initialized.current = true;
      initData();
    }
  }, [initData]);

  // ── Tick interval ──
  useEffect(() => {
    if (tickRef.current) clearInterval(tickRef.current);
    if (!isPlaying) return;

    const speed = showReplay ? useTradingStore.getState().replaySpeed : 1;
    tickRef.current = setInterval(() => {
      tick();
    }, Math.max(300, 1200 / speed));

    return () => {
      if (tickRef.current) clearInterval(tickRef.current);
    };
  }, [isPlaying, showReplay, tick]);

  // ── Connection auto-update ──
  useEffect(() => {
    const timer = setInterval(() => {
      const state = useTradingStore.getState();
      const updated = state.connections.map((c) => {
        if (c.status === "connected") {
          const drop = Math.random() < 0.015;
          if (drop) {
            return { ...c, status: "connecting" as const, reconnects: c.reconnects + 1 };
          }
          return {
            ...c,
            latency: Math.min(300, Math.max(8, c.latency + (Math.random() - 0.5) * 12)),
            throughput: Math.min(5000, Math.max(200, c.throughput + (Math.random() - 0.5) * 200)),
            lastHeartbeat: Date.now(),
          };
        }
        return c;
      });
      useTradingStore.setState({ connections: updated });
    }, 2000);
    return () => clearInterval(timer);
  }, []);

  // ── Connection auto-reconnect ──
  useEffect(() => {
    const timer = setInterval(() => {
      const state = useTradingStore.getState();
      const updated = state.connections.map((c) => {
        if (c.status === "connecting") {
          return {
            ...c,
            status: "connected" as const,
            latency: 20 + Math.random() * 40,
            throughput: 800 + Math.random() * 2000,
            lastHeartbeat: Date.now(),
          };
        }
        return c;
      });
      useTradingStore.setState({ connections: updated });
    }, 2500);
    return () => clearInterval(timer);
  }, []);

  // ── Computed values ──
  const lastCandle = candles[candles.length - 1];
  const currentPrice = lastCandle?.close ?? 0;
  const firstCandle = candles[0];
  const sessionChange = firstCandle && lastCandle
    ? ((lastCandle.close - firstCandle.open) / firstCandle.open) * 100
    : 0;

  const currentSymbols = MARKETS[market];

  // ─── Render ────────────────────────────────────────────────────
  return (
    <div className="terminal-root">
      {/* ═══ TOP BAR ═══ */}
      <header className="flex items-center justify-between gap-2 px-3 py-1.5 border-b border-[#1b2b3f] bg-[rgba(8,13,20,0.92)] backdrop-blur-sm">
        {/* Brand */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5">
            <Activity className="w-4 h-4 text-[#59a0ff]" />
            <span className="text-sm font-bold tracking-wide text-[#59a0ff]">FlowDesk</span>
            <span className="text-[10px] font-semibold text-[#f6b446] bg-[rgba(246,180,70,0.12)] px-1.5 py-0.5 rounded">PRO</span>
          </div>
        </div>

        {/* Market & Symbol */}
        <div className="flex items-center gap-1.5">
          {(["crypto", "futures"] as MarketKey[]).map((m) => (
            <button
              key={m}
              className={`tbtn ${market === m ? "tbtn-active" : ""}`}
              onClick={() => setMarket(m)}
            >
              {m.toUpperCase()}
            </button>
          ))}
          <div className="tsep" />
          <select
            className="tselect font-semibold text-[#dfeeff]"
            value={symbol}
            onChange={(e) => setSymbol(e.target.value)}
          >
            {currentSymbols.map((s) => (
              <option key={s.symbol} value={s.symbol}>
                {s.symbol}
              </option>
            ))}
          </select>
        </div>

        {/* Timeframes */}
        <div className="flex items-center gap-1">
          {TIMEFRAMES.map((tf) => (
            <button
              key={tf.label}
              className={`tbtn ${timeframe === tf.label ? "tbtn-active" : ""}`}
              onClick={() => setTimeframe(tf.label)}
            >
              {tf.label}
            </button>
          ))}
        </div>

        {/* Price */}
        <div className="flex items-center gap-3">
          <div className="flex items-baseline gap-2">
            <span className="mono text-base font-bold">
              {formatPrice(currentPrice)}
            </span>
            <span
              className={`mono text-xs font-semibold ${
                sessionChange >= 0 ? "price-up" : "price-down"
              }`}
            >
              {sessionChange >= 0 ? "+" : ""}
              {sessionChange.toFixed(2)}%
            </span>
          </div>
          <button
            className={`tbtn ${isPlaying ? "tbtn-active" : ""}`}
            onClick={() => setIsPlaying(!isPlaying)}
            title={isPlaying ? "Pause" : "Resume"}
          >
            {isPlaying ? (
              <Pause className="w-3 h-3" />
            ) : (
              <Play className="w-3 h-3" />
            )}
          </button>
        </div>
      </header>

      {/* ═══ TOOLBAR ═══ */}
      <div className="flex items-center justify-between gap-2 px-3 py-1 border-b border-[#1b2b3f] bg-[rgba(10,14,20,0.8)]">
        {/* Chart Type */}
        <div className="flex items-center gap-1">
          {([
            { id: "candle" as CandleType, label: "Candles", icon: <CandlestickChart className="w-3 h-3" /> },
            { id: "line" as CandleType, label: "Line", icon: <LineChart className="w-3 h-3" /> },
            { id: "delta" as CandleType, label: "Delta", icon: <Waves className="w-3 h-3" /> },
          ]).map((ct) => (
            <button
              key={ct.id}
              className={`tbtn flex items-center gap-1 ${chartType === ct.id ? "tbtn-active" : ""}`}
              onClick={() => setChartType(ct.id)}
            >
              {ct.icon}
              <span className="hidden sm:inline">{ct.label}</span>
            </button>
          ))}

          <div className="tsep" />

          {/* Drawing Tools */}
          {([
            { id: "crosshair" as ToolType, label: "Crosshair", icon: <Crosshair className="w-3 h-3" /> },
            { id: "trend" as ToolType, label: "Trend", icon: <TrendingUp className="w-3 h-3" /> },
            { id: "fib" as ToolType, label: "Fibonacci", icon: <Target className="w-3 h-3" /> },
            { id: "hline" as ToolType, label: "H-Line", icon: <Minus className="w-3 h-3" /> },
          ]).map((t) => (
            <button
              key={t.id}
              className={`tbtn flex items-center gap-1 ${tool === t.id ? "tbtn-active" : ""}`}
              onClick={() => setTool(t.id)}
            >
              {t.icon}
              <span className="hidden md:inline">{t.label}</span>
            </button>
          ))}

          <button className="tbtn" onClick={clearDrawings} title="Clear drawings">
            <RefreshCw className="w-3 h-3" />
          </button>
        </div>

        {/* Overlays */}
        <div className="flex items-center gap-1">
          {[
            { key: "showEma", label: "EMA" },
            { key: "showBollinger", label: "BB" },
            { key: "showVwap", label: "VWAP" },
            { key: "showSuperTrend", label: "ST" },
            { key: "showIchimoku", label: "ICH" },
            { key: "showVolumeBars", label: "Vol" },
            { key: "showCVD", label: "CVD" },
          ].map((ov) => {
            const state = useTradingStore.getState() as Record<string, boolean>;
            const active = state[ov.key] ?? false;
            return (
              <button
                key={ov.key}
                className={`tbtn text-[10px] ${active ? "tbtn-active" : ""}`}
                onClick={() => toggleOverlay(ov.key)}
              >
                {ov.label}
              </button>
            );
          })}

          {/* Indicator selector button */}
          <div className="relative">
            <button
              className={`tbtn text-[10px] flex items-center gap-1 ${showIndicatorPanel ? "tbtn-active" : ""}`}
              onClick={() => setShowIndicatorPanel(!showIndicatorPanel)}
            >
              <Settings className="w-3 h-3" />
              <span className="hidden lg:inline">Indicators</span>
              <span className="text-[8px] bg-[#59a0ff] text-white rounded-full w-4 h-4 flex items-center justify-center">
                {useTradingStore.getState().activeIndicators.size}
              </span>
            </button>
            {showIndicatorPanel && (
              <IndicatorPanel open={showIndicatorPanel} onClose={() => setShowIndicatorPanel(false)} />
            )}
          </div>
        </div>
      </div>

      {/* ═══ MAIN LAYOUT ═══ */}
      <div className="flex-1 flex gap-[3px] p-[3px] min-h-0">
        {/* ── LEFT SIDEBAR: Watchlist ── */}
        <aside className="w-[200px] flex-shrink-0 flex flex-col gap-[3px]">
          <WatchlistPanel />
        </aside>

        {/* ── CENTER: Chart + Subpanels ── */}
        <div className="flex-1 flex flex-col gap-[3px] min-w-0">
          {/* Main Chart */}
          <div className="flex-1 min-h-0">
            <ChartPanel />
          </div>

          {/* Subpanels: DOM + Tape */}
          <div className="h-[180px] flex-shrink-0 flex gap-[3px]">
            <div className="flex-1 min-w-0">
              <DomPanel />
            </div>
            <div className="flex-1 min-w-0">
              <TapePanel />
            </div>
          </div>
        </div>

        {/* ── RIGHT SIDEBAR ── */}
        <aside className="w-[260px] flex-shrink-0 flex flex-col gap-[3px]">
          {/* Session Stats */}
          <SessionStats />

          {/* Tabbed Panel */}
          <div className="flex-1 flex flex-col min-h-0 tpanel">
            {/* Tabs */}
            <div className="flex items-center border-b border-[#1b2b3f] bg-[rgba(14,23,35,0.7)] px-1">
              {([
                { id: "order" as RightTab, label: "Order", icon: <Target className="w-3 h-3" /> },
                { id: "positions" as RightTab, label: "Positions", icon: <BarChart3 className="w-3 h-3" /> },
                { id: "signals" as RightTab, label: "Signals", icon: <Zap className="w-3 h-3" /> },
                { id: "connections" as RightTab, label: "Data", icon: <Cable className="w-3 h-3" /> },
              ]).map((tab) => (
                <button
                  key={tab.id}
                  className={`ttab flex items-center gap-1 px-2 py-2 ${
                    rightPanelTab === tab.id ? "ttab-active" : ""
                  }`}
                  onClick={() => setRightPanelTab(tab.id)}
                >
                  {tab.icon}
                  <span className="text-[11px]">{tab.label}</span>
                </button>
              ))}
            </div>

            {/* Tab Content */}
            <div className="flex-1 overflow-y-auto tpanel-body">
              {rightPanelTab === "order" && <OrderEntryPanel />}
              {rightPanelTab === "positions" && <PositionsPanel />}
              {rightPanelTab === "signals" && <SignalsPanel />}
              {rightPanelTab === "connections" && <ConnectionsPanel />}
            </div>
          </div>
        </aside>
      </div>

      {/* ═══ BOTTOM PANEL ═══ */}
      <div className="h-[200px] flex-shrink-0 flex flex-col border-t border-[#1b2b3f]">
        {/* Tabs */}
        <div className="flex items-center gap-0 px-2 bg-[rgba(10,14,20,0.8)] border-b border-[#1b2b3f]">
          {[
            { id: "footprint" as const, label: "Footprint" },
            { id: "volumeprofile" as const, label: "Volume Profile" },
            { id: "tpo" as const, label: "TPO / Market Profile" },
          ].map((tab) => (
            <button
              key={tab.id}
              className={`ttab px-3 py-1.5 ${bottomPanelTab === tab.id ? "ttab-active" : ""}`}
              onClick={() => setBottomPanelTab(tab.id)}
            >
              <span className="text-[11px]">{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="flex-1 min-h-0">
          {bottomPanelTab === "footprint" && <FootprintPanel />}
          {bottomPanelTab === "volumeprofile" && <VolumeProfilePanel />}
          {bottomPanelTab === "tpo" && <TpoPanel />}
        </div>
      </div>

      {/* ═══ FOOTER ═══ */}
      <footer className="flex items-center justify-between px-3 py-1 border-t border-[#1b2b3f] bg-[rgba(8,13,20,0.92)] text-[10px] text-[#7489a1]">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1">
            <span className="status-dot status-dot-connected" />
            <span>Market Data</span>
          </span>
          <span className="mono">{new Date().toLocaleString()}</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="mono">
            {currentSymbols.find((s) => s.symbol === symbol)?.description ?? symbol}
          </span>
          <span className="mono">|</span>
          <span>FlowDesk Pro v2.0</span>
        </div>
      </footer>
    </div>
  );
}
