"use client";

import { useMemo } from "react";
import { useTradingStore } from "@/lib/trading-store";
import { computeVolumeProfile } from "@/lib/trading-utils";
import { formatPrice, formatQty } from "@/lib/trading-utils";
import { BarChart3 } from "lucide-react";

export default function VolumeProfilePanel() {
  const candles = useTradingStore((s) => s.candles);
  const showReplay = useTradingStore((s) => s.showReplay);
  const replayCursor = useTradingStore((s) => s.replayCursor);

  const visibleCandles = useMemo(() => {
    if (candles.length === 0) return [];
    if (showReplay) {
      const idx = Math.min(replayCursor, candles.length - 1);
      return candles.slice(Math.max(0, idx - 100), idx + 1);
    }
    return candles;
  }, [candles, showReplay, replayCursor]);

  const rows = useMemo(() => {
    return computeVolumeProfile(visibleCandles);
  }, [visibleCandles]);

  const maxVolume = useMemo(
    () => Math.max(...rows.map((r) => r.volume), 1),
    [rows]
  );

  const pocRow = useMemo(() => rows.find((r) => r.poc), [rows]);
  const vahRow = useMemo(() => rows.find((r) => r.vah), [rows]);
  const valRow = useMemo(() => rows.find((r) => r.val), [rows]);
  const totalVolume = useMemo(
    () => rows.reduce((a, r) => a + r.volume, 0),
    [rows]
  );

  if (rows.length === 0) {
    return (
      <div className="tpanel h-full">
        <div className="tpanel-header">
          <span>VOLUME PROFILE</span>
        </div>
        <div className="tpanel-body flex items-center justify-center h-32 text-[#7489a1] text-xs">
          No data
        </div>
      </div>
    );
  }

  return (
    <div className="tpanel h-full flex flex-col">
      <div className="tpanel-header">
        <div className="flex items-center gap-2">
          <BarChart3 size={12} className="text-[#59a0ff]" />
          <span>VOLUME PROFILE</span>
        </div>
        <div className="flex items-center gap-3 text-[10px]">
          {pocRow && (
            <span className="text-[#59a0ff]">POC {formatPrice(pocRow.price)}</span>
          )}
          <span className="text-[#7489a1]">Vol {formatQty(totalVolume)}</span>
        </div>
      </div>

      <div className="tpanel-body flex-1 p-0 relative">
        {/* Column headers */}
        <div className="flex items-center px-2 py-1 text-[9px] uppercase tracking-wider text-[#7489a1] border-b border-[#1b2b3f]/50">
          <div className="w-[72px] text-right pr-2">Price</div>
          <div className="w-[36px] text-center">Vol</div>
          <div className="flex-1 text-right pr-2">Profile</div>
          <div className="w-[28px] text-center">Tag</div>
        </div>

        {rows.map((row, i) => {
          const barWidth = (row.volume / maxVolume) * 100;
          const buyWidth = row.volume > 0 ? (row.buyVol / row.volume) * barWidth : 0;
          const sellWidth = barWidth - buyWidth;

          const isPoc = row.poc;
          const isVah = row.vah;
          const isVal = row.val;

          return (
            <div
              key={i}
              className={`
                flex items-center px-2 text-[11px] mono border-b border-[#1b2b3f]/20
                ${isPoc ? "bg-[#59a0ff]/8" : ""}
                hover:bg-[#142031]/50 transition-colors
              `}
            >
              {/* Price label */}
              <div className={`w-[72px] text-right pr-2 font-medium ${isPoc ? "text-[#59a0ff]" : isVah ? "text-amber-400" : isVal ? "text-amber-400" : "text-[#d8e0ea]"}`}>
                {formatPrice(row.price)}
              </div>

              {/* Volume number */}
              <div className={`w-[36px] text-center text-[10px] ${isPoc ? "text-[#59a0ff] font-semibold" : "text-[#7489a1]"}`}>
                {formatQty(row.volume)}
              </div>

              {/* Horizontal bar */}
              <div className="flex-1 h-[14px] relative pr-2">
                {/* VA area highlight */}
                {(isVah || isVal) && (
                  <div
                    className="absolute top-0 bottom-0 right-0 left-0 border-t border-dashed"
                    style={{ borderColor: "rgba(245, 180, 70, 0.35)" }}
                  />
                )}

                {/* Buy volume (green part from left) */}
                {buyWidth > 0 && (
                  <div
                    className="absolute top-[2px] bottom-[2px] left-0 rounded-l-sm"
                    style={{
                      width: `${buyWidth}%`,
                      backgroundColor: isPoc
                        ? "rgba(89, 160, 255, 0.35)"
                        : "rgba(25, 195, 125, 0.25)",
                    }}
                  />
                )}

                {/* Sell volume (red part from right) */}
                {sellWidth > 0 && (
                  <div
                    className="absolute top-[2px] bottom-[2px] rounded-r-sm"
                    style={{
                      width: `${sellWidth}%`,
                      right: 0,
                      backgroundColor: isPoc
                        ? "rgba(89, 160, 255, 0.25)"
                        : "rgba(255, 95, 112, 0.25)",
                    }}
                  />
                )}

                {/* POC marker line */}
                {isPoc && (
                  <div
                    className="absolute top-0 bottom-0 left-0 right-0"
                    style={{
                      borderTop: "1px solid rgba(89, 160, 255, 0.6)",
                      borderBottom: "1px solid rgba(89, 160, 255, 0.6)",
                    }}
                  />
                )}
              </div>

              {/* Tag */}
              <div className="w-[28px] text-center text-[9px] font-semibold">
                {isPoc && <span className="text-[#59a0ff]">POC</span>}
                {isVah && <span className="text-amber-400">VAH</span>}
                {isVal && <span className="text-amber-400">VAL</span>}
              </div>
            </div>
          );
        })}

        {/* Legend */}
        <div className="flex items-center gap-4 px-2 py-2 text-[9px] text-[#7489a1] border-t border-[#1b2b3f]/50 mt-auto">
          <span className="flex items-center gap-1">
            <span className="inline-block w-2.5 h-2.5 rounded-sm bg-[#59a0ff]/40" />
            POC
          </span>
          <span className="flex items-center gap-1">
            <span className="inline-block w-2.5 h-1 border-t border-dashed border-amber-500/60" />
            VAH/VAL
          </span>
          <span className="flex items-center gap-1">
            <span className="inline-block w-2.5 h-2.5 rounded-sm bg-[#19c37d]/30" />
            Buy
          </span>
          <span className="flex items-center gap-1">
            <span className="inline-block w-2.5 h-2.5 rounded-sm bg-[#ff5f70]/30" />
            Sell
          </span>
        </div>
      </div>
    </div>
  );
}
