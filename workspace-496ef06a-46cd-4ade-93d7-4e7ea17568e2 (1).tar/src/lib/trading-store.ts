"use client";

import { create } from "zustand";
import type {
  MarketKey,
  CandleType,
  OrderSide,
  OrderType,
  ToolType,
  Candle,
  DepthLevel,
  TapeTrade,
  Position,
  TrendLine,
  FibZone,
  HorizontalLine,
  DataConnection,
  ConnectionStatus,
} from "./trading-types";
import { MARKETS, TIMEFRAMES, CONNECTION_PRESETS } from "./trading-types";
import {
  seedCandles,
  createCandle,
  createDepth,
  createTape,
  clamp,
} from "./trading-utils";

interface TradingState {
  // Market Selection
  market: MarketKey;
  symbol: string;
  timeframe: string;
  chartType: CandleType;

  // Data
  candles: Candle[];
  depth: { bids: DepthLevel[]; asks: DepthLevel[] };
  tape: TapeTrade[];
  positions: Position[];

  // Overlay toggles (original)
  showFootprint: boolean;
  showHeatmap: boolean;
  showTpo: boolean;
  showEma: boolean;
  showRsi: boolean;
  showBollinger: boolean;
  showVwap: boolean;
  showVolumeBars: boolean;
  showCVD: boolean;

  // New indicator toggles
  showMacd: boolean;
  showStochastic: boolean;
  showSuperTrend: boolean;
  showIchimoku: boolean;
  showAlligator: boolean;
  showParabolicSar: boolean;
  showAtr: boolean;
  showKeltner: boolean;
  showDonchian: boolean;
  showSqueeze: boolean;
  showFairValueGap: boolean;
  showOrderBlock: boolean;
  showFractals: boolean;
  showVwma: boolean;
  showObv: boolean;
  showCmf: boolean;
  showCci: boolean;
  showMfi: boolean;
  showWilliamsR: boolean;
  showRoc: boolean;
  showAdx: boolean;
  showWavetrend: boolean;
  showQQE: boolean;
  showTDSequential: boolean;

  // Active indicators set (for external indicator panel)
  activeIndicators: Set<string>;

  // Replay
  showReplay: boolean;
  replayCursor: number;
  replaySpeed: number;
  isPlaying: boolean;

  // Drawing tools
  tool: ToolType;
  trendLines: TrendLine[];
  fibZones: FibZone[];
  hLines: HorizontalLine[];
  draftPoint: { index: number; price: number } | null;

  // Hover state
  hoverIndex: number | null;
  hoverX: number;
  hoverY: number;

  // Order entry
  orderSide: OrderSide;
  orderType: OrderType;
  orderQty: number;
  orderPrice: number;
  orderStop: number;
  orderTarget: number;

  // Connections
  connections: DataConnection[];

  // UI state
  showJournal: boolean;
  rightPanelTab: "order" | "positions" | "connections" | "signals" | "journal";
  bottomPanelTab: "footprint" | "volumeprofile" | "tpo" | "tape";

  // Actions
  setMarket: (m: MarketKey) => void;
  setSymbol: (s: string) => void;
  setTimeframe: (t: string) => void;
  setChartType: (t: CandleType) => void;
  toggleOverlay: (key: string) => void;
  setTool: (t: ToolType) => void;
  setHover: (index: number | null, x: number, y: number) => void;
  setOrderSide: (s: OrderSide) => void;
  setOrderType: (t: OrderType) => void;
  setOrderQty: (q: number) => void;
  setOrderPrice: (p: number) => void;
  setOrderStop: (p: number) => void;
  setOrderTarget: (p: number) => void;
  setReplay: (show: boolean) => void;
  setReplayCursor: (c: number) => void;
  setReplaySpeed: (s: number) => void;
  setIsPlaying: (p: boolean) => void;
  addTrendLine: (line: TrendLine) => void;
  addFibZone: (zone: FibZone) => void;
  addHLine: (line: HorizontalLine) => void;
  setDraftPoint: (p: { index: number; price: number } | null) => void;
  clearDrawings: () => void;
  placeOrder: () => void;
  closePosition: (id: number) => void;
  toggleConnection: (id: string) => void;
  setShowJournal: (show: boolean) => void;
  setRightPanelTab: (tab: TradingState["rightPanelTab"]) => void;
  setBottomPanelTab: (tab: TradingState["bottomPanelTab"]) => void;
  tick: () => void;
  initData: () => void;
}

export const useTradingStore = create<TradingState>((set, get) => {
  const currentSymbols = () => MARKETS[get().market];
  const currentTf = () => TIMEFRAMES.find((t) => t.label === get().timeframe) ?? TIMEFRAMES[2];

  return {
    market: "crypto",
    symbol: "BTCUSDT",
    timeframe: "1m",
    chartType: "candle",

    candles: [],
    depth: { bids: [], asks: [] },
    tape: [],
    positions: [],

    showFootprint: true,
    showHeatmap: false,
    showTpo: true,
    showEma: true,
    showRsi: true,
    showBollinger: false,
    showVwap: true,
    showVolumeBars: true,
    showCVD: true,

    showMacd: false,
    showStochastic: false,
    showSuperTrend: false,
    showIchimoku: false,
    showAlligator: false,
    showParabolicSar: false,
    showAtr: false,
    showKeltner: false,
    showDonchian: false,
    showSqueeze: false,
    showFairValueGap: false,
    showOrderBlock: false,
    showFractals: false,
    showVwma: false,
    showObv: false,
    showCmf: false,
    showCci: false,
    showMfi: false,
    showWilliamsR: false,
    showRoc: false,
    showAdx: false,
    showWavetrend: false,
    showQQE: false,
    showTDSequential: false,

    activeIndicators: new Set<string>([
      "showEma", "showRsi", "showVwap", "showVolumeBars", "showCVD", "showFootprint"
    ]),

    showReplay: false,
    replayCursor: 200,
    replaySpeed: 1,
    isPlaying: true,

    tool: "crosshair",
    trendLines: [],
    fibZones: [],
    hLines: [],
    draftPoint: null,

    hoverIndex: null,
    hoverX: 0,
    hoverY: 0,

    orderSide: "buy",
    orderType: "limit",
    orderQty: 1,
    orderPrice: 0,
    orderStop: 0,
    orderTarget: 0,

    connections: CONNECTION_PRESETS.map((row) => ({
      id: row.id,
      label: row.label,
      status: (row.id === "binance" ? "connected" : "disconnected") as ConnectionStatus,
      latency: row.id === "binance" ? 34 : 0,
      lastHeartbeat: Date.now(),
      reconnects: 0,
      throughput: row.id === "binance" ? 1250 : 0,
    })),

    showJournal: false,
    rightPanelTab: "order",
    bottomPanelTab: "footprint",

    setMarket: (m) => {
      const syms = MARKETS[m];
      set({ market: m, symbol: syms[0].symbol });
      // Re-init data
      const state = get();
      const tf = currentTf();
      const sel = MARKETS[m][0];
      const seeded = seedCandles(sel.basePrice, 300, tf.ms);
      const last = seeded[seeded.length - 1];
      set({
        candles: seeded,
        depth: createDepth(last.close),
        tape: createTape(last.close, 50),
        orderPrice: last.close,
        orderStop: last.close * 0.997,
        orderTarget: last.close * 1.004,
        positions: [],
        trendLines: [],
        fibZones: [],
        hLines: [],
        draftPoint: null,
        replayCursor: 200,
      });
    },

    setSymbol: (s) => {
      set({ symbol: s });
      const state = get();
      const tf = currentTf();
      const sel = MARKETS[state.market].find((r) => r.symbol === s) ?? MARKETS[state.market][0];
      const seeded = seedCandles(sel.basePrice, 300, tf.ms);
      const last = seeded[seeded.length - 1];
      set({
        candles: seeded,
        depth: createDepth(last.close),
        tape: createTape(last.close, 50),
        orderPrice: last.close,
        orderStop: last.close * 0.997,
        orderTarget: last.close * 1.004,
        positions: [],
        trendLines: [],
        fibZones: [],
        hLines: [],
        draftPoint: null,
        replayCursor: 200,
      });
    },

    setTimeframe: (t) => {
      set({ timeframe: t });
      const state = get();
      const tf = TIMEFRAMES.find((r) => r.label === t) ?? TIMEFRAMES[0];
      const sel = MARKETS[state.market].find((r) => r.symbol === state.symbol) ?? MARKETS[state.market][0];
      const seeded = seedCandles(sel.basePrice, 300, tf.ms);
      const last = seeded[seeded.length - 1];
      set({
        candles: seeded,
        depth: createDepth(last.close),
        tape: createTape(last.close, 50),
        replayCursor: 200,
      });
    },

    setChartType: (t) => set({ chartType: t }),

    toggleOverlay: (key) => {
      const state = get();
      const val = (state as Record<string, boolean>)[key];
      const newVal = !val;
      const newActive = new Set(state.activeIndicators);
      if (newVal) {
        newActive.add(key);
      } else {
        newActive.delete(key);
      }
      set({ [key]: newVal, activeIndicators: newActive } as Partial<TradingState>);
    },

    setTool: (t) => set({ tool: t }),
    setHover: (index, x, y) => set({ hoverIndex: index, hoverX: x, hoverY: y }),

    setOrderSide: (s) => set({ orderSide: s }),
    setOrderType: (t) => set({ orderType: t }),
    setOrderQty: (q) => set({ orderQty: q }),
    setOrderPrice: (p) => set({ orderPrice: p }),
    setOrderStop: (p) => set({ orderStop: p }),
    setOrderTarget: (p) => set({ orderTarget: p }),

    setReplay: (show) => set({ showReplay: show }),
    setReplayCursor: (c) => set({ replayCursor: c }),
    setReplaySpeed: (s) => set({ replaySpeed: s }),
    setIsPlaying: (p) => set({ isPlaying: p }),

    addTrendLine: (line) =>
      set((s) => ({ trendLines: [line, ...s.trendLines].slice(0, 20) })),
    addFibZone: (zone) =>
      set((s) => ({ fibZones: [zone, ...s.fibZones].slice(0, 10) })),
    addHLine: (line) =>
      set((s) => ({ hLines: [line, ...s.hLines].slice(0, 18) })),
    setDraftPoint: (p) => set({ draftPoint: p }),
    clearDrawings: () => set({ trendLines: [], fibZones: [], hLines: [], draftPoint: null }),

    placeOrder: () => {
      const state = get();
      if (state.candles.length === 0) return;
      const last = state.candles[state.candles.length - 1];
      const id = Date.now();
      const fill = state.orderType === "market" ? last.close : state.orderPrice;
      set({
        positions: [
          {
            id,
            symbol: state.symbol,
            side: state.orderSide,
            qty: state.orderQty,
            entry: fill,
            stop: state.orderStop,
            target: state.orderTarget,
            timestamp: Date.now(),
          },
          ...state.positions,
        ].slice(0, 12),
      });
    },

    closePosition: (id) =>
      set((s) => ({ positions: s.positions.filter((p) => p.id !== id) })),

    toggleConnection: (id) =>
      set((s) => ({
        connections: s.connections.map((row) => {
          if (row.id !== id) return row;
          if (row.status === "disconnected") return { ...row, status: "connecting" as ConnectionStatus };
          return { ...row, status: "disconnected" as ConnectionStatus, latency: 0, throughput: 0 };
        }),
      })),

    setShowJournal: (show) => set({ showJournal: show }),
    setRightPanelTab: (tab) => set({ rightPanelTab: tab }),
    setBottomPanelTab: (tab) => set({ bottomPanelTab: tab }),

    tick: () => {
      const state = get();
      const { showReplay, replayCursor, isPlaying, replaySpeed, candles } = state;
      if (candles.length === 0) return;

      const tf = currentTf();

      if (showReplay) {
        if (!isPlaying) return;
        set({
          replayCursor: clamp(replayCursor + 1, 30, candles.length),
        });
      } else {
        if (!isPlaying) return;
        set((s) => {
          const prev = s.candles;
          if (prev.length === 0) return s;
          const next = createCandle(prev[prev.length - 1], tf.ms);
          const newCandles = [...prev.slice(-299), next];
          const last = newCandles[newCandles.length - 1];
          return {
            candles: newCandles,
            depth: createDepth(last.close),
            tape: [...createTape(last.close, 2), ...s.tape].slice(0, 60),
          };
        });
      }
    },

    initData: () => {
      const state = get();
      const tf = currentTf();
      const sel = MARKETS[state.market].find((r) => r.symbol === state.symbol) ?? MARKETS[state.market][0];
      const seeded = seedCandles(sel.basePrice, 300, tf.ms);
      const last = seeded[seeded.length - 1];
      set({
        candles: seeded,
        depth: createDepth(last.close),
        tape: createTape(last.close, 50),
        orderPrice: last.close,
        orderStop: last.close * 0.997,
        orderTarget: last.close * 1.004,
      });
    },
  };
});
