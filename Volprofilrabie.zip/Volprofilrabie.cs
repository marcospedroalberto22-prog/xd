#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private Volprofilrabie[] cacheVolprofilrabie;

		
		public Volprofilrabie Volprofilrabie()
		{
			return Volprofilrabie(Input);
		}


		
		public Volprofilrabie Volprofilrabie(ISeries<double> input)
		{
			if (cacheVolprofilrabie != null)
				for (int idx = 0; idx < cacheVolprofilrabie.Length; idx++)
					if ( cacheVolprofilrabie[idx].EqualsInput(input))
						return cacheVolprofilrabie[idx];
			return CacheIndicator<Volprofilrabie>(new Volprofilrabie(), input, ref cacheVolprofilrabie);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.Volprofilrabie Volprofilrabie()
		{
			return indicator.Volprofilrabie(Input);
		}


		
		public Indicators.Volprofilrabie Volprofilrabie(ISeries<double> input )
		{
			return indicator.Volprofilrabie(input);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.Volprofilrabie Volprofilrabie()
		{
			return indicator.Volprofilrabie(Input);
		}


		
		public Indicators.Volprofilrabie Volprofilrabie(ISeries<double> input )
		{
			return indicator.Volprofilrabie(input);
		}

	}
}

#endregion
