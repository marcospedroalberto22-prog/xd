import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/journal - List all journal entries
export async function GET() {
  try {
    const entries = await db.journalEntry.findMany({
      orderBy: { createdAt: "desc" },
      take: 50,
    });
    return NextResponse.json(entries);
  } catch (error) {
    console.error("Error fetching journal entries:", error);
    return NextResponse.json({ error: "Failed to fetch entries" }, { status: 500 });
  }
}

// POST /api/journal - Create a new journal entry
export async function POST(request: Request) {
  try {
    const body = await request.json();

    const {
      symbol,
      side,
      entryPrice,
      exitPrice,
      stopLoss,
      takeProfit,
      quantity,
      pnl,
      strategy,
      notes,
      tags,
      emotion,
      marketCondition,
      rating,
    } = body;

    const entry = await db.journalEntry.create({
      data: {
        symbol: symbol || "",
        side: side || "buy",
        entryPrice: parseFloat(entryPrice) || 0,
        exitPrice: exitPrice ? parseFloat(exitPrice) : null,
        stopLoss: stopLoss ? parseFloat(stopLoss) : null,
        takeProfit: takeProfit ? parseFloat(takeProfit) : null,
        quantity: parseFloat(quantity) || 0,
        pnl: pnl !== undefined ? parseFloat(pnl) : null,
        strategy: strategy || null,
        notes: notes || null,
        tags: tags || null,
        emotion: emotion || null,
        marketCondition: marketCondition || null,
        rating: rating ? parseInt(rating) : null,
      },
    });

    return NextResponse.json(entry, { status: 201 });
  } catch (error) {
    console.error("Error creating journal entry:", error);
    return NextResponse.json({ error: "Failed to create entry" }, { status: 500 });
  }
}

// DELETE /api/journal?id=xxx - Delete a journal entry
export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "Missing id parameter" }, { status: 400 });
    }

    await db.journalEntry.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting journal entry:", error);
    return NextResponse.json({ error: "Failed to delete entry" }, { status: 500 });
  }
}
