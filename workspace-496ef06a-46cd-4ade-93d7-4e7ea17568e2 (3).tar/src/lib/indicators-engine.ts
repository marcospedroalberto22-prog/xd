// ==================== Indicators Computation Engine ====================
// Pure computation module — "use client" compatible, no React hooks.
// 30 indicators ported from C# trading terminal logic.
"use client";

import type { Candle } from "./trading-types";
import { computeEma, computeRsi, computeBollinger } from "./trading-utils";

// =====================================================================
// Internal Helper Functions
// =====================================================================

/** Simple Moving Average over a numeric array. Returns 0 for indices before period-1. */
function sma(values: number[], period: number): number[] {
  const len = values.length;
  const result: number[] = new Array(len).fill(0);
  if (len < period) return result;
  let windowSum = 0;
  for (let i = 0; i < period; i++) windowSum += values[i];
  result[period - 1] = windowSum / period;
  for (let i = period; i < len; i++) {
    windowSum += values[i] - values[i - period];
    result[i] = windowSum / period;
  }
  return result;
}

/** Smoothed Moving Average (SMMA). First value is SMA, then Wilder-style smoothing. */
function smma(values: number[], period: number): number[] {
  const len = values.length;
  const result: number[] = new Array(len).fill(0);
  if (len < period) return result;
  let sum = 0;
  for (let i = 0; i < period; i++) sum += values[i];
  result[period - 1] = sum / period;
  for (let i = period; i < len; i++) {
    result[i] = (result[i - 1] * (period - 1) + values[i]) / period;
  }
  return result;
}

/** Running Moving Average (RMA) — Wilder's smoothing. Identical to SMMA. */
function rma(values: number[], period: number): number[] {
  return smma(values, period);
}

/** Rolling highest over a window of `period`. */
function highest(values: number[], period: number): number[] {
  const len = values.length;
  const result: number[] = new Array(len).fill(0);
  if (len < period) return result;
  let maxVal = -Infinity;
  // Use a simple loop for correctness and small periods
  for (let i = period - 1; i < len; i++) {
    maxVal = values[i];
    for (let j = i - period + 1; j < i; j++) {
      if (values[j] > maxVal) maxVal = values[j];
    }
    result[i] = maxVal;
  }
  return result;
}

/** Rolling lowest over a window of `period`. */
function lowest(values: number[], period: number): number[] {
  const len = values.length;
  const result: number[] = new Array(len).fill(0);
  if (len < period) return result;
  let minVal = Infinity;
  for (let i = period - 1; i < len; i++) {
    minVal = values[i];
    for (let j = i - period + 1; j < i; j++) {
      if (values[j] < minVal) minVal = values[j];
    }
    result[i] = minVal;
  }
  return result;
}

/** True Range for each candle. tr[0] = high[0] - low[0]. */
function trueRange(candles: Candle[]): number[] {
  const len = candles.length;
  const tr: number[] = new Array(len).fill(0);
  if (len === 0) return tr;
  tr[0] = candles[0].high - candles[0].low;
  for (let i = 1; i < len; i++) {
    const hl = candles[i].high - candles[i].low;
    const hc = Math.abs(candles[i].high - candles[i - 1].close);
    const lc = Math.abs(candles[i].low - candles[i - 1].close);
    tr[i] = Math.max(hl, hc, lc);
  }
  return tr;
}

/** Average True Range using Wilder's RMA smoothing. */
function atr(candles: Candle[], period: number): number[] {
  const tr = trueRange(candles);
  return rma(tr, period);
}

/** Least-squares linear regression value at the current (last) point. */
function linearRegValue(values: number[], period: number): number[] {
  const len = values.length;
  const result: number[] = new Array(len).fill(0);
  if (len < period) return result;
  const n = period;
  for (let i = period - 1; i < len; i++) {
    let sumX = 0;
    let sumY = 0;
    let sumXY = 0;
    let sumX2 = 0;
    for (let j = 0; j < n; j++) {
      const x = j;
      const y = values[i - n + 1 + j];
      sumX += x;
      sumY += y;
      sumXY += x * y;
      sumX2 += x * x;
    }
    const denom = n * sumX2 - sumX * sumX;
    if (denom === 0) {
      result[i] = sumY / n;
    } else {
      const slope = (n * sumXY - sumX * sumY) / denom;
      const intercept = (sumY - slope * sumX) / n;
      result[i] = slope * (n - 1) + intercept;
    }
  }
  return result;
}

// =====================================================================
// 1. ATR — Average True Range
// =====================================================================

export function computeATR(candles: Candle[], period = 10): number[] {
  if (candles.length === 0) return [];
  return atr(candles, period);
}

// =====================================================================
// 2. MACD — Moving Average Convergence Divergence
// =====================================================================

export function computeMACD(
  candles: Candle[],
  fast = 12,
  slow = 26,
  signal = 9
): { macd: number[]; signal: number[]; histogram: number[] } {
  const len = candles.length;
  const closes = candles.map((c) => c.close);
  const macdLine: number[] = new Array(len).fill(0);
  const signalLine: number[] = new Array(len).fill(0);
  const histogram: number[] = new Array(len).fill(0);

  if (len < slow) return { macd: macdLine, signal: signalLine, histogram };

  const emaFast = computeEma(closes, fast);
  const emaSlow = computeEma(closes, slow);

  // MACD line = EMA(fast) - EMA(slow)
  for (let i = 0; i < len; i++) {
    if (emaFast[i] !== null && emaSlow[i] !== null) {
      macdLine[i] = emaFast[i] - emaSlow[i];
    }
  }

  // Signal line = EMA of MACD line
  const emaSignal = computeEma(macdLine, signal);
  for (let i = 0; i < len; i++) {
    if (emaSignal[i] !== null) signalLine[i] = emaSignal[i];
  }

  // Histogram = MACD - Signal
  for (let i = 0; i < len; i++) {
    histogram[i] = macdLine[i] - signalLine[i];
  }

  return { macd: macdLine, signal: signalLine, histogram };
}

// =====================================================================
// 3. Stochastic Oscillator
// =====================================================================

export function computeStochastic(
  candles: Candle[],
  period = 14,
  smoothK = 3,
  smoothD = 3
): { k: number[]; d: number[] } {
  const len = candles.length;
  const k: number[] = new Array(len).fill(0);
  const d: number[] = new Array(len).fill(0);

  if (len < period) return { k, d };

  const highs = candles.map((c) => c.high);
  const lows = candles.map((c) => c.low);
  const closes = candles.map((c) => c.close);

  const hh = highest(highs, period);
  const ll = lowest(lows, period);

  // Raw %K
  const rawK: number[] = new Array(len).fill(0);
  for (let i = period - 1; i < len; i++) {
    const range = hh[i] - ll[i];
    rawK[i] = range > 0 ? ((closes[i] - ll[i]) / range) * 100 : 50;
  }

  // Smooth %K
  const smK = sma(rawK, smoothK);
  for (let i = 0; i < len; i++) k[i] = smK[i];

  // %D = SMA of smoothed %K
  const smD = sma(k, smoothD);
  for (let i = 0; i < len; i++) d[i] = smD[i];

  return { k, d };
}

// =====================================================================
// 4. CCI — Commodity Channel Index
// =====================================================================

export function computeCCI(candles: Candle[], period = 20): number[] {
  const len = candles.length;
  const result: number[] = new Array(len).fill(0);
  if (len < period) return result;

  const tp = candles.map((c) => (c.high + c.low + c.close) / 3);
  const tpSma = sma(tp, period);

  for (let i = period - 1; i < len; i++) {
    let meanDev = 0;
    for (let j = i - period + 1; j <= i; j++) {
      meanDev += Math.abs(tp[j] - tpSma[i]);
    }
    meanDev /= period;
    result[i] = meanDev > 0 ? (tp[i] - tpSma[i]) / (0.015 * meanDev) : 0;
  }

  return result;
}

// =====================================================================
// 5. SuperTrend
// =====================================================================

export function computeSuperTrend(
  candles: Candle[],
  period = 10,
  multiplier = 3
): { value: number[]; direction: ("up" | "down")[] } {
  const len = candles.length;
  const value: number[] = new Array(len).fill(0);
  const direction: ("up" | "down")[] = new Array(len).fill("down");

  if (len <= period) return { value, direction };

  const atrVals = atr(candles, period);
  const closes = candles.map((c) => c.close);

  let prevUpper = 0;
  let prevLower = 0;
  let prevDir = 1; // 1 = up, -1 = down

  for (let i = period - 1; i < len; i++) {
    const hl2 = (candles[i].high + candles[i].low) / 2;
    let upperBand = hl2 + multiplier * atrVals[i];
    let lowerBand = hl2 - multiplier * atrVals[i];

    if (i === period - 1) {
      prevUpper = upperBand;
      prevLower = lowerBand;
      prevDir = 1;
      value[i] = lowerBand;
      direction[i] = "up";
      continue;
    }

    // Determine direction
    let dir: number;
    if (closes[i - 1] > prevUpper) {
      dir = 1;
    } else if (closes[i - 1] < prevLower) {
      dir = -1;
    } else {
      dir = prevDir;
    }

    // Adjust bands
    if (dir === 1) {
      lowerBand = Math.max(lowerBand, prevLower);
    } else {
      upperBand = Math.min(upperBand, prevUpper);
    }

    value[i] = dir === 1 ? lowerBand : upperBand;
    direction[i] = dir === 1 ? "up" : "down";

    prevUpper = upperBand;
    prevLower = lowerBand;
    prevDir = dir;
  }

  return { value, direction };
}

// =====================================================================
// 6. Ichimoku Cloud
// =====================================================================

export function computeIchimoku(
  candles: Candle[],
  tenkan = 9,
  kijun = 26,
  senkou = 52
): {
  conversion: number[];
  base: number[];
  leadA: number[];
  leadB: number[];
  lagging: number[];
  cloudTop: number[];
  cloudBottom: number[];
} {
  const len = candles.length;
  const conversion: number[] = new Array(len).fill(0);
  const base: number[] = new Array(len).fill(0);
  const leadA: number[] = new Array(len).fill(0);
  const leadB: number[] = new Array(len).fill(0);
  const lagging: number[] = new Array(len).fill(0);
  const cloudTop: number[] = new Array(len).fill(0);
  const cloudBottom: number[] = new Array(len).fill(0);

  if (len === 0) return { conversion, base, leadA, leadB, lagging, cloudTop, cloudBottom };

  const highs = candles.map((c) => c.high);
  const lows = candles.map((c) => c.low);
  const closes = candles.map((c) => c.close);

  // Tenkan-sen (Conversion Line)
  const hhTenkan = highest(highs, tenkan);
  const llTenkan = lowest(lows, tenkan);
  for (let i = tenkan - 1; i < len; i++) {
    conversion[i] = (hhTenkan[i] + llTenkan[i]) / 2;
  }

  // Kijun-sen (Base Line)
  const hhKijun = highest(highs, kijun);
  const llKijun = lowest(lows, kijun);
  for (let i = kijun - 1; i < len; i++) {
    base[i] = (hhKijun[i] + llKijun[i]) / 2;
  }

  // Senkou Span A = (Tenkan + Kijun) / 2, plotted kijun periods ahead
  for (let i = 0; i < len; i++) {
    if (conversion[i] !== 0 || base[i] !== 0) {
      leadA[i] = (conversion[i] + base[i]) / 2;
    }
  }

  // Senkou Span B = (Highest High + Lowest Low) / 2 over senkou period, plotted kijun ahead
  const hhSenkou = highest(highs, senkou);
  const llSenkou = lowest(lows, senkou);
  for (let i = senkou - 1; i < len; i++) {
    leadB[i] = (hhSenkou[i] + llSenkou[i]) / 2;
  }

  // Chikou Span = close shifted kijun periods back
  for (let i = kijun; i < len; i++) {
    lagging[i] = closes[i - kijun];
  }

  // Cloud top / bottom at each position (using shifted spans)
  for (let i = kijun; i < len; i++) {
    const a = leadA[i - kijun];
    const b = leadB[i - kijun];
    cloudTop[i] = Math.max(a, b);
    cloudBottom[i] = Math.min(a, b);
  }

  return { conversion, base, leadA, leadB, lagging, cloudTop, cloudBottom };
}

// =====================================================================
// 7. Fair Value Gap (FVG)
// =====================================================================

export interface FairValueGapResult {
  type: "bullish" | "bearish";
  high: number;
  low: number;
  startIndex: number;
  endIndex: number;
  closed: boolean;
}

export function computeFairValueGap(candles: Candle[]): FairValueGapResult[] {
  if (candles.length < 3) return [];
  const results: FairValueGapResult[] = [];

  for (let i = 0; i < candles.length - 2; i++) {
    // Bullish FVG: candle[i].low > candle[i+2].high (gap between candle 0 low and candle 2 high)
    if (candles[i].low > candles[i + 2].high) {
      let closed = false;
      for (let j = i + 3; j < candles.length; j++) {
        if (candles[j].low <= candles[i + 2].high) {
          closed = true;
          break;
        }
      }
      results.push({
        type: "bullish",
        high: candles[i].low,
        low: candles[i + 2].high,
        startIndex: i,
        endIndex: i + 2,
        closed,
      });
    }

    // Bearish FVG: candle[i].high < candle[i+2].low
    if (candles[i].high < candles[i + 2].low) {
      let closed = false;
      for (let j = i + 3; j < candles.length; j++) {
        if (candles[j].high >= candles[i + 2].low) {
          closed = true;
          break;
        }
      }
      results.push({
        type: "bearish",
        high: candles[i + 2].low,
        low: candles[i].high,
        startIndex: i,
        endIndex: i + 2,
        closed,
      });
    }
  }

  return results;
}

// =====================================================================
// 8. Order Block
// =====================================================================

export interface OrderBlockResult {
  type: "bullish" | "bearish";
  top: number;
  bottom: number;
  index: number;
  active: boolean;
}

export function computeOrderBlock(
  candles: Candle[],
  period = 10
): OrderBlockResult[] {
  const results: OrderBlockResult[] = [];
  if (candles.length < period + 1) return results;

  for (let i = period; i < candles.length; i++) {
    // Bullish break of structure
    let highestHigh = -Infinity;
    for (let j = i - period; j < i; j++) {
      if (candles[j].high > highestHigh) highestHigh = candles[j].high;
    }

    if (candles[i].close > highestHigh) {
      // Find last bearish candle before break
      for (let j = i - 1; j >= i - period && j >= 0; j--) {
        if (candles[j].close < candles[j].open) {
          let active = true;
          for (let k = j + 1; k <= i; k++) {
            if (candles[k].low <= candles[j].low) {
              active = false;
              break;
            }
          }
          results.push({
            type: "bullish",
            top: candles[j].high,
            bottom: candles[j].low,
            index: j,
            active,
          });
          break;
        }
      }
    }

    // Bearish break of structure
    let lowestLow = Infinity;
    for (let j = i - period; j < i; j++) {
      if (candles[j].low < lowestLow) lowestLow = candles[j].low;
    }

    if (candles[i].close < lowestLow) {
      for (let j = i - 1; j >= i - period && j >= 0; j--) {
        if (candles[j].close > candles[j].open) {
          let active = true;
          for (let k = j + 1; k <= i; k++) {
            if (candles[k].high >= candles[j].high) {
              active = false;
              break;
            }
          }
          results.push({
            type: "bearish",
            top: candles[j].high,
            bottom: candles[j].low,
            index: j,
            active,
          });
          break;
        }
      }
    }
  }

  return results;
}

// =====================================================================
// 9. TD Sequential
// =====================================================================

export function computeTDSequential(
  candles: Candle[],
  setup = 4
): {
  buyCount: number[];
  sellCount: number[];
  buySetup: boolean[];
  sellSetup: boolean[];
} {
  const len = candles.length;
  const buyCount: number[] = new Array(len).fill(0);
  const sellCount: number[] = new Array(len).fill(0);
  const buySetup: boolean[] = new Array(len).fill(false);
  const sellSetup: boolean[] = new Array(len).fill(false);

  let bCount = 0;
  let sCount = 0;

  for (let i = setup; i < len; i++) {
    const closeI = candles[i].close;
    const closeLookback = candles[i - setup].close;

    if (closeI < closeLookback) {
      bCount++;
      sCount = 0;
    } else if (closeI > closeLookback) {
      sCount++;
      bCount = 0;
    } else {
      bCount = 0;
      sCount = 0;
    }

    buyCount[i] = bCount;
    sellCount[i] = sCount;

    if (bCount === 9) buySetup[i] = true;
    if (sCount === 9) sellSetup[i] = true;
  }

  return { buyCount, sellCount, buySetup, sellSetup };
}

// =====================================================================
// 10. Squeeze Momentum (TTM Squeeze)
// =====================================================================

export function computeSqueezeMomentum(
  candles: Candle[],
  bbPeriod = 20,
  bbMult = 2,
  kcPeriod = 20,
  kcMult = 1.5
): {
  momentum: number[];
  squeeze: ("on" | "off" | "none")[];
} {
  const len = candles.length;
  const momentum: number[] = new Array(len).fill(0);
  const squeeze: ("on" | "off" | "none")[] = new Array(len).fill("none");

  if (len < Math.max(bbPeriod, kcPeriod)) return { momentum, squeeze };

  const closes = candles.map((c) => c.close);
  const midline = sma(closes, bbPeriod);

  // Bollinger Bands
  const bb = computeBollinger(closes, bbPeriod, bbMult);

  // Keltner Channel — EMA-based middle, ATR-based bands
  const emaClose: Array<number | null> = computeEma(closes, kcPeriod);
  const atrVals = atr(candles, kcPeriod);

  for (let i = kcPeriod - 1; i < len; i++) {
    const emaVal = emaClose[i] ?? 0;
    const kcUpper = emaVal + kcMult * atrVals[i];
    const kcLower = emaVal - kcMult * atrVals[i];

    const bbUp = bb.upper[i];
    const bbLo = bb.lower[i];

    if (bbUp !== null && bbLo !== null) {
      // Squeeze is ON when BB is inside KC
      if (bbLo > kcLower && bbUp < kcUpper) {
        squeeze[i] = "on";
      } else {
        squeeze[i] = "off";
      }
    }

    // Momentum: normalized deviation from mean, smoothed with linear regression
    if (i >= bbPeriod - 1) {
      const diff = closes[i] - midline[i];
      momentum[i] = diff;
    }
  }

  // Smooth momentum with linear regression
  const smoothedMom = linearRegValue(momentum, bbPeriod);
  for (let i = 0; i < len; i++) momentum[i] = smoothedMom[i];

  return { momentum, squeeze };
}

// =====================================================================
// 11. QQE — Qualitative Quantitative Estimation
// =====================================================================

export function computeQQE(
  candles: Candle[],
  rsiPeriod = 14,
  sf = 5,
  factor = 4.236
): { long: number[]; short: number[] } {
  const len = candles.length;
  const long: number[] = new Array(len).fill(0);
  const short: number[] = new Array(len).fill(0);

  if (len < rsiPeriod + 1) return { long, short };

  const closes = candles.map((c) => c.close);
  const rsiArr: Array<number | null> = computeRsi(closes, rsiPeriod);

  // Absolute RSI changes (ATR of RSI)
  const absRsiDiff: number[] = new Array(len).fill(0);
  for (let i = 1; i < len; i++) {
    if (rsiArr[i] !== null && rsiArr[i - 1] !== null) {
      absRsiDiff[i] = Math.abs(rsiArr[i] - rsiArr[i - 1]);
    }
  }

  // Wilder smoothing of RSI ATR
  const atrRSI = rma(absRsiDiff, sf);

  let trendLong = 1; // 1 = up, -1 = down
  let prevLongVal = 0;
  let prevShortVal = 0;
  let longVal = 0;
  let shortVal = 0;

  for (let i = 0; i < len; i++) {
    if (rsiArr[i] === null) {
      long[i] = longVal;
      short[i] = shortVal;
      continue;
    }

    const rsi = rsiArr[i]!;
    const threshold = atrRSI[i] * factor;

    // Long line
    if (trendLong === 1) {
      const newLong = prevLongVal + threshold;
      if (rsi < newLong) {
        trendLong = -1;
        longVal = prevLongVal;
      } else {
        longVal = newLong;
        if (rsi > prevLongVal) {
          longVal = rsi;
        }
      }
    } else {
      const newLong = prevLongVal - threshold;
      if (rsi > newLong) {
        trendLong = 1;
        longVal = prevLongVal;
      } else {
        longVal = newLong;
        if (rsi < prevLongVal) {
          longVal = rsi;
        }
      }
    }

    // Short line (opposite trend tracking)
    if (trendLong === -1) {
      const newShort = prevShortVal - threshold;
      if (rsi > newShort) {
        shortVal = prevShortVal;
      } else {
        shortVal = newShort;
        if (rsi < prevShortVal) {
          shortVal = rsi;
        }
      }
    } else {
      const newShort = prevShortVal + threshold;
      if (rsi < newShort) {
        shortVal = prevShortVal;
      } else {
        shortVal = newShort;
        if (rsi > prevShortVal) {
          shortVal = rsi;
        }
      }
    }

    prevLongVal = longVal;
    prevShortVal = shortVal;
    long[i] = longVal;
    short[i] = shortVal;
  }

  return { long, short };
}

// =====================================================================
// 12. Alligator
// =====================================================================

export function computeAlligator(
  candles: Candle[],
  jaw = 13,
  jawShift = 8,
  teeth = 8,
  teethShift = 5,
  lips = 5,
  lipsShift = 3
): { jaw: number[]; teeth: number[]; lips: number[] } {
  const len = candles.length;
  const jawArr: number[] = new Array(len).fill(0);
  const teethArr: number[] = new Array(len).fill(0);
  const lipsArr: number[] = new Array(len).fill(0);

  if (len === 0) return { jaw: jawArr, teeth: teethArr, lips: lipsArr };

  const closes = candles.map((c) => c.close);
  const smmaJaw = smma(closes, jaw);
  const smmaTeeth = smma(closes, teeth);
  const smmaLips = smma(closes, lips);

  // Apply shifts: value at position i = SMMA at position (i - shift)
  for (let i = 0; i < len; i++) {
    jawArr[i] = i >= jawShift ? smmaJaw[i - jawShift] : 0;
    teethArr[i] = i >= teethShift ? smmaTeeth[i - teethShift] : 0;
    lipsArr[i] = i >= lipsShift ? smmaLips[i - lipsShift] : 0;
  }

  return { jaw: jawArr, teeth: teethArr, lips: lipsArr };
}

// =====================================================================
// 13. Fractals (Williams)
// =====================================================================

export function computeFractals(
  candles: Candle[],
  period = 2
): {
  up: (number | null)[];
  down: (number | null)[];
} {
  const len = candles.length;
  const up: (number | null)[] = new Array(len).fill(null);
  const down: (number | null)[] = new Array(len).fill(null);

  for (let i = period; i < len - period; i++) {
    // Up fractal: candle[i].high is the highest among period candles on each side
    let isUp = true;
    for (let j = i - period; j <= i + period; j++) {
      if (j !== i && candles[j].high >= candles[i].high) {
        isUp = false;
        break;
      }
    }
    if (isUp) up[i] = candles[i].high;

    // Down fractal: candle[i].low is the lowest among period candles on each side
    let isDown = true;
    for (let j = i - period; j <= i + period; j++) {
      if (j !== i && candles[j].low <= candles[i].low) {
        isDown = false;
        break;
      }
    }
    if (isDown) down[i] = candles[i].low;
  }

  return { up, down };
}

// =====================================================================
// 14. Keltner Channel
// =====================================================================

export function computeKeltnerChannel(
  candles: Candle[],
  period = 20,
  mult = 1.5
): { upper: number[]; middle: number[]; lower: number[] } {
  const len = candles.length;
  const upper: number[] = new Array(len).fill(0);
  const middle: number[] = new Array(len).fill(0);
  const lower: number[] = new Array(len).fill(0);

  if (len < period) return { upper, middle, lower };

  const closes = candles.map((c) => c.close);
  const emaVals: Array<number | null> = computeEma(closes, period);
  const atrVals = atr(candles, period);

  for (let i = 0; i < len; i++) {
    const emaVal = emaVals[i];
    if (emaVal !== null) {
      middle[i] = emaVal;
      upper[i] = emaVal + mult * atrVals[i];
      lower[i] = emaVal - mult * atrVals[i];
    }
  }

  return { upper, middle, lower };
}

// =====================================================================
// 15. Donchian Channel
// =====================================================================

export function computeDonchianChannel(
  candles: Candle[],
  period = 20
): { upper: number[]; middle: number[]; lower: number[] } {
  const len = candles.length;
  const upper: number[] = new Array(len).fill(0);
  const middle: number[] = new Array(len).fill(0);
  const lower: number[] = new Array(len).fill(0);

  if (len < period) return { upper, middle, lower };

  const highs = candles.map((c) => c.high);
  const lows = candles.map((c) => c.low);

  const hh = highest(highs, period);
  const ll = lowest(lows, period);

  for (let i = period - 1; i < len; i++) {
    upper[i] = hh[i];
    lower[i] = ll[i];
    middle[i] = (hh[i] + ll[i]) / 2;
  }

  return { upper, middle, lower };
}

// =====================================================================
// 16. Parabolic SAR
// =====================================================================

export function computeParabolicSAR(
  candles: Candle[],
  start = 0.02,
  step = 0.02,
  max = 0.2
): number[] {
  const len = candles.length;
  const sar: number[] = new Array(len).fill(0);
  if (len < 2) return sar;

  // Determine initial trend from first two candles
  let isUpTrend = candles[1].close > candles[0].close;

  // Initialize
  let af = start;
  let ep = isUpTrend ? candles[0].high : candles[0].low;
  sar[0] = isUpTrend ? candles[0].low : candles[0].high;

  for (let i = 1; i < len; i++) {
    // Calculate preliminary SAR
    sar[i] = sar[i - 1] + af * (ep - sar[i - 1]);

    if (isUpTrend) {
      // Ensure SAR is below prior two lows
      if (i >= 2) {
        sar[i] = Math.min(sar[i], candles[i - 1].low, candles[i - 2].low);
      } else {
        sar[i] = Math.min(sar[i], candles[i - 1].low);
      }

      // Check for reversal
      if (candles[i].low < sar[i]) {
        isUpTrend = false;
        sar[i] = ep; // flip to previous extreme
        ep = candles[i].low;
        af = start;
      } else {
        if (candles[i].high > ep) {
          ep = candles[i].high;
          af = Math.min(af + step, max);
        }
      }
    } else {
      // Ensure SAR is above prior two highs
      if (i >= 2) {
        sar[i] = Math.max(sar[i], candles[i - 1].high, candles[i - 2].high);
      } else {
        sar[i] = Math.max(sar[i], candles[i - 1].high);
      }

      // Check for reversal
      if (candles[i].high > sar[i]) {
        isUpTrend = true;
        sar[i] = ep;
        ep = candles[i].high;
        af = start;
      } else {
        if (candles[i].low < ep) {
          ep = candles[i].low;
          af = Math.min(af + step, max);
        }
      }
    }
  }

  return sar;
}

// =====================================================================
// 17. ADX — Average Directional Index
// =====================================================================

export function computeADX(
  candles: Candle[],
  period = 14
): { adx: number[]; plusDI: number[]; minusDI: number[] } {
  const len = candles.length;
  const adx: number[] = new Array(len).fill(0);
  const plusDI: number[] = new Array(len).fill(0);
  const minusDI: number[] = new Array(len).fill(0);

  if (len < period + 1) return { adx, plusDI, minusDI };

  // Calculate +DM, -DM, and TR
  const pDM: number[] = new Array(len).fill(0);
  const mDM: number[] = new Array(len).fill(0);
  const tr = trueRange(candles);

  for (let i = 1; i < len; i++) {
    const upMove = candles[i].high - candles[i - 1].high;
    const downMove = candles[i - 1].low - candles[i].low;

    if (upMove > downMove && upMove > 0) {
      pDM[i] = upMove;
    }
    if (downMove > upMove && downMove > 0) {
      mDM[i] = downMove;
    }
  }

  // Smooth with Wilder's RMA
  const smoothPDM = rma(pDM, period);
  const smoothMDM = rma(mDM, period);
  const smoothTR = rma(tr, period);

  // +DI and -DI
  for (let i = period - 1; i < len; i++) {
    const str = smoothTR[i];
    if (str > 0) {
      plusDI[i] = (smoothPDM[i] / str) * 100;
      minusDI[i] = (smoothMDM[i] / str) * 100;
    }
  }

  // DX and ADX
  const dx: number[] = new Array(len).fill(0);
  for (let i = period - 1; i < len; i++) {
    const diSum = plusDI[i] + minusDI[i];
    dx[i] = diSum > 0 ? (Math.abs(plusDI[i] - minusDI[i]) / diSum) * 100 : 0;
  }

  // ADX = RMA of DX
  const adxSmooth = rma(dx, period);
  for (let i = 0; i < len; i++) adx[i] = adxSmooth[i];

  return { adx, plusDI, minusDI };
}

// =====================================================================
// 18. MFI — Money Flow Index
// =====================================================================

export function computeMFI(candles: Candle[], period = 14): number[] {
  const len = candles.length;
  const result: number[] = new Array(len).fill(0);
  if (len < period + 1) return result;

  // Typical Price and Raw Money Flow
  const tp = candles.map((c) => (c.high + c.low + c.close) / 3);
  const rmf = candles.map((c, i) => tp[i] * c.volume);

  for (let i = period; i < len; i++) {
    let posFlow = 0;
    let negFlow = 0;

    for (let j = i - period + 1; j <= i; j++) {
      if (tp[j] > tp[j - 1]) {
        posFlow += rmf[j];
      } else if (tp[j] < tp[j - 1]) {
        negFlow += rmf[j];
      }
    }

    const ratio = negFlow > 0 ? posFlow / negFlow : posFlow > 0 ? 100 : 1;
    result[i] = 100 - 100 / (1 + ratio);
  }

  return result;
}

// =====================================================================
// 19. CMF — Chaikin Money Flow
// =====================================================================

export function computeCMF(candles: Candle[], period = 20): number[] {
  const len = candles.length;
  const result: number[] = new Array(len).fill(0);
  if (len < period) return result;

  for (let i = period - 1; i < len; i++) {
    let sumMFV = 0;
    let sumVol = 0;

    for (let j = i - period + 1; j <= i; j++) {
      const range = candles[j].high - candles[j].low;
      const mfm = range > 0 ? ((candles[j].close - candles[j].low) - (candles[j].high - candles[j].close)) / range : 0;
      sumMFV += mfm * candles[j].volume;
      sumVol += candles[j].volume;
    }

    result[i] = sumVol > 0 ? sumMFV / sumVol : 0;
  }

  return result;
}

// =====================================================================
// 20. OBV — On Balance Volume
// =====================================================================

export function computeOBV(candles: Candle[]): number[] {
  const len = candles.length;
  const result: number[] = new Array(len).fill(0);
  if (len === 0) return result;

  result[0] = 0;
  for (let i = 1; i < len; i++) {
    if (candles[i].close > candles[i - 1].close) {
      result[i] = result[i - 1] + candles[i].volume;
    } else if (candles[i].close < candles[i - 1].close) {
      result[i] = result[i - 1] - candles[i].volume;
    } else {
      result[i] = result[i - 1];
    }
  }

  return result;
}

// =====================================================================
// 21. Williams %R
// =====================================================================

export function computeWilliamsR(candles: Candle[], period = 14): number[] {
  const len = candles.length;
  const result: number[] = new Array(len).fill(-50);
  if (len < period) return result;

  const highs = candles.map((c) => c.high);
  const lows = candles.map((c) => c.low);
  const hh = highest(highs, period);
  const ll = lowest(lows, period);

  for (let i = period - 1; i < len; i++) {
    const range = hh[i] - ll[i];
    result[i] = range > 0 ? ((hh[i] - candles[i].close) / range) * -100 : -50;
  }

  return result;
}

// =====================================================================
// 22. ROC — Rate of Change
// =====================================================================

export function computeROC(candles: Candle[], period = 12): number[] {
  const len = candles.length;
  const result: number[] = new Array(len).fill(0);

  for (let i = period; i < len; i++) {
    const prevClose = candles[i - period].close;
    result[i] = prevClose > 0 ? ((candles[i].close - prevClose) / prevClose) * 100 : 0;
  }

  return result;
}

// =====================================================================
// 23. VWMA — Volume Weighted Moving Average
// =====================================================================

export function computeVWMA(candles: Candle[], period = 10): number[] {
  const len = candles.length;
  const result: number[] = new Array(len).fill(0);
  if (len < period) return result;

  const closes = candles.map((c) => c.close);

  // Use rolling sums for efficiency
  let sumCV = 0;
  let sumV = 0;
  for (let i = 0; i < period; i++) {
    sumCV += closes[i] * candles[i].volume;
    sumV += candles[i].volume;
  }
  result[period - 1] = sumV > 0 ? sumCV / sumV : 0;

  for (let i = period; i < len; i++) {
    sumCV += closes[i] * candles[i].volume - closes[i - period] * candles[i - period].volume;
    sumV += candles[i].volume - candles[i - period].volume;
    result[i] = sumV > 0 ? sumCV / sumV : 0;
  }

  return result;
}

// =====================================================================
// 24. Wavetrend
// =====================================================================

export function computeWavetrend(
  candles: Candle[],
  channelLen = 10,
  avgLen = 21,
  overBought = 60,
  overSold = -60
): {
  wt1: number[];
  wt2: number[];
  buySignal: boolean[];
  sellSignal: boolean[];
} {
  const len = candles.length;
  const wt1: number[] = new Array(len).fill(0);
  const wt2: number[] = new Array(len).fill(0);
  const buySignal: boolean[] = new Array(len).fill(false);
  const sellSignal: boolean[] = new Array(len).fill(false);

  if (len < channelLen) return { wt1, wt2, buySignal, sellSignal };

  // HLC3
  const hlc3 = candles.map((c) => (c.high + c.low + c.close) / 3);

  // ESA = EMA of HLC3
  const esa: Array<number | null> = computeEma(hlc3, channelLen);

  // D = EMA of |HLC3 - ESA|
  const absDiff: number[] = new Array(len).fill(0);
  for (let i = 0; i < len; i++) {
    if (esa[i] !== null) {
      absDiff[i] = Math.abs(hlc3[i] - esa[i]);
    }
  }
  const d: Array<number | null> = computeEma(absDiff, channelLen);

  // CI = (HLC3 - ESA) / (0.015 * D)
  const ci: number[] = new Array(len).fill(0);
  for (let i = 0; i < len; i++) {
    if (esa[i] !== null && d[i] !== null && d[i] > 0) {
      ci[i] = (hlc3[i] - esa[i]) / (0.015 * d[i]);
    }
  }

  // WT1 = EMA of CI
  const wt1Raw: Array<number | null> = computeEma(ci, avgLen);
  for (let i = 0; i < len; i++) {
    wt1[i] = wt1Raw[i] ?? 0;
  }

  // WT2 = SMA of WT1 over 4 periods
  const wt2Raw = sma(wt1, 4);
  for (let i = 0; i < len; i++) wt2[i] = wt2Raw[i];

  // Buy/Sell signals: cross above overSold / cross below overBought
  for (let i = 1; i < len; i++) {
    if (wt1[i - 1] <= overSold && wt1[i] > overSold) {
      buySignal[i] = true;
    }
    if (wt1[i - 1] >= overBought && wt1[i] < overBought) {
      sellSignal[i] = true;
    }
  }

  return { wt1, wt2, buySignal, sellSignal };
}

// =====================================================================
// 25. Bollinger Squeeze (BB / KC width ratio)
// =====================================================================

export function computeBollingerSqueeze(
  candles: Candle[],
  bbPeriod = 20,
  bbMult = 2,
  kcPeriod = 20,
  kcMult = 1.5
): { ratio: number[]; squeeze: boolean[] } {
  const len = candles.length;
  const ratio: number[] = new Array(len).fill(0);
  const squeeze: boolean[] = new Array(len).fill(false);

  if (len < Math.max(bbPeriod, kcPeriod)) return { ratio, squeeze };

  const closes = candles.map((c) => c.close);
  const bb = computeBollinger(closes, bbPeriod, bbMult);
  const emaClose: Array<number | null> = computeEma(closes, kcPeriod);
  const atrVals = atr(candles, kcPeriod);

  for (let i = Math.max(bbPeriod, kcPeriod) - 1; i < len; i++) {
    const bbUp = bb.upper[i];
    const bbLo = bb.lower[i];
    const bbMid = bb.middle[i];
    const emaVal = emaClose[i];

    if (bbUp !== null && bbLo !== null && bbMid !== null && emaVal !== null) {
      const bbWidth = bbUp - bbLo;
      const kcUpper = emaVal + kcMult * atrVals[i];
      const kcLower = emaVal - kcMult * atrVals[i];
      const kcWidth = kcUpper - kcLower;

      ratio[i] = kcWidth > 0 ? bbWidth / kcWidth : 0;
      squeeze[i] = ratio[i] < 1;
    }
  }

  return { ratio, squeeze };
}

// =====================================================================
// 26. Delta Strength
// =====================================================================

export function computeDeltaStrength(candles: Candle[]): {
  positive: (number | null)[];
  negative: (number | null)[];
} {
  const len = candles.length;
  const positive: (number | null)[] = new Array(len).fill(null);
  const negative: (number | null)[] = new Array(len).fill(null);

  let posSum = 0;
  let negSum = 0;

  for (let i = 0; i < len; i++) {
    const d = candles[i].delta;
    if (d > 0) {
      posSum += d;
      negSum = 0; // reset negative on positive delta
      positive[i] = posSum;
      negative[i] = null;
    } else if (d < 0) {
      negSum += d;
      posSum = 0; // reset positive on negative delta
      negative[i] = negSum;
      positive[i] = null;
    }
    // If delta is 0, both stay null (no update)
  }

  return { positive, negative };
}

// =====================================================================
// 27. Stacked Imbalance
// =====================================================================

export interface StackedImbalanceResult {
  price: number;
  type: "bullish" | "bearish";
  startIndex: number;
  length: number;
}

export function computeStackedImbalance(
  candles: Candle[],
  ratio = 300,
  range = 3
): StackedImbalanceResult[] {
  const results: StackedImbalanceResult[] = [];
  if (candles.length < range) return results;

  const threshold = ratio / 100; // e.g., 300 → 3.0

  for (let i = 0; i <= candles.length - range; i++) {
    const group = candles.slice(i, i + range);
    let bullishCount = 0;
    let bearishCount = 0;

    for (const c of group) {
      const totalVol = c.buyVolume + c.sellVolume;
      if (totalVol === 0) continue;
      const buyRatio = c.buyVolume / c.sellVolume;
      const sellRatio = c.sellVolume / c.buyVolume;

      if (buyRatio >= threshold) {
        bullishCount++;
      } else if (sellRatio >= threshold) {
        bearishCount++;
      }
    }

    if (bullishCount >= range) {
      // Find the common price zone
      const groupHigh = Math.max(...group.map((c) => c.high));
      const groupLow = Math.min(...group.map((c) => c.low));
      results.push({
        price: (groupHigh + groupLow) / 2,
        type: "bullish",
        startIndex: i,
        length: range,
      });
    } else if (bearishCount >= range) {
      const groupHigh = Math.max(...group.map((c) => c.high));
      const groupLow = Math.min(...group.map((c) => c.low));
      results.push({
        price: (groupHigh + groupLow) / 2,
        type: "bearish",
        startIndex: i,
        length: range,
      });
    }
  }

  return results;
}

// =====================================================================
// 28. Unfinished Auction
// =====================================================================

export interface UnfinishedAuctionResult {
  price: number;
  type: "bullish" | "bearish";
  index: number;
}

export function computeUnfinishedAuction(
  candles: Candle[],
  bidFilter = 20,
  askFilter = 20
): UnfinishedAuctionResult[] {
  const results: UnfinishedAuctionResult[] = [];

  for (let i = 1; i < candles.length; i++) {
    const c = candles[i];
    const body = Math.abs(c.close - c.open);
    const totalRange = c.high - c.low;

    if (totalRange === 0) continue;

    const lowerWick = Math.min(c.open, c.close) - c.low;
    const upperWick = c.high - Math.max(c.open, c.close);
    const deltaPct = c.volume > 0 ? (c.delta / c.volume) * 100 : 0;

    // Bullish unfinished auction: long lower wick + positive delta exceeds bid filter
    if (lowerWick > body && deltaPct > bidFilter) {
      results.push({
        price: c.low,
        type: "bullish",
        index: i,
      });
    }

    // Bearish unfinished auction: long upper wick + negative delta exceeds ask filter
    if (upperWick > body && deltaPct < -askFilter) {
      results.push({
        price: c.high,
        type: "bearish",
        index: i,
      });
    }
  }

  return results;
}

// =====================================================================
// 29. VZO — Volume Zone Oscillator
// =====================================================================

export function computeVZO(candles: Candle[], period = 14): number[] {
  const len = candles.length;
  const result: number[] = new Array(len).fill(0);
  if (len < 2) return result;

  const closes = candles.map((c) => c.close);

  // Positive volume when close goes up, negative when close goes down
  const posVol: number[] = new Array(len).fill(0);
  const negVol: number[] = new Array(len).fill(0);

  for (let i = 1; i < len; i++) {
    if (closes[i] > closes[i - 1]) {
      posVol[i] = candles[i].volume;
    } else if (closes[i] < closes[i - 1]) {
      negVol[i] = candles[i].volume;
    }
  }

  // Smooth with EMA
  const emaPos: Array<number | null> = computeEma(posVol, period);
  const emaNeg: Array<number | null> = computeEma(negVol, period);

  for (let i = 0; i < len; i++) {
    const p = emaPos[i] ?? 0;
    const n = emaNeg[i] ?? 0;
    const sum = p + n;
    result[i] = sum > 0 ? ((p - n) / sum) * 100 : 0;
  }

  return result;
}

// =====================================================================
// 30. SMA Indicator
// =====================================================================

export function computeSMAIndicator(
  candles: Candle[],
  period = 20
): number[] {
  if (candles.length === 0) return [];
  const closes = candles.map((c) => c.close);
  return sma(closes, period);
}

// =====================================================================
// Indicator Metadata
// =====================================================================

export interface IndicatorMeta {
  id: string;
  label: string;
  category: "Trend" | "Momentum" | "Volume" | "Volatility" | "Smart Money" | "Oscillator";
  description: string;
  defaultParams: Record<string, number>;
}

export const INDICATORS_LIST: IndicatorMeta[] = [
  {
    id: "atr",
    label: "ATR",
    category: "Volatility",
    description: "Average True Range measures market volatility by decomposing the entire range of a price.",
    defaultParams: { period: 10 },
  },
  {
    id: "macd",
    label: "MACD",
    category: "Momentum",
    description: "Moving Average Convergence Divergence shows the relationship between two moving averages.",
    defaultParams: { fast: 12, slow: 26, signal: 9 },
  },
  {
    id: "stochastic",
    label: "Stochastic",
    category: "Momentum",
    description: "Stochastic Oscillator compares a closing price to its price range over time.",
    defaultParams: { period: 14, smoothK: 3, smoothD: 3 },
  },
  {
    id: "cci",
    label: "CCI",
    category: "Momentum",
    description: "Commodity Channel Index identifies cyclical trends and measures deviation from average.",
    defaultParams: { period: 20 },
  },
  {
    id: "supertrend",
    label: "SuperTrend",
    category: "Trend",
    description: "SuperTrend uses ATR to identify trend direction and provide trailing stop levels.",
    defaultParams: { period: 10, multiplier: 3 },
  },
  {
    id: "ichimoku",
    label: "Ichimoku Cloud",
    category: "Trend",
    description: "Ichimoku Kinko Hyo provides support/resistance, trend, and momentum signals at a glance.",
    defaultParams: { tenkan: 9, kijun: 26, senkou: 52 },
  },
  {
    id: "fvg",
    label: "Fair Value Gap",
    category: "Smart Money",
    description: "Detects price gaps between three-candle patterns where buying/selling was incomplete.",
    defaultParams: {},
  },
  {
    id: "orderblock",
    label: "Order Block",
    category: "Smart Money",
    description: "Identifies institutional order blocks — the last opposing candle before a strong move.",
    defaultParams: { period: 10 },
  },
  {
    id: "tdsequential",
    label: "TD Sequential",
    category: "Smart Money",
    description: "Counts consecutive closes relative to a lookback to identify exhaustion and reversal points.",
    defaultParams: { setup: 4 },
  },
  {
    id: "squeezemomentum",
    label: "Squeeze Momentum",
    category: "Volatility",
    description: "TTM Squeeze identifies periods of low volatility (squeeze) followed by explosive moves.",
    defaultParams: { bbPeriod: 20, bbMult: 2, kcPeriod: 20, kcMult: 1.5 },
  },
  {
    id: "qqe",
    label: "QQE",
    category: "Oscillator",
    description: "Qualitative Quantitative Estimation smooths RSI with ATR-based threshold bands.",
    defaultParams: { rsiPeriod: 14, sf: 5, factor: 4.236 },
  },
  {
    id: "alligator",
    label: "Alligator",
    category: "Trend",
    description: "Williams Alligator uses three SMMA lines to identify trend formation and direction.",
    defaultParams: { jaw: 13, jawShift: 8, teeth: 8, teethShift: 5, lips: 5, lipsShift: 3 },
  },
  {
    id: "fractals",
    label: "Fractals",
    category: "Trend",
    description: "Williams Fractals identify local highs and lows by comparing to surrounding bars.",
    defaultParams: { period: 2 },
  },
  {
    id: "keltner",
    label: "Keltner Channel",
    category: "Volatility",
    description: "Keltner Channel uses EMA with ATR bands to identify trend and overextension.",
    defaultParams: { period: 20, mult: 1.5 },
  },
  {
    id: "donchian",
    label: "Donchian Channel",
    category: "Volatility",
    description: "Donchian Channel tracks the highest high and lowest low over a rolling period.",
    defaultParams: { period: 20 },
  },
  {
    id: "psar",
    label: "Parabolic SAR",
    category: "Trend",
    description: "Parabolic SAR trails price with an accelerating factor to identify potential reversals.",
    defaultParams: { start: 0.02, step: 0.02, max: 0.2 },
  },
  {
    id: "adx",
    label: "ADX",
    category: "Trend",
    description: "Average Directional Index measures trend strength regardless of direction.",
    defaultParams: { period: 14 },
  },
  {
    id: "mfi",
    label: "MFI",
    category: "Volume",
    description: "Money Flow Index combines price and volume to identify overbought/oversold conditions.",
    defaultParams: { period: 14 },
  },
  {
    id: "cmf",
    label: "CMF",
    category: "Volume",
    description: "Chaikin Money Flow measures accumulation/distribution over a period using volume-weighted price.",
    defaultParams: { period: 20 },
  },
  {
    id: "obv",
    label: "OBV",
    category: "Volume",
    description: "On Balance Volume adds volume on up days and subtracts on down days to show flow.",
    defaultParams: {},
  },
  {
    id: "williamsr",
    label: "Williams %R",
    category: "Momentum",
    description: "Williams Percent Range shows the current close relative to the highest high over a period.",
    defaultParams: { period: 14 },
  },
  {
    id: "roc",
    label: "ROC",
    category: "Momentum",
    description: "Rate of Change measures the percentage change in price between the current and past period.",
    defaultParams: { period: 12 },
  },
  {
    id: "vwma",
    label: "VWMA",
    category: "Volume",
    description: "Volume Weighted Moving Average weights the SMA by volume to emphasize high-activity periods.",
    defaultParams: { period: 10 },
  },
  {
    id: "wavetrend",
    label: "Wavetrend",
    category: "Oscillator",
    description: "Wavetrend oscillator identifies cycles and overbought/oversold using channel normalization.",
    defaultParams: { channelLen: 10, avgLen: 21, overBought: 60, overSold: -60 },
  },
  {
    id: "bollingersqueeze",
    label: "Bollinger Squeeze",
    category: "Volatility",
    description: "Bollinger Squeeze ratio detects when Bollinger Bands contract inside Keltner Channels.",
    defaultParams: { bbPeriod: 20, bbMult: 2, kcPeriod: 20, kcMult: 1.5 },
  },
  {
    id: "deltastrength",
    label: "Delta Strength",
    category: "Smart Money",
    description: "Delta Strength tracks cumulative buying/selling pressure based on order flow delta.",
    defaultParams: {},
  },
  {
    id: "stackedimbalance",
    label: "Stacked Imbalance",
    category: "Smart Money",
    description: "Detects zones of consecutive candles with strong directional volume imbalance.",
    defaultParams: { ratio: 300, range: 3 },
  },
  {
    id: "unfinishedauction",
    label: "Unfinished Auction",
    category: "Smart Money",
    description: "Identifies price levels where buying/selling was interrupted, indicating potential revisit zones.",
    defaultParams: { bidFilter: 20, askFilter: 20 },
  },
  {
    id: "vzo",
    label: "VZO",
    category: "Volume",
    description: "Volume Zone Oscillator shows the relationship between up-volume and down-volume using EMA.",
    defaultParams: { period: 14 },
  },
  {
    id: "sma",
    label: "SMA",
    category: "Trend",
    description: "Simple Moving Average smooths price data over a period to identify trend direction.",
    defaultParams: { period: 20 },
  },
];
