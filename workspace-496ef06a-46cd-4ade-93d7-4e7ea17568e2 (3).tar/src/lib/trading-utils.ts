// ==================== Trading Utility Functions ====================
import type { Candle, DepthLevel, TapeTrade, FootprintRow, VolumeProfileRow, TpoRow, OrderSide } from "./trading-types";

const clamp = (value: number, min: number, max: number): number =>
  Math.min(max, Math.max(min, value));

export const formatPrice = (value: number, decimals?: number): string => {
  if (decimals !== undefined) return value.toFixed(decimals);
  if (value >= 10000) return value.toFixed(2);
  if (value >= 100) return value.toFixed(2);
  if (value >= 1) return value.toFixed(2);
  if (value >= 0.01) return value.toFixed(4);
  return value.toFixed(5);
};

export const formatQty = (value: number): string => {
  const abs = Math.abs(value);
  if (abs >= 1_000_000) return `${(value / 1_000_000).toFixed(2)}M`;
  if (abs >= 1000) return `${(value / 1000).toFixed(1)}K`;
  if (abs >= 1) return value.toFixed(2);
  return value.toFixed(4);
};

export const formatTime = (value: number): string => {
  return new Date(value).toLocaleTimeString("en-US", {
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
};

export const formatDateTime = (value: number): string => {
  return new Date(value).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
  });
};

export const createCandle = (prev: Candle, stepMs: number): Candle => {
  const drift = prev.close * 0.00035;
  const trend = Math.sin(Date.now() / 50000) * drift * 0.5;
  const body = (Math.random() - 0.5) * drift * 2 + trend * 0.1;
  const close = Math.max(0.0001, prev.close + body);
  const high = Math.max(prev.close, close) + Math.random() * drift;
  const low = Math.max(0.0001, Math.min(prev.close, close) - Math.random() * drift);
  const volume = clamp(prev.volume * (0.85 + Math.random() * 0.4), 80, 24000);
  const buyPct = 0.35 + Math.random() * 0.3;
  const buyVolume = volume * buyPct;
  const sellVolume = volume * (1 - buyPct);
  const delta = buyVolume - sellVolume;

  return {
    time: prev.time + stepMs,
    open: prev.close,
    high,
    low,
    close,
    volume,
    delta,
    buyVolume,
    sellVolume,
  };
};

export const seedCandles = (basePrice: number, count: number, stepMs: number): Candle[] => {
  const start = Date.now() - count * stepMs;
  const first: Candle = {
    time: start,
    open: basePrice,
    high: basePrice * 1.0012,
    low: basePrice * 0.9988,
    close: basePrice,
    volume: 2200,
    delta: 140,
    buyVolume: 1170,
    sellVolume: 1030,
  };

  const list: Candle[] = [first];
  for (let i = 1; i < count; i += 1) {
    list.push(createCandle(list[i - 1], stepMs));
  }
  return list;
};

export const createDepth = (price: number): { bids: DepthLevel[]; asks: DepthLevel[] } => {
  const ticks = 14;
  const step = price * 0.00012;
  const bids: DepthLevel[] = [];
  const asks: DepthLevel[] = [];
  let bidTotal = 0;
  let askTotal = 0;

  for (let i = 0; i < ticks; i += 1) {
    const bidSize = 5 + Math.random() * 50;
    const askSize = 5 + Math.random() * 50;
    const bidOrders = Math.floor(bidSize / (1 + Math.random() * 3));
    const askOrders = Math.floor(askSize / (1 + Math.random() * 3));
    bidTotal += bidSize;
    askTotal += askSize;

    bids.push({ price: price - (i + 1) * step, size: bidSize, total: bidTotal, orders: bidOrders });
    asks.push({ price: price + (i + 1) * step, size: askSize, total: askTotal, orders: askOrders });
  }

  return { bids, asks };
};

export const createTape = (price: number, rows: number): TapeTrade[] => {
  const list: TapeTrade[] = [];
  const now = Date.now();
  for (let i = 0; i < rows; i += 1) {
    const side: OrderSide = Math.random() > 0.49 ? "buy" : "sell";
    const size = 0.08 + Math.random() * 12;
    list.push({
      time: now - i * (300 + Math.random() * 600),
      price: price + (Math.random() - 0.5) * price * 0.0003,
      size,
      side,
      isBlock: size > 8,
    });
  }
  return list;
};

export const computeFootprint = (candle: Candle): FootprintRow[] => {
  const levels = 18;
  const span = Math.max(candle.high - candle.low, candle.close * 0.001);
  const step = span / levels;
  const rows: FootprintRow[] = [];

  for (let i = 0; i < levels; i += 1) {
    const price = candle.low + i * step;
    const imbalanceFactor = 0.25 + Math.random() * 0.5;
    const askVol = (candle.volume / levels) * imbalanceFactor;
    const bidVol = (candle.volume / levels) * (1.25 - imbalanceFactor);
    const delta = askVol - bidVol;
    const maxSide = Math.max(askVol, bidVol, 0.001);
    const minSide = Math.max(Math.min(askVol, bidVol), 0.001);
    const ratio = maxSide / minSide;
    const isImbalance = ratio > 2.0;

    rows.push({
      price,
      bid: Math.round(bidVol * 10) / 10,
      ask: Math.round(askVol * 10) / 10,
      delta: Math.round(delta * 10) / 10,
      total: Math.round((askVol + bidVol) * 10) / 10,
      imbalance: isImbalance,
      imbalanceRatio: ratio,
    });
  }

  return rows.reverse();
};

export const computeVolumeProfile = (
  candles: Candle[]
): VolumeProfileRow[] => {
  if (candles.length < 5) return [];
  const allLows = candles.map((c) => c.low);
  const allHighs = candles.map((c) => c.high);
  const min = Math.min(...allLows);
  const max = Math.max(...allHighs);
  const bins = 32;
  const step = (max - min) / bins;
  const rows: VolumeProfileRow[] = [];

  for (let i = 0; i < bins; i += 1) {
    const price = min + i * step + step / 2;
    let volume = 0;
    let buyVol = 0;
    let sellVol = 0;
    for (const candle of candles) {
      if (candle.low <= price && candle.high >= price) {
        volume += candle.volume;
        buyVol += candle.buyVolume;
        sellVol += candle.sellVolume;
      }
    }
    rows.push({ price, volume, buyVol, sellVol, poc: false, vah: false, val: false });
  }

  // Mark POC (Point of Control)
  const maxVol = Math.max(...rows.map((r) => r.volume));
  const pocIdx = rows.findIndex((r) => r.volume === maxVol);
  if (pocIdx >= 0) rows[pocIdx].poc = true;

  // Mark VAH (Value Area High) and VAL (Value Area Low)
  const totalVol = rows.reduce((a, r) => a + r.volume, 0);
  const vaTarget = totalVol * 0.7;
  let vaVol = rows[pocIdx].volume;
  let up = pocIdx - 1;
  let down = pocIdx + 1;
  while (vaVol < vaTarget && (up >= 0 || down < rows.length)) {
    const upVol = up >= 0 ? rows[up].volume : 0;
    const downVol = down < rows.length ? rows[down].volume : 0;
    if (upVol >= downVol && up >= 0) {
      vaVol += upVol;
      up--;
    } else if (down < rows.length) {
      vaVol += downVol;
      down++;
    } else {
      break;
    }
  }
  if (up >= 0) rows[up + 1].vah = true;
  if (down < rows.length) rows[down - 1].val = true;

  return rows;
};

export const computeTpoRows = (candles: Candle[]): TpoRow[] => {
  if (candles.length === 0) return [];
  const allLows = candles.map((c) => c.low);
  const allHighs = candles.map((c) => c.high);
  const min = Math.min(...allLows);
  const max = Math.max(...allHighs);
  const levels = 22;
  const step = (max - min) / levels;

  return Array.from({ length: levels }).map((_, idx) => {
    const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".slice(0, 2 + Math.floor(Math.random() * 8));
    return {
      price: max - idx * step,
      letters,
      tpoCount: letters.length,
    };
  });
};

export const computeEma = (values: number[], period: number): Array<number | null> => {
  if (values.length === 0) return [];
  const result: Array<number | null> = new Array(values.length).fill(null);
  const multiplier = 2 / (period + 1);
  let ema = values[0];

  for (let i = 0; i < values.length; i += 1) {
    ema = i === 0 ? values[i] : values[i] * multiplier + ema * (1 - multiplier);
    if (i >= period - 1) {
      result[i] = ema;
    }
  }
  return result;
};

export const computeRsi = (values: number[], period: number): Array<number | null> => {
  if (values.length < period + 1) return new Array(values.length).fill(null);
  const out: Array<number | null> = new Array(values.length).fill(null);
  let gains = 0;
  let losses = 0;

  for (let i = 1; i <= period; i += 1) {
    const diff = values[i] - values[i - 1];
    gains += Math.max(diff, 0);
    losses += Math.max(-diff, 0);
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;
  const initialRs = avgLoss === 0 ? 100 : avgGain / avgLoss;
  out[period] = 100 - 100 / (1 + initialRs);

  for (let i = period + 1; i < values.length; i += 1) {
    const diff = values[i] - values[i - 1];
    const gain = Math.max(diff, 0);
    const loss = Math.max(-diff, 0);
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
    const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
    out[i] = 100 - 100 / (1 + rs);
  }

  return out;
};

export const computeBollinger = (
  values: number[],
  period: number,
  mult: number
): { upper: Array<number | null>; middle: Array<number | null>; lower: Array<number | null> } => {
  const upper: Array<number | null> = new Array(values.length).fill(null);
  const middle: Array<number | null> = new Array(values.length).fill(null);
  const lower: Array<number | null> = new Array(values.length).fill(null);

  for (let i = period - 1; i < values.length; i += 1) {
    const window = values.slice(i - period + 1, i + 1);
    const mean = window.reduce((acc, value) => acc + value, 0) / period;
    const variance = window.reduce((acc, value) => acc + (value - mean) ** 2, 0) / period;
    const std = Math.sqrt(variance);
    middle[i] = mean;
    upper[i] = mean + std * mult;
    lower[i] = mean - std * mult;
  }

  return { upper, middle, lower };
};

export const computeVwap = (candles: Candle[]): number => {
  let pv = 0;
  let vv = 0;
  for (const row of candles) {
    const typical = (row.high + row.low + row.close) / 3;
    pv += typical * row.volume;
    vv += row.volume;
  }
  return vv > 0 ? pv / vv : 0;
};

export const computeCumulativeDelta = (candles: Candle[]): number => {
  return candles.reduce((acc, row) => acc + row.delta, 0);
};

export { clamp };
