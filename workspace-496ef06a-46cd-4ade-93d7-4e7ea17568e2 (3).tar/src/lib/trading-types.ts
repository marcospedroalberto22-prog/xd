// ==================== Trading Types ====================

export type MarketKey = "crypto" | "futures";
export type CandleType = "candle" | "line" | "delta" | "heikinashi";
export type OrderSide = "buy" | "sell";
export type OrderType = "limit" | "market";
export type ToolType = "crosshair" | "trend" | "fib" | "hline" | "rect" | "text";
export type ConnectionStatus = "disconnected" | "connecting" | "connected";

export interface SymbolRow {
  symbol: string;
  basePrice: number;
  tickSize: number;
  description: string;
}

export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  delta: number;
  buyVolume: number;
  sellVolume: number;
}

export interface DepthLevel {
  price: number;
  size: number;
  total: number;
  orders: number;
}

export interface TapeTrade {
  time: number;
  price: number;
  size: number;
  side: OrderSide;
  isBlock: boolean;
}

export interface Position {
  id: number;
  symbol: string;
  side: OrderSide;
  qty: number;
  entry: number;
  stop: number;
  target: number;
  timestamp: number;
}

export interface DrawPoint {
  index: number;
  price: number;
}

export interface TrendLine {
  id: number;
  start: DrawPoint;
  end: DrawPoint;
  color: string;
  width: number;
}

export interface FibZone {
  id: number;
  start: DrawPoint;
  end: DrawPoint;
}

export interface HorizontalLine {
  id: number;
  price: number;
  color: string;
  label: string;
}

export interface DataConnection {
  id: string;
  label: string;
  status: ConnectionStatus;
  latency: number;
  lastHeartbeat: number;
  reconnects: number;
  throughput: number;
}

export interface FootprintRow {
  price: number;
  bid: number;
  ask: number;
  delta: number;
  total: number;
  imbalance: boolean;
  imbalanceRatio: number;
}

export interface VolumeProfileRow {
  price: number;
  volume: number;
  buyVol: number;
  sellVol: number;
  poc: boolean;
  vah: boolean;
  val: boolean;
}

export interface TpoRow {
  price: number;
  letters: string;
  tpoCount: number;
}

export interface ScreenerRow {
  symbol: string;
  momentum: number;
  deltaScore: number;
  volume: number;
  high: number;
  low: number;
  close: number;
  change: number;
}

export interface ImbalanceSignal {
  price: number;
  side: "ask" | "bid";
  ratio: number;
  type: "volume" | "delta";
}

export interface IcebergSignal {
  time: number;
  side: OrderSide;
  price: number;
  size: number;
}

export interface ChartViewRange {
  startIdx: number;
  endIdx: number;
}

export const MARKETS: Record<MarketKey, SymbolRow[]> = {
  crypto: [
    { symbol: "BTCUSDT", basePrice: 65200, tickSize: 0.01, description: "Bitcoin" },
    { symbol: "ETHUSDT", basePrice: 3440, tickSize: 0.01, description: "Ethereum" },
    { symbol: "SOLUSDT", basePrice: 164, tickSize: 0.01, description: "Solana" },
    { symbol: "BNBUSDT", basePrice: 602, tickSize: 0.01, description: "BNB" },
    { symbol: "XRPUSDT", basePrice: 0.59, tickSize: 0.0001, description: "XRP" },
    { symbol: "ADAUSDT", basePrice: 0.45, tickSize: 0.0001, description: "Cardano" },
    { symbol: "DOGEUSDT", basePrice: 0.12, tickSize: 0.00001, description: "Dogecoin" },
    { symbol: "AVAXUSDT", basePrice: 35.8, tickSize: 0.01, description: "Avalanche" },
  ],
  futures: [
    { symbol: "ES", basePrice: 5310, tickSize: 0.25, description: "S&P 500 E-mini" },
    { symbol: "NQ", basePrice: 18880, tickSize: 0.25, description: "Nasdaq 100" },
    { symbol: "CL", basePrice: 82.6, tickSize: 0.01, description: "Crude Oil" },
    { symbol: "GC", basePrice: 2342, tickSize: 0.1, description: "Gold" },
    { symbol: "ZN", basePrice: 111.25, tickSize: 0.03125, description: "10Y Treasury" },
    { symbol: "6E", basePrice: 1.0875, tickSize: 0.0001, description: "Euro FX" },
    { symbol: "YM", basePrice: 39200, tickSize: 1, description: "Dow E-mini" },
    { symbol: "RTY", basePrice: 2050, tickSize: 0.25, description: "Russell 2000" },
  ],
};

export const TIMEFRAMES: Array<{ label: string; ms: number; seconds: number }> = [
  { label: "10s", ms: 10_000, seconds: 10 },
  { label: "30s", ms: 30_000, seconds: 30 },
  { label: "1m", ms: 60_000, seconds: 60 },
  { label: "5m", ms: 300_000, seconds: 300 },
  { label: "15m", ms: 900_000, seconds: 900 },
  { label: "1H", ms: 3_600_000, seconds: 3600 },
];

export const CONNECTION_PRESETS: Array<{ id: string; label: string }> = [
  { id: "binance", label: "Binance Feed" },
  { id: "bybit", label: "Bybit Feed" },
  { id: "coinbase", label: "Coinbase Feed" },
  { id: "dxfeed", label: "DXFeed Futures" },
];
