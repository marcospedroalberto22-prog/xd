"use client";

import { useMemo, useState } from "react";
import { useTradingStore } from "@/lib/trading-store";
import { MARKETS } from "@/lib/trading-types";
import { formatPrice, formatQty, seedCandles } from "@/lib/trading-utils";
import type { MarketKey, ScreenerRow } from "@/lib/trading-types";

export default function WatchlistPanel() {
  const market = useTradingStore((s) => s.market);
  const symbol = useTradingStore((s) => s.symbol);
  const candles = useTradingStore((s) => s.candles);
  const setSymbol = useTradingStore((s) => s.setSymbol);
  const [activeTab, setActiveTab] = useState<"watchlist" | "screener">("watchlist");

  const currentPrice = useMemo(() => {
    if (candles.length === 0) return 0;
    return candles[candles.length - 1].close;
  }, [candles]);

  const changePct = useMemo(() => {
    if (candles.length < 2) return 0;
    const open = candles[0].open;
    if (open === 0) return 0;
    return ((currentPrice - open) / open) * 100;
  }, [candles, currentPrice]);

  const symbolRows = useMemo(() => {
    return MARKETS[market];
  }, [market]);

  const screenerData = useMemo<ScreenerRow[]>(() => {
    const tfMs = 60_000;
    return MARKETS[market].map((row) => {
      const seeded = seedCandles(row.basePrice, 50, tfMs);
      const last = seeded[seeded.length - 1];
      const first = seeded[0];
      const change = first.open > 0 ? ((last.close - first.open) / first.open) * 100 : 0;

      // Compute momentum as rate of change over last 10 candles
      const recent10 = seeded.slice(-10).map((c) => c.close);
      const momentum =
        recent10.length >= 2
          ? ((recent10[recent10.length - 1] - recent10[0]) / recent10[0]) * 100
          : 0;

      // Delta score: cumulative delta relative to total volume
      const cumDelta = seeded.reduce((acc, c) => acc + c.delta, 0);
      const totalVol = seeded.reduce((acc, c) => acc + c.volume, 0);
      const deltaScore = totalVol > 0 ? (cumDelta / totalVol) * 100 : 0;

      const vol = seeded.slice(-10).reduce((acc, c) => acc + c.volume, 0);

      return {
        symbol: row.symbol,
        momentum,
        deltaScore,
        volume: vol,
        high: Math.max(...seeded.slice(-10).map((c) => c.high)),
        low: Math.min(...seeded.slice(-10).map((c) => c.low)),
        close: last.close,
        change,
      };
    });
  }, [market]);

  return (
    <div className="tpanel h-full flex flex-col">
      {/* Header with tabs */}
      <div className="tpanel-header gap-2">
        <div className="flex items-center gap-3">
          <button
            className={`ttab ${activeTab === "watchlist" ? "ttab-active" : ""}`}
            onClick={() => setActiveTab("watchlist")}
          >
            Watchlist
          </button>
          <button
            className={`ttab ${activeTab === "screener" ? "ttab-active" : ""}`}
            onClick={() => setActiveTab("screener")}
          >
            Screener
          </button>
        </div>
        <span className="mono text-[10px]">{(MARKETS[market] as unknown as MarketKey)?.length ?? 8}</span>
      </div>

      <div className="tpanel-body flex-1 p-0">
        {activeTab === "watchlist" ? (
          <div className="flex flex-col">
            {/* Column headers */}
            <div className="flex items-center justify-between px-3 py-1.5 text-[10px] text-[#7489a1] uppercase tracking-wider border-b border-[#1b2b3f]">
              <span className="w-20">Symbol</span>
              <span className="flex-1 text-right">Price</span>
              <span className="w-16 text-right">Chg %</span>
            </div>
            {symbolRows.map((row) => {
              const isActive = row.symbol === symbol;
              return (
                <button
                  key={row.symbol}
                  onClick={() => setSymbol(row.symbol)}
                  className={`flex items-center justify-between px-3 py-2 text-xs transition-colors hover:bg-[#11273f] ${
                    isActive ? "bg-[#11273f] border-l-2 border-[#59a0ff]" : "border-l-2 border-transparent"
                  }`}
                >
                  <div className="flex flex-col items-start w-20">
                    <span className={`font-semibold text-[11px] ${isActive ? "text-[#dfeeff]" : "text-[#9eb3ca]"}`}>
                      {row.symbol}
                    </span>
                    <span className="text-[9px] text-[#4a6178]">{row.description}</span>
                  </div>
                  {isActive ? (
                    <span className="flex-1 text-right mono text-[11px] text-[#d8e0ea]">
                      {formatPrice(currentPrice)}
                    </span>
                  ) : (
                    <span className="flex-1 text-right mono text-[11px] text-[#7489a1]">
                      {formatPrice(row.basePrice)}
                    </span>
                  )}
                  {isActive ? (
                    <span
                      className={`w-16 text-right mono text-[11px] font-medium ${
                        changePct >= 0 ? "price-up" : "price-down"
                      }`}
                    >
                      {changePct >= 0 ? "+" : ""}
                      {changePct.toFixed(2)}%
                    </span>
                  ) : (
                    <span className="w-16 text-right mono text-[11px] text-[#4a6178]">--</span>
                  )}
                </button>
              );
            })}
          </div>
        ) : (
          <div className="flex flex-col">
            {/* Column headers */}
            <div className="flex items-center justify-between px-3 py-1.5 text-[10px] text-[#7489a1] uppercase tracking-wider border-b border-[#1b2b3f]">
              <span className="w-16">Symbol</span>
              <span className="flex-1 text-right">Volume</span>
              <span className="w-14 text-right">Delta</span>
              <span className="w-14 text-right">Mom%</span>
            </div>
            {screenerData
              .sort((a, b) => Math.abs(b.deltaScore) - Math.abs(a.deltaScore))
              .map((row) => {
                const isActive = row.symbol === symbol;
                return (
                  <button
                    key={row.symbol}
                    onClick={() => setSymbol(row.symbol)}
                    className={`flex items-center justify-between px-3 py-2 text-xs transition-colors hover:bg-[#11273f] ${
                      isActive ? "bg-[#11273f] border-l-2 border-[#59a0ff]" : "border-l-2 border-transparent"
                    }`}
                  >
                    <div className="flex flex-col items-start w-16">
                      <span className={`font-semibold text-[11px] ${isActive ? "text-[#dfeeff]" : "text-[#9eb3ca]"}`}>
                        {row.symbol}
                      </span>
                      <span className={`mono text-[9px] ${row.change >= 0 ? "price-up" : "price-down"}`}>
                        {row.change >= 0 ? "+" : ""}{row.change.toFixed(2)}%
                      </span>
                    </div>
                    <span className="flex-1 text-right mono text-[11px] text-[#7489a1]">
                      {formatQty(row.volume)}
                    </span>
                    <span
                      className={`w-14 text-right mono text-[11px] font-medium ${
                        row.deltaScore >= 0 ? "price-up" : "price-down"
                      }`}
                    >
                      {row.deltaScore >= 0 ? "+" : ""}{row.deltaScore.toFixed(1)}
                    </span>
                    <span
                      className={`w-14 text-right mono text-[11px] ${
                        row.momentum >= 0 ? "price-up" : "price-down"
                      }`}
                    >
                      {row.momentum >= 0 ? "+" : ""}{row.momentum.toFixed(2)}%
                    </span>
                  </button>
                );
              })}
          </div>
        )}
      </div>
    </div>
  );
}
