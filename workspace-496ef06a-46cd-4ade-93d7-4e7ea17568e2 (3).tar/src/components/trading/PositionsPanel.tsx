"use client";

import { useMemo } from "react";
import { useTradingStore } from "@/lib/trading-store";
import { formatPrice, formatQty } from "@/lib/trading-utils";
import { X, TrendingUp, TrendingDown } from "lucide-react";

export default function PositionsPanel() {
  const positions = useTradingStore((s) => s.positions);
  const candles = useTradingStore((s) => s.candles);
  const closePosition = useTradingStore((s) => s.closePosition);

  const currentPrice = useMemo(() => {
    if (candles.length === 0) return 0;
    return candles[candles.length - 1].close;
  }, [candles]);

  const enrichedPositions = useMemo(() => {
    return positions.map((pos) => {
      const pnl = pos.side === "buy"
        ? (currentPrice - pos.entry) * pos.qty
        : (pos.entry - currentPrice) * pos.qty;
      const pnlPct = pos.entry > 0 ? (pnl / (pos.entry * pos.qty)) * 100 : 0;
      return { ...pos, pnl, pnlPct };
    });
  }, [positions, currentPrice]);

  const totalPnl = useMemo(() => {
    return enrichedPositions.reduce((sum, p) => sum + p.pnl, 0);
  }, [enrichedPositions]);

  if (positions.length === 0) {
    return (
      <div className="tpanel h-full flex flex-col">
        <div className="tpanel-header">
          <span>Positions</span>
          <span className="mono text-[10px]">0 open</span>
        </div>
        <div className="tpanel-body flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="text-[#2a4060] text-3xl mb-2">
              <TrendingUp className="w-8 h-8 mx-auto opacity-30" />
            </div>
            <p className="text-[11px] text-[#4a6178]">No open positions</p>
            <p className="text-[10px] text-[#2a4060] mt-1">Place an order to get started</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="tpanel h-full flex flex-col">
      <div className="tpanel-header">
        <span>Positions</span>
        <span className="mono text-[10px]">{positions.length} open</span>
      </div>

      <div className="tpanel-body flex-1 p-0 flex flex-col">
        {/* Column headers */}
        <div className="flex items-center px-3 py-1.5 text-[10px] text-[#7489a1] uppercase tracking-wider border-b border-[#1b2b3f]">
          <span className="w-8">Side</span>
          <span className="w-16">Symbol</span>
          <span className="flex-1 text-right">Qty @ Entry</span>
          <span className="w-20 text-right">PnL</span>
          <span className="w-6" />
        </div>

        {/* Position rows */}
        <div className="flex-1 overflow-y-auto max-h-[60vh]">
          {enrichedPositions.map((pos) => {
            const isBuy = pos.side === "buy";
            const isProfit = pos.pnl >= 0;
            return (
              <div
                key={pos.id}
                className="flex items-center px-3 py-2.5 text-xs border-b border-[#1b2b3f50] hover:bg-[#11273f50] transition-colors"
              >
                {/* Side */}
                <div className="w-8">
                  {isBuy ? (
                    <span className="inline-flex items-center gap-0.5 text-[10px] font-bold text-[#19c37d]">
                      <TrendingUp className="w-3 h-3" />
                      B
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-0.5 text-[10px] font-bold text-[#ff5f70]">
                      <TrendingDown className="w-3 h-3" />
                      S
                    </span>
                  )}
                </div>

                {/* Symbol */}
                <span className="w-16 font-semibold text-[11px] text-[#d8e0ea]">{pos.symbol}</span>

                {/* Qty @ Entry */}
                <span className="flex-1 text-right mono text-[11px] text-[#7489a1]">
                  {formatQty(pos.qty)} @ {formatPrice(pos.entry)}
                </span>

                {/* PnL */}
                <div className="w-20 text-right">
                  <div className={`mono text-[11px] font-semibold ${isProfit ? "text-[#19c37d]" : "text-[#ff5f70]"}`}>
                    {isProfit ? "+" : ""}{formatPrice(pos.pnl)}
                  </div>
                  <div className={`mono text-[9px] ${isProfit ? "text-[#19c37d80]" : "text-[#ff5f7080]"}`}>
                    {pos.pnlPct >= 0 ? "+" : ""}{pos.pnlPct.toFixed(2)}%
                  </div>
                </div>

                {/* Close button */}
                <button
                  onClick={() => closePosition(pos.id)}
                  className="w-6 h-6 flex items-center justify-center rounded text-[#4a6178] hover:text-[#ff5f70] hover:bg-[rgba(255,95,112,0.1)] transition-all"
                  title="Close position"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Summary row */}
        <div className="flex items-center justify-between px-3 py-2.5 bg-[#0e1723] border-t border-[#1b2b3f]">
          <div className="flex items-center gap-3">
            <span className="text-[10px] text-[#7489a1] uppercase tracking-wider">
              Total ({positions.length})
            </span>
          </div>
          <div className="flex items-center gap-4">
            <span className={`mono text-sm font-bold ${totalPnl >= 0 ? "text-[#19c37d]" : "text-[#ff5f70]"}`}>
              {totalPnl >= 0 ? "+" : ""}{formatPrice(totalPnl)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
