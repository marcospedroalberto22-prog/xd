"use client";

import { useMemo } from "react";
import { useTradingStore } from "@/lib/trading-store";
import { formatPrice } from "@/lib/trading-utils";

export default function OrderEntryPanel() {
  const symbol = useTradingStore((s) => s.symbol);
  const candles = useTradingStore((s) => s.candles);
  const orderSide = useTradingStore((s) => s.orderSide);
  const orderType = useTradingStore((s) => s.orderType);
  const orderQty = useTradingStore((s) => s.orderQty);
  const orderPrice = useTradingStore((s) => s.orderPrice);
  const orderStop = useTradingStore((s) => s.orderStop);
  const orderTarget = useTradingStore((s) => s.orderTarget);
  const setOrderSide = useTradingStore((s) => s.setOrderSide);
  const setOrderType = useTradingStore((s) => s.setOrderType);
  const setOrderQty = useTradingStore((s) => s.setOrderQty);
  const setOrderPrice = useTradingStore((s) => s.setOrderPrice);
  const setOrderStop = useTradingStore((s) => s.setOrderStop);
  const setOrderTarget = useTradingStore((s) => s.setOrderTarget);
  const placeOrder = useTradingStore((s) => s.placeOrder);

  const currentPrice = useMemo(() => {
    if (candles.length === 0) return 0;
    return candles[candles.length - 1].close;
  }, [candles]);

  const isMarket = orderType === "market";
  const isBuy = orderSide === "buy";

  // Risk/Reward calculation
  const riskReward = useMemo(() => {
    const entry = isMarket ? currentPrice : orderPrice;
    if (entry === 0 || orderStop === 0 || orderTarget === 0) return null;

    const risk = Math.abs(entry - orderStop);
    const reward = Math.abs(orderTarget - entry);
    if (risk === 0) return null;
    return reward / risk;
  }, [currentPrice, orderPrice, orderStop, orderTarget, isMarket]);

  // Quick qty multipliers
  const baseQty = 0.01;
  const quickQtys = [0.5, 1, 2, 5];

  const inputClass = "tinput";
  const labelClass = "text-[10px] text-[#7489a1] uppercase tracking-wider mb-1 block";

  return (
    <div className="tpanel h-full flex flex-col">
      <div className="tpanel-header">
        <span>Order Entry</span>
        <span className="mono text-[#59a0ff]">{symbol}</span>
      </div>

      <div className="tpanel-body flex flex-col gap-3">
        {/* Buy / Sell Toggle */}
        <div className="flex gap-2">
          <button
            className={`flex-1 py-2.5 rounded-md text-xs font-bold uppercase tracking-wider transition-all ${
              isBuy
                ? "bg-[#19c37d] text-white shadow-lg shadow-[rgba(25,195,125,0.25)]"
                : "bg-[#0e1723] text-[#19c37d] border border-[#19c37d30] hover:bg-[rgba(25,195,125,0.08)]"
            }`}
            onClick={() => setOrderSide("buy")}
          >
            Buy
          </button>
          <button
            className={`flex-1 py-2.5 rounded-md text-xs font-bold uppercase tracking-wider transition-all ${
              !isBuy
                ? "bg-[#ff5f70] text-white shadow-lg shadow-[rgba(255,95,112,0.25)]"
                : "bg-[#0e1723] text-[#ff5f70] border border-[#ff5f7030] hover:bg-[rgba(255,95,112,0.08)]"
            }`}
            onClick={() => setOrderSide("sell")}
          >
            Sell
          </button>
        </div>

        {/* Limit / Market Toggle */}
        <div className="flex gap-2">
          <button
            className={`tbtn flex-1 ${!isMarket ? "tbtn-active" : ""}`}
            onClick={() => setOrderType("limit")}
          >
            Limit
          </button>
          <button
            className={`tbtn flex-1 ${isMarket ? "tbtn-active" : ""}`}
            onClick={() => setOrderType("market")}
          >
            Market
          </button>
        </div>

        {/* Quantity */}
        <div>
          <label className={labelClass}>Quantity</label>
          <div className="flex gap-1.5">
            <input
              type="number"
              className={inputClass}
              value={orderQty}
              onChange={(e) => setOrderQty(Math.max(0.001, parseFloat(e.target.value) || 0))}
              step={baseQty}
              min={0.001}
            />
          </div>
          {/* Quick qty buttons */}
          <div className="flex gap-1 mt-1.5">
            {quickQtys.map((mult) => (
              <button
                key={mult}
                className="tbtn text-[10px] px-2 py-1 flex-1"
                onClick={() => setOrderQty(parseFloat((baseQty * mult).toFixed(4)))}
              >
                {mult}x
              </button>
            ))}
          </div>
        </div>

        {/* Price */}
        <div>
          <label className={labelClass}>Price</label>
          <input
            type="number"
            className={inputClass}
            value={isMarket ? formatPrice(currentPrice) : orderPrice}
            onChange={(e) => setOrderPrice(parseFloat(e.target.value) || 0)}
            step={currentPrice * 0.0001}
            disabled={isMarket}
          />
        </div>

        {/* Stop Loss & Take Profit side by side */}
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className={labelClass}>Stop Loss</label>
            <input
              type="number"
              className={inputClass}
              value={orderStop}
              onChange={(e) => setOrderStop(parseFloat(e.target.value) || 0)}
              step={currentPrice * 0.0001}
            />
          </div>
          <div>
            <label className={labelClass}>Take Profit</label>
            <input
              type="number"
              className={inputClass}
              value={orderTarget}
              onChange={(e) => setOrderTarget(parseFloat(e.target.value) || 0)}
              step={currentPrice * 0.0001}
            />
          </div>
        </div>

        {/* Risk/Reward Display */}
        {riskReward !== null && (
          <div className="flex items-center justify-between px-3 py-2 rounded-md bg-[#0e1723] border border-[#1b2b3f]">
            <span className="text-[10px] text-[#7489a1] uppercase tracking-wider">Risk : Reward</span>
            <span className="mono text-sm font-bold">
              <span className="text-[#ff5f70]">1</span>
              <span className="text-[#4a6178] mx-1">:</span>
              <span className={riskReward >= 2 ? "text-[#19c37d]" : riskReward >= 1 ? "text-[#f6b446]" : "text-[#ff5f70]"}>
                {riskReward.toFixed(1)}
              </span>
            </span>
          </div>
        )}

        {/* Estimated Values */}
        <div className="flex items-center justify-between text-[10px] text-[#4a6178] px-1">
          <span>Est. Value</span>
          <span className="mono text-[#9eb3ca]">
            {formatPrice((isMarket ? currentPrice : orderPrice) * orderQty)}
          </span>
        </div>

        {/* Place Order Button */}
        <button
          onClick={placeOrder}
          className={`w-full py-3 rounded-md text-xs font-bold uppercase tracking-widest transition-all active:scale-[0.98] ${
            isBuy
              ? "bg-[#19c37d] text-white hover:bg-[#22d495] shadow-lg shadow-[rgba(25,195,125,0.2)]"
              : "bg-[#ff5f70] text-white hover:bg-[#ff7085] shadow-lg shadow-[rgba(255,95,112,0.2)]"
          }`}
        >
          {isBuy ? "Place Buy Order" : "Place Sell Order"}
        </button>
      </div>
    </div>
  );
}
