"use client";

import { useMemo } from "react";
import { useTradingStore } from "@/lib/trading-store";
import { computeFootprint } from "@/lib/trading-utils";
import { formatPrice, formatQty } from "@/lib/trading-utils";
import { Zap } from "lucide-react";

export default function FootprintPanel() {
  const candles = useTradingStore((s) => s.candles);
  const showReplay = useTradingStore((s) => s.showReplay);
  const replayCursor = useTradingStore((s) => s.replayCursor);

  const lastCandle = useMemo(() => {
    if (candles.length === 0) return null;
    if (showReplay) {
      const idx = Math.min(replayCursor, candles.length - 1);
      return candles[idx];
    }
    return candles[candles.length - 1];
  }, [candles, showReplay, replayCursor]);

  const rows = useMemo(() => {
    if (!lastCandle) return [];
    return computeFootprint(lastCandle);
  }, [lastCandle]);

  const imbalanceCount = useMemo(
    () => rows.filter((r) => r.imbalance).length,
    [rows]
  );

  const totalBid = useMemo(
    () => rows.reduce((a, r) => a + r.bid, 0),
    [rows]
  );
  const totalAsk = useMemo(
    () => rows.reduce((a, r) => a + r.ask, 0),
    [rows]
  );
  const totalDelta = useMemo(
    () => rows.reduce((a, r) => a + r.delta, 0),
    [rows]
  );

  if (!lastCandle) {
    return (
      <div className="tpanel h-full">
        <div className="tpanel-header">
          <span>FOOTPRINT</span>
        </div>
        <div className="tpanel-body flex items-center justify-center h-32 text-[#7489a1] text-xs">
          No candle data
        </div>
      </div>
    );
  }

  return (
    <div className="tpanel h-full flex flex-col">
      <div className="tpanel-header">
        <div className="flex items-center gap-2">
          <span>FOOTPRINT</span>
          {imbalanceCount > 0 && (
            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-500/15 text-amber-400 border border-amber-500/20">
              <Zap size={10} />
              {imbalanceCount}
            </span>
          )}
        </div>
        <div className="flex items-center gap-3 text-[10px]">
          <span className="text-[#19c37d]">B {formatQty(totalBid)}</span>
          <span className="text-[#ff5f70]">S {formatQty(totalAsk)}</span>
          <span className={totalDelta >= 0 ? "text-[#19c37d]" : "text-[#ff5f70]"}>
            Δ {totalDelta >= 0 ? "+" : ""}{formatQty(totalDelta)}
          </span>
        </div>
      </div>

      {/* Column headers */}
      <div className="flex items-center px-2 py-1 text-[9px] uppercase tracking-wider text-[#7489a1] border-b border-[#1b2b3f]/50">
        <div className="w-[72px] text-right pr-1">Bid</div>
        <div className="w-[78px] text-center">Price</div>
        <div className="w-[72px] text-left pl-1">Ask</div>
        <div className="w-[52px] text-right">Delta</div>
        <div className="flex-1 text-right">Total</div>
      </div>

      <div className="tpanel-body flex-1 p-0">
        {rows.map((row, i) => {
          const isImbalance = row.imbalance;
          const deltaPositive = row.delta > 0;
          const maxTotal = Math.max(...rows.map((r) => r.total), 1);
          const bidPct = (row.bid / row.total) * 100;
          const askPct = (row.ask / row.total) * 100;

          return (
            <div
              key={i}
              className={`
                flex items-center px-2 text-[11px] mono border-b border-[#1b2b3f]/30
                ${isImbalance ? "imbalance-row" : ""}
                hover:bg-[#142031]/50 transition-colors
              `}
              style={{
                ...(isImbalance
                  ? {
                      backgroundColor:
                        "rgba(255, 200, 50, 0.06)",
                    }
                  : {}),
              }}
            >
              {/* Bid volume with background bar */}
              <div className="w-[72px] text-right pr-1 relative">
                <div
                  className="absolute right-1 top-0 bottom-0 rounded-l-sm"
                  style={{
                    width: `${(row.bid / maxTotal) * 100}%`,
                    backgroundColor: "rgba(25, 195, 125, 0.08)",
                    maxWidth: "100%",
                  }}
                />
                <span className="relative z-10 text-[#19c37d]">
                  {formatQty(row.bid)}
                </span>
              </div>

              {/* Price */}
              <div className="w-[78px] text-center text-[#d8e0ea] font-medium relative">
                {formatPrice(row.price)}
                {isImbalance && (
                  <span
                    className="absolute right-1 top-1/2 -translate-y-1/2 text-[7px] font-bold text-amber-400"
                    title={`Imbalance ratio: ${row.imbalanceRatio.toFixed(1)}x`}
                  >
                    ⚡
                  </span>
                )}
              </div>

              {/* Ask volume with background bar */}
              <div className="w-[72px] text-left pl-1 relative">
                <div
                  className="absolute left-1 top-0 bottom-0 rounded-r-sm"
                  style={{
                    width: `${(row.ask / maxTotal) * 100}%`,
                    backgroundColor: "rgba(255, 95, 112, 0.08)",
                    maxWidth: "100%",
                  }}
                />
                <span className="relative z-10 text-[#ff5f70]">
                  {formatQty(row.ask)}
                </span>
              </div>

              {/* Delta */}
              <div
                className={`w-[52px] text-right font-medium ${
                  deltaPositive ? "text-[#19c37d]" : "text-[#ff5f70]"
                }`}
              >
                {row.delta > 0 ? "+" : ""}
                {formatQty(row.delta)}
              </div>

              {/* Total volume with bar */}
              <div className="flex-1 text-right pr-1 relative">
                <div
                  className="absolute right-1 top-[3px] bottom-[3px] rounded-sm"
                  style={{
                    width: `${(row.total / maxTotal) * 100}%`,
                    maxWidth: "100%",
                    background: `linear-gradient(to left, rgba(25, 195, 125, ${bidPct / 200}), rgba(255, 95, 112, ${askPct / 200}))`,
                  }}
                />
                <span className="relative z-10 text-[#9eb3ca]">
                  {formatQty(row.total)}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
