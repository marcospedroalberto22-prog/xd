"use client";

import { useMemo } from "react";
import { useTradingStore } from "@/lib/trading-store";
import { formatPrice, formatQty } from "@/lib/trading-utils";
import { Layers } from "lucide-react";

export default function DomPanel() {
  const candles = useTradingStore((s) => s.candles);
  const depth = useTradingStore((s) => s.depth);
  const showReplay = useTradingStore((s) => s.showReplay);
  const replayCursor = useTradingStore((s) => s.replayCursor);

  const currentPrice = useMemo(() => {
    if (candles.length === 0) return 0;
    if (showReplay) {
      const idx = Math.min(replayCursor, candles.length - 1);
      return candles[idx].close;
    }
    return candles[candles.length - 1].close;
  }, [candles, showReplay, replayCursor]);

  const { asks, bids } = depth;

  // Max total for sizing bars
  const maxTotal = useMemo(() => {
    const askMax = asks.length > 0 ? Math.max(...asks.map((a) => a.total)) : 0;
    const bidMax = bids.length > 0 ? Math.max(...bids.map((b) => b.total)) : 0;
    return Math.max(askMax, bidMax, 1);
  }, [asks, bids]);

  // Cumulative sizes
  const totalAskSize = useMemo(
    () => asks.reduce((a, r) => a + r.size, 0),
    [asks]
  );
  const totalBidSize = useMemo(
    () => bids.reduce((a, r) => a + r.size, 0),
    [bids]
  );
  const spread = useMemo(() => {
    if (asks.length === 0 || bids.length === 0) return 0;
    return asks[0].price - bids[0].price;
  }, [asks, bids]);

  return (
    <div className="tpanel h-full flex flex-col">
      <div className="tpanel-header">
        <div className="flex items-center gap-2">
          <Layers size={12} className="text-[#59a0ff]" />
          <span>ORDER BOOK</span>
        </div>
        <div className="flex items-center gap-3 text-[10px]">
          <span className="text-[#ff5f70]">{formatQty(totalAskSize)} asks</span>
          <span className="text-[#19c37d]">{formatQty(totalBidSize)} bids</span>
          <span className="text-[#7489a1]">Sprd {formatPrice(spread)}</span>
        </div>
      </div>

      <div className="tpanel-body flex-1 p-0">
        {/* Column headers */}
        <div className="flex items-center px-2 py-1 text-[9px] uppercase tracking-wider text-[#7489a1] border-b border-[#1b2b3f]/50">
          <div className="w-[72px] text-right pr-2">Price</div>
          <div className="w-[52px] text-right">Size</div>
          <div className="w-[52px] text-right">Total</div>
          <div className="w-[36px] text-right">Orders</div>
          <div className="flex-1" />
        </div>

        {/* Asks (reversed so lowest ask is closest to spread) */}
        <div className="max-h-[38%] overflow-hidden">
          {[...asks].reverse().map((level, i) => {
            const barWidth = (level.total / maxTotal) * 100;
            return (
              <div
                key={`ask-${i}`}
                className="flex items-center px-2 text-[11px] mono border-b border-[#1b2b3f]/20 hover:bg-[#142031]/50 transition-colors relative"
              >
                <div
                  className="absolute top-0 bottom-0 right-0 rounded-l-sm"
                  style={{
                    width: `${barWidth}%`,
                    backgroundColor: "rgba(255, 95, 112, 0.06)",
                  }}
                />
                <div className="w-[72px] text-right pr-2 relative z-10 text-[#ff5f70] font-medium">
                  {formatPrice(level.price)}
                </div>
                <div className="w-[52px] text-right relative z-10 text-[#d8e0ea]">
                  {formatQty(level.size)}
                </div>
                <div className="w-[52px] text-right relative z-10 text-[#9eb3ca]">
                  {formatQty(level.total)}
                </div>
                <div className="w-[36px] text-right relative z-10 text-[#7489a1] text-[10px]">
                  {level.orders}
                </div>
                <div className="flex-1" />
              </div>
            );
          })}
        </div>

        {/* Spread / Market price */}
        <div className="flex items-center px-2 py-1.5 bg-[#59a0ff]/10 border-y border-[#59a0ff]/20">
          <div className="w-[72px] text-right pr-2">
            <span className="mono text-[13px] font-bold text-[#59a0ff]">
              {currentPrice > 0 ? formatPrice(currentPrice) : "—"}
            </span>
          </div>
          <div className="flex-1 flex items-center gap-2">
            <span className="text-[9px] text-[#59a0ff] font-medium tracking-wider uppercase">
              Market Price
            </span>
            {spread > 0 && (
              <span className="text-[9px] text-[#7489a1]">
                Spread: {formatPrice(spread)}
              </span>
            )}
          </div>
          <div className="w-[140px]" />
        </div>

        {/* Bids */}
        <div className="max-h-[38%] overflow-hidden">
          {bids.map((level, i) => {
            const barWidth = (level.total / maxTotal) * 100;
            return (
              <div
                key={`bid-${i}`}
                className="flex items-center px-2 text-[11px] mono border-b border-[#1b2b3f]/20 hover:bg-[#142031]/50 transition-colors relative"
              >
                <div
                  className="absolute top-0 bottom-0 right-0 rounded-l-sm"
                  style={{
                    width: `${barWidth}%`,
                    backgroundColor: "rgba(25, 195, 125, 0.06)",
                  }}
                />
                <div className="w-[72px] text-right pr-2 relative z-10 text-[#19c37d] font-medium">
                  {formatPrice(level.price)}
                </div>
                <div className="w-[52px] text-right relative z-10 text-[#d8e0ea]">
                  {formatQty(level.size)}
                </div>
                <div className="w-[52px] text-right relative z-10 text-[#9eb3ca]">
                  {formatQty(level.total)}
                </div>
                <div className="w-[36px] text-right relative z-10 text-[#7489a1] text-[10px]">
                  {level.orders}
                </div>
                <div className="flex-1" />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
