"use client";

import { useMemo } from "react";
import { useTradingStore } from "@/lib/trading-store";
import { formatPrice, formatQty } from "@/lib/trading-utils";
import { Activity, DollarSign, BarChart3, TrendingUp, Target, ArrowUp, ArrowDown } from "lucide-react";

export default function SessionStats() {
  const positions = useTradingStore((s) => s.positions);
  const candles = useTradingStore((s) => s.candles);

  const currentPrice = useMemo(() => {
    if (candles.length === 0) return 0;
    return candles[candles.length - 1].close;
  }, [candles]);

  // Total PnL from all positions
  const totalPnl = useMemo(() => {
    return positions.reduce((sum, pos) => {
      const pnl = pos.side === "buy"
        ? (currentPrice - pos.entry) * pos.qty
        : (pos.entry - currentPrice) * pos.qty;
      return sum + pnl;
    }, 0);
  }, [positions, currentPrice]);

  // Simulated win rate and trade count
  const tradeCount = positions.length;
  const winCount = useMemo(() => {
    return positions.filter((pos) => {
      const pnl = pos.side === "buy"
        ? (currentPrice - pos.entry) * pos.qty
        : (pos.entry - currentPrice) * pos.qty;
      return pnl > 0;
    }).length;
  }, [positions, currentPrice]);
  const winRate = tradeCount > 0 ? (winCount / tradeCount) * 100 : 0;

  // Current cumulative delta from candles
  const currentDelta = useMemo(() => {
    return candles.slice(-20).reduce((sum, c) => sum + c.delta, 0);
  }, [candles]);

  // Simulated open interest
  const openInterest = useMemo(() => {
    if (candles.length < 2) return 0;
    const baseOI = candles[candles.length - 1].volume * 150;
    return baseOI + Math.sin(Date.now() / 30000) * baseOI * 0.05;
  }, [candles]);

  // Session high/low
  const sessionHigh = useMemo(() => {
    if (candles.length === 0) return 0;
    return Math.max(...candles.map((c) => c.high));
  }, [candles]);

  const sessionLow = useMemo(() => {
    if (candles.length === 0) return 0;
    return Math.min(...candles.map((c) => c.low));
  }, [candles]);

  const stats = [
    {
      label: "Total PnL",
      value: `${totalPnl >= 0 ? "+" : ""}${formatPrice(totalPnl)}`,
      color: totalPnl >= 0 ? "text-[#19c37d]" : "text-[#ff5f70]",
      icon: <DollarSign className="w-3.5 h-3.5" />,
    },
    {
      label: "Win Rate",
      value: tradeCount > 0 ? `${winRate.toFixed(0)}%` : "--",
      color: winRate >= 50 ? "text-[#19c37d]" : winRate > 0 ? "text-[#f6b446]" : "text-[#7489a1]",
      icon: <Target className="w-3.5 h-3.5" />,
    },
    {
      label: "Trades",
      value: `${tradeCount} (${winCount}W)`,
      color: "text-[#9eb3ca]",
      icon: <BarChart3 className="w-3.5 h-3.5" />,
    },
    {
      label: "Delta",
      value: `${currentDelta >= 0 ? "+" : ""}${formatQty(currentDelta)}`,
      color: currentDelta >= 0 ? "text-[#19c37d]" : "text-[#ff5f70]",
      icon: <Activity className="w-3.5 h-3.5" />,
    },
    {
      label: "Session High",
      value: formatPrice(sessionHigh),
      color: "text-[#d8e0ea]",
      icon: <ArrowUp className="w-3.5 h-3.5" />,
    },
    {
      label: "Session Low",
      value: formatPrice(sessionLow),
      color: "text-[#d8e0ea]",
      icon: <ArrowDown className="w-3.5 h-3.5" />,
    },
  ];

  return (
    <div className="flex items-center gap-3 px-3 py-1.5">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="flex items-center gap-1.5 px-2 py-1 rounded bg-[#0a121d] border border-[#1b2b3f]"
        >
          <span className="text-[#4a6178]">{stat.icon}</span>
          <div className="flex flex-col">
            <span className="text-[9px] text-[#4a6178] uppercase tracking-wider leading-none">
              {stat.label}
            </span>
            <span className={`mono text-[11px] font-semibold ${stat.color} leading-tight`}>
              {stat.value}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}
