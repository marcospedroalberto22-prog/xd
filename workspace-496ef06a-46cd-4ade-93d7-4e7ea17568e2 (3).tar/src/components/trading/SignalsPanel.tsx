"use client";

import { useMemo, useState } from "react";
import { useTradingStore } from "@/lib/trading-store";
import { formatPrice, formatQty, formatTime, computeFootprint } from "@/lib/trading-utils";
import type { ImbalanceSignal, IcebergSignal } from "@/lib/trading-types";
import {
  AlertTriangle,
  Waves,
  ArrowDown,
  Shield,
  Zap,
  Radio,
} from "lucide-react";

type SignalTab = "imbalance" | "iceberg" | "delta" | "absorption";

export default function SignalsPanel() {
  const candles = useTradingStore((s) => s.candles);
  const tape = useTradingStore((s) => s.tape);
  const [activeTab, setActiveTab] = useState<SignalTab>("imbalance");

  // Compute imbalance signals from footprint
  const imbalanceSignals = useMemo<ImbalanceSignal[]>(() => {
    if (candles.length === 0) return [];
    const lastCandle = candles[candles.length - 1];
    const footprint = computeFootprint(lastCandle);

    // Filter rows with imbalance ratio > 200% (ratio > 3.0)
    return footprint
      .filter((row) => row.imbalance && row.imbalanceRatio > 3.0)
      .map((row) => ({
        price: row.price,
        side: row.ask > row.bid ? "ask" as const : "bid" as const,
        ratio: row.imbalanceRatio,
        type: Math.abs(row.delta) > row.total * 0.15 ? "delta" as const : "volume" as const,
      }))
      .sort((a, b) => b.ratio - a.ratio);
  }, [candles]);

  // Compute iceberg signals from tape (large block trades)
  const icebergSignals = useMemo<IcebergSignal[]>(() => {
    if (tape.length === 0) return [];

    // Filter for block trades (large size)
    const blockThreshold = tape.reduce((max, t) => Math.max(max, t.size), 0) * 0.6;
    return tape
      .filter((trade) => trade.size >= blockThreshold)
      .map((trade) => ({
        time: trade.time,
        side: trade.side,
        price: trade.price,
        size: trade.size,
      }))
      .sort((a, b) => b.time - a.time)
      .slice(0, 20);
  }, [tape]);

  // Simulate delta divergence signals
  const deltaDivergence = useMemo(() => {
    if (candles.length < 10) return [];
    const signals: Array<{
      time: number;
      price: number;
      type: "bullish" | "bearish";
      strength: number;
    }> = [];

    const recent = candles.slice(-20);
    for (let i = 2; i < recent.length; i++) {
      const priceUp = recent[i].close > recent[i - 1].close;
      const deltaUp = recent[i].delta > recent[i - 1].delta;
      if (priceUp !== deltaUp) {
        const strength = Math.abs(recent[i].delta - recent[i - 1].delta) / recent[i].volume;
        if (strength > 0.05) {
          signals.push({
            time: recent[i].time,
            price: recent[i].close,
            type: priceUp ? "bearish" : "bullish",
            strength,
          });
        }
      }
    }
    return signals.slice(-8);
  }, [candles]);

  // Simulate absorption signals (high volume, small price change)
  const absorptionSignals = useMemo(() => {
    if (candles.length < 5) return [];
    const signals: Array<{
      time: number;
      price: number;
      side: "buy" | "sell";
      volume: number;
      range: number;
    }> = [];

    const recent = candles.slice(-20);
    const avgVol = recent.reduce((s, c) => s + c.volume, 0) / recent.length;

    for (const c of recent) {
      const range = c.high - c.low;
      const body = Math.abs(c.close - c.open);
      const isHighVolume = c.volume > avgVol * 1.5;
      const isSmallRange = body < range * 0.3;
      if (isHighVolume && isSmallRange && c.volume > 0) {
        signals.push({
          time: c.time,
          price: c.close,
          side: c.close > c.open ? "buy" : "sell",
          volume: c.volume,
          range,
        });
      }
    }
    return signals.slice(-8);
  }, [candles]);

  const tabs: Array<{ key: SignalTab; label: string; icon: React.ReactNode; count: number }> = [
    {
      key: "imbalance",
      label: "Imbalance",
      icon: <AlertTriangle className="w-3 h-3" />,
      count: imbalanceSignals.length,
    },
    {
      key: "iceberg",
      label: "Iceberg",
      icon: <Zap className="w-3 h-3" />,
      count: icebergSignals.length,
    },
    {
      key: "delta",
      label: "Delta Div",
      icon: <Waves className="w-3 h-3" />,
      count: deltaDivergence.length,
    },
    {
      key: "absorption",
      label: "Absorption",
      icon: <Shield className="w-3 h-3" />,
      count: absorptionSignals.length,
    },
  ];

  return (
    <div className="tpanel h-full flex flex-col">
      <div className="tpanel-header">
        <span>Signals</span>
        <span className="mono text-[10px]">
          {imbalanceSignals.length + icebergSignals.length + deltaDivergence.length + absorptionSignals.length} active
        </span>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 px-2 py-1.5 border-b border-[#1b2b3f]">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] transition-all ${
              activeTab === tab.key
                ? "bg-[#11273f] text-[#59a0ff]"
                : "text-[#4a6178] hover:text-[#7489a1] hover:bg-[#0e1723]"
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
            {tab.count > 0 && (
              <span className={`mono text-[9px] px-1 rounded ${
                activeTab === tab.key
                  ? "bg-[#59a0ff20] text-[#59a0ff]"
                  : "bg-[#1b2b3f] text-[#4a6178]"
              }`}>
                {tab.count}
              </span>
            )}
          </button>
        ))}
      </div>

      <div className="tpanel-body flex-1 p-0">
        {/* Imbalance Signals */}
        {activeTab === "imbalance" && (
          <div className="flex flex-col">
            {imbalanceSignals.length === 0 ? (
              <div className="flex items-center justify-center py-8 text-[11px] text-[#4a6178]">
                No volume imbalances detected
              </div>
            ) : (
              <>
                <div className="flex items-center px-3 py-1.5 text-[10px] text-[#7489a1] uppercase tracking-wider border-b border-[#1b2b3f]">
                  <span className="w-16">Level</span>
                  <span className="w-10 text-center">Side</span>
                  <span className="flex-1 text-center">Ratio</span>
                  <span className="w-14 text-right">Type</span>
                </div>
                {imbalanceSignals.map((sig, i) => (
                  <div
                    key={i}
                    className={`flex items-center px-3 py-2 text-xs border-b border-[#1b2b3f50] ${
                      sig.ratio > 5 ? "bg-[rgba(255,200,50,0.04)]" : ""
                    }`}
                  >
                    <span className="w-16 mono text-[11px] text-[#d8e0ea]">
                      {formatPrice(sig.price)}
                    </span>
                    <span className={`w-10 text-center text-[10px] font-bold uppercase ${
                      sig.side === "ask" ? "text-[#ff5f70]" : "text-[#19c37d]"
                    }`}>
                      {sig.side === "ask" ? "ASK" : "BID"}
                    </span>
                    <div className="flex-1 flex items-center justify-center gap-2">
                      <div className="w-16 h-1.5 rounded-full bg-[#1b2b3f] overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            sig.ratio > 5 ? "bg-[#f6b446]" : sig.side === "ask" ? "bg-[#ff5f70]" : "bg-[#19c37d]"
                          }`}
                          style={{ width: `${Math.min(100, (sig.ratio / 10) * 100)}%` }}
                        />
                      </div>
                      <span className={`mono text-[11px] font-semibold ${
                        sig.ratio > 5 ? "text-[#f6b446]" : "text-[#9eb3ca]"
                      }`}>
                        {sig.ratio.toFixed(1)}x
                      </span>
                    </div>
                    <span className={`w-14 text-right text-[10px] ${
                      sig.type === "delta" ? "text-[#d76dff]" : "text-[#4a6178]"
                    }`}>
                      {sig.type === "delta" ? "Delta" : "Volume"}
                    </span>
                  </div>
                ))}
              </>
            )}
          </div>
        )}

        {/* Iceberg Signals */}
        {activeTab === "iceberg" && (
          <div className="flex flex-col">
            {icebergSignals.length === 0 ? (
              <div className="flex items-center justify-center py-8 text-[11px] text-[#4a6178]">
                No iceberg orders detected
              </div>
            ) : (
              <>
                <div className="flex items-center px-3 py-1.5 text-[10px] text-[#7489a1] uppercase tracking-wider border-b border-[#1b2b3f]">
                  <span className="w-14">Time</span>
                  <span className="w-10 text-center">Side</span>
                  <span className="flex-1 text-right">Price</span>
                  <span className="w-14 text-right">Size</span>
                </div>
                {icebergSignals.map((sig, i) => (
                  <div
                    key={i}
                    className="flex items-center px-3 py-2 text-xs border-b border-[#1b2b3f50] hover:bg-[#11273f50] transition-colors"
                  >
                    <span className="w-14 mono text-[10px] text-[#4a6178]">
                      {formatTime(sig.time)}
                    </span>
                    <span className={`w-10 text-center text-[10px] font-bold ${
                      sig.side === "buy" ? "text-[#19c37d]" : "text-[#ff5f70]"
                    }`}>
                      {sig.side === "buy" ? "BUY" : "SELL"}
                    </span>
                    <span className="flex-1 text-right mono text-[11px] text-[#d8e0ea]">
                      {formatPrice(sig.price)}
                    </span>
                    <span className="w-14 text-right mono text-[11px] font-semibold text-[#f6b446]">
                      {formatQty(sig.size)}
                    </span>
                  </div>
                ))}
              </>
            )}
          </div>
        )}

        {/* Delta Divergence Signals */}
        {activeTab === "delta" && (
          <div className="flex flex-col">
            {deltaDivergence.length === 0 ? (
              <div className="flex items-center justify-center py-8 text-[11px] text-[#4a6178]">
                No delta divergence detected
              </div>
            ) : (
              <>
                <div className="flex items-center px-3 py-1.5 text-[10px] text-[#7489a1] uppercase tracking-wider border-b border-[#1b2b3f]">
                  <span className="w-14">Time</span>
                  <span className="w-14 text-center">Type</span>
                  <span className="flex-1 text-right">Price</span>
                  <span className="w-14 text-right">Strength</span>
                </div>
                {deltaDivergence.map((sig, i) => (
                  <div
                    key={i}
                    className="flex items-center px-3 py-2 text-xs border-b border-[#1b2b3f50] hover:bg-[#11273f50] transition-colors"
                  >
                    <span className="w-14 mono text-[10px] text-[#4a6178]">
                      {formatTime(sig.time)}
                    </span>
                    <span className={`w-14 text-center text-[10px] font-bold uppercase ${
                      sig.type === "bullish" ? "text-[#19c37d]" : "text-[#ff5f70]"
                    }`}>
                      {sig.type}
                    </span>
                    <span className="flex-1 text-right mono text-[11px] text-[#d8e0ea]">
                      {formatPrice(sig.price)}
                    </span>
                    <span className={`w-14 text-right mono text-[11px] ${
                      sig.strength > 0.15 ? "text-[#f6b446]" : "text-[#7489a1]"
                    }`}>
                      {(sig.strength * 100).toFixed(0)}%
                    </span>
                  </div>
                ))}
              </>
            )}
          </div>
        )}

        {/* Absorption Signals */}
        {activeTab === "absorption" && (
          <div className="flex flex-col">
            {absorptionSignals.length === 0 ? (
              <div className="flex items-center justify-center py-8 text-[11px] text-[#4a6178]">
                No absorption detected
              </div>
            ) : (
              <>
                <div className="flex items-center px-3 py-1.5 text-[10px] text-[#7489a1] uppercase tracking-wider border-b border-[#1b2b3f]">
                  <span className="w-14">Time</span>
                  <span className="w-10 text-center">Side</span>
                  <span className="flex-1 text-right">Price</span>
                  <span className="w-14 text-right">Volume</span>
                </div>
                {absorptionSignals.map((sig, i) => (
                  <div
                    key={i}
                    className="flex items-center px-3 py-2 text-xs border-b border-[#1b2b3f50] hover:bg-[#11273f50] transition-colors"
                  >
                    <span className="w-14 mono text-[10px] text-[#4a6178]">
                      {formatTime(sig.time)}
                    </span>
                    <span className={`w-10 text-center text-[10px] font-bold ${
                      sig.side === "buy" ? "text-[#19c37d]" : "text-[#ff5f70]"
                    }`}>
                      {sig.side === "buy" ? "BUY" : "SELL"}
                    </span>
                    <span className="flex-1 text-right mono text-[11px] text-[#d8e0ea]">
                      {formatPrice(sig.price)}
                    </span>
                    <span className="w-14 text-right mono text-[11px] text-[#d76dff]">
                      {formatQty(sig.volume)}
                    </span>
                  </div>
                ))}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
