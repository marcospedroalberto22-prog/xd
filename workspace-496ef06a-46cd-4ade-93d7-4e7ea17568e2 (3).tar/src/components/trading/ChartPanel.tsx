"use client";

import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { useTradingStore } from "@/lib/trading-store";
import {
  computeEma,
  computeRsi,
  computeBollinger,
  computeVwap,
  computeCumulativeDelta,
  formatPrice,
  formatTime,
  formatQty,
  clamp,
} from "@/lib/trading-utils";
import type { Candle } from "@/lib/trading-types";
import {
  computeSuperTrend,
  computeMACD,
  computeStochastic,
  computeIchimoku,
  computeAlligator,
  computeParabolicSAR,
  computeKeltnerChannel,
  computeDonchianChannel,
  computeSqueezeMomentum,
  computeFairValueGap,
  computeOrderBlock,
  computeFractals,
  computeVWMA,
  computeATR,
  computeTDSequential,
} from "@/lib/indicators-engine";

// ─── Constants ──────────────────────────────────────────────────────
const VW = 1200;
const VH = 620;
const PAD_L = 62;
const PAD_R = 20;
const PAD_T = 22;
const CHART_BOTTOM = 375;
const VOL_TOP = 382;
const VOL_BOTTOM = 445;
const CVD_TOP = 452;
const CVD_BOTTOM = 510;
const SUB_TOP = 516;
const SUB_BOTTOM = 612;

const COL_BULL = "#19c37d";
const COL_BEAR = "#ff5f70";
const COL_BULL_DIM = "rgba(25,195,125,0.25)";
const COL_BEAR_DIM = "rgba(255,95,112,0.25)";
const COL_GRID = "rgba(255,255,255,0.06)";
const COL_GRID_TEXT = "rgba(255,255,255,0.35)";
const COL_EMA20 = "#f5c842";
const COL_EMA50 = "#e879f9";
const COL_BB_FILL = "rgba(89,160,255,0.07)";
const COL_BB_LINE = "#59a0ff";
const COL_VWAP = "#59a0ff";
const COL_CROSSHAIR = "rgba(255,255,255,0.25)";
const COL_FIB = "rgba(255,255,255,0.13)";
const COL_HLINE = "rgba(255,255,255,0.35)";

// New indicator colors
const COL_SUPERTREND_UP = "#19c37d";
const COL_SUPERTREND_DN = "#ff5f70";
const COL_ICHIMOKU_BULL = "rgba(25,195,125,0.08)";
const COL_ICHIMOKU_BEAR = "rgba(255,95,112,0.08)";
const COL_ICHIMOKU_CONV = "#59a0ff";
const COL_ICHIMOKU_BASE = "#ff5f70";
const COL_ALLIGATOR_JAW = "#59a0ff";
const COL_ALLIGATOR_TEETH = "#ff5f70";
const COL_ALLIGATOR_LIPS = "#19c37d";
const COL_SAR = "#f6b446";
const COL_KELTNER = "rgba(89,160,255,0.3)";
const COL_DONCHIAN = "rgba(246,180,70,0.3)";
const COL_FVG_BULL = "rgba(25,195,125,0.12)";
const COL_FVG_BEAR = "rgba(255,95,112,0.12)";
const COL_OB_BULL = "rgba(25,195,125,0.15)";
const COL_OB_BEAR = "rgba(255,95,112,0.15)";
const COL_FRACTAL_UP = "#19c37d";
const COL_FRACTAL_DN = "#ff5f70";
const COL_VWMA = "#d76dff";
const COL_TD_SEQ = "#f6b446";
const COL_MACD_LINE = "#59a0ff";
const COL_STOCH_K = "#f6b446";
const COL_STOCH_D = "#d76dff";

// Volume & anchor overlay colors
const COL_AVWAP = "#00e5ff";
const COL_POC_TRAIL = "#f6b446";
const COL_VOL_MA = "rgba(255,255,255,0.4)";
const COL_VOL_SPLIT_BUY = "rgba(25,195,125,0.6)";
const COL_VOL_SPLIT_SELL = "rgba(255,95,112,0.6)";
const COL_VOL_NODES = "rgba(246,180,70,0.3)";

const FIB_LEVELS = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1];

const pathFromSeries = (xs: number[], ys: number[]): string => {
  if (xs.length === 0) return "";
  let d = `M ${xs[0].toFixed(2)} ${ys[0].toFixed(2)}`;
  for (let i = 1; i < xs.length; i++) {
    d += ` L ${xs[i].toFixed(2)} ${ys[i].toFixed(2)}`;
  }
  return d;
};

// ─── ChartPanel ─────────────────────────────────────────────────────
const ChartPanel: React.FC = React.memo(function ChartPanel() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [dims, setDims] = useState({ w: VW, h: VH });
  const [anchorMode, setAnchorMode] = useState(false);
  const rafRef = useRef<number>(0);

  // ── Store (original) ──────────────────────────────────────────────
  const candles = useTradingStore((s) => s.candles);
  const chartType = useTradingStore((s) => s.chartType);
  const showHeatmap = useTradingStore((s) => s.showHeatmap);
  const showEma = useTradingStore((s) => s.showEma);
  const showRsi = useTradingStore((s) => s.showRsi);
  const showBollinger = useTradingStore((s) => s.showBollinger);
  const showVwap = useTradingStore((s) => s.showVwap);
  const showVolumeBars = useTradingStore((s) => s.showVolumeBars);
  const showCVD = useTradingStore((s) => s.showCVD);
  const showReplay = useTradingStore((s) => s.showReplay);
  const replayCursor = useTradingStore((s) => s.replayCursor);
  const replaySpeed = useTradingStore((s) => s.replaySpeed);
  const isPlaying = useTradingStore((s) => s.isPlaying);
  const tool = useTradingStore((s) => s.tool);
  const trendLines = useTradingStore((s) => s.trendLines);
  const fibZones = useTradingStore((s) => s.fibZones);
  const hLines = useTradingStore((s) => s.hLines);
  const draftPoint = useTradingStore((s) => s.draftPoint);
  const hoverIndex = useTradingStore((s) => s.hoverIndex);
  const hoverX = useTradingStore((s) => s.hoverX);
  const hoverY = useTradingStore((s) => s.hoverY);
  const setHover = useTradingStore((s) => s.setHover);
  const setReplay = useTradingStore((s) => s.setReplay);
  const setReplayCursor = useTradingStore((s) => s.setReplayCursor);
  const setReplaySpeed = useTradingStore((s) => s.setReplaySpeed);
  const setIsPlaying = useTradingStore((s) => s.setIsPlaying);
  const addTrendLine = useTradingStore((s) => s.addTrendLine);
  const addFibZone = useTradingStore((s) => s.addFibZone);
  const addHLine = useTradingStore((s) => s.addHLine);
  const setDraftPoint = useTradingStore((s) => s.setDraftPoint);

  // ── Store (new indicator toggles) ─────────────────────────────────
  const showSuperTrend = useTradingStore((s) => s.showSuperTrend);
  const showMacd = useTradingStore((s) => s.showMacd);
  const showStochastic = useTradingStore((s) => s.showStochastic);
  const showIchimoku = useTradingStore((s) => s.showIchimoku);
  const showAlligator = useTradingStore((s) => s.showAlligator);
  const showParabolicSar = useTradingStore((s) => s.showParabolicSar);
  const showAtr = useTradingStore((s) => s.showAtr);
  const showKeltner = useTradingStore((s) => s.showKeltner);
  const showDonchian = useTradingStore((s) => s.showDonchian);
  const showSqueeze = useTradingStore((s) => s.showSqueeze);
  const showFairValueGap = useTradingStore((s) => s.showFairValueGap);
  const showOrderBlock = useTradingStore((s) => s.showOrderBlock);
  const showFractals = useTradingStore((s) => s.showFractals);
  const showVwma = useTradingStore((s) => s.showVwma);
  const showTDSequential = useTradingStore((s) => s.showTDSequential);

  // ── Store (new overlay toggles) ────────────────────────────────────
  const showAnchoredVwap = useTradingStore((s) => s.showAnchoredVwap);
  const showPocTrail = useTradingStore((s) => s.showPocTrail);
  const showVolumeMa = useTradingStore((s) => s.showVolumeMa);
  const showVolumeNodes = useTradingStore((s) => s.showVolumeNodes);
  const volumeMode = useTradingStore((s) => s.volumeMode);
  const anchorIndex = useTradingStore((s) => s.anchorIndex);
  const setAnchorIndex = useTradingStore((s) => s.setAnchorIndex);
  const setVolumeMode = useTradingStore((s) => s.setVolumeMode);

  // ── ResizeObserver ─────────────────────────────────────────────────
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const ro = new ResizeObserver(([entry]) => {
      const { width, height } = entry.contentRect;
      if (width > 10 && height > 10) {
        setDims({ w: Math.round(width), h: Math.round(height) });
      }
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // ── Visible candles ────────────────────────────────────────────────
  const visibleCandles = useMemo<Candle[]>(() => {
    if (candles.length === 0) return [];
    if (showReplay) {
      return candles.slice(0, clamp(replayCursor, 1, candles.length));
    }
    return candles;
  }, [candles, showReplay, replayCursor]);

  // ── Computed stats & indicators (original) ─────────────────────────
  const closes = useMemo(
    () => visibleCandles.map((c) => c.close),
    [visibleCandles]
  );
  const ema20 = useMemo(() => computeEma(closes, 20), [closes]);
  const ema50 = useMemo(() => computeEma(closes, 50), [closes]);
  const rsi = useMemo(() => computeRsi(closes, 14), [closes]);
  const boll = useMemo(() => computeBollinger(closes, 20, 2), [closes]);
  const vwap = useMemo(() => computeVwap(visibleCandles), [visibleCandles]);
  const cvd = useMemo(() => computeCumulativeDelta(visibleCandles), [visibleCandles]);

  // ── New indicator computations (guarded by toggles) ────────────────
  const superTrend = useMemo(
    () =>
      showSuperTrend && visibleCandles.length > 0
        ? computeSuperTrend(visibleCandles)
        : null,
    [visibleCandles, showSuperTrend]
  );

  const macdData = useMemo(
    () =>
      showMacd && visibleCandles.length > 0 ? computeMACD(visibleCandles) : null,
    [visibleCandles, showMacd]
  );

  const stochasticData = useMemo(
    () =>
      showStochastic && visibleCandles.length > 0
        ? computeStochastic(visibleCandles)
        : null,
    [visibleCandles, showStochastic]
  );

  const ichimoku = useMemo(
    () =>
      showIchimoku && visibleCandles.length > 0
        ? computeIchimoku(visibleCandles)
        : null,
    [visibleCandles, showIchimoku]
  );

  const alligator = useMemo(
    () =>
      showAlligator && visibleCandles.length > 0
        ? computeAlligator(visibleCandles)
        : null,
    [visibleCandles, showAlligator]
  );

  const parabolicSar = useMemo(
    () =>
      showParabolicSar && visibleCandles.length > 0
        ? computeParabolicSAR(visibleCandles)
        : null,
    [visibleCandles, showParabolicSar]
  );

  const keltner = useMemo(
    () =>
      showKeltner && visibleCandles.length > 0
        ? computeKeltnerChannel(visibleCandles)
        : null,
    [visibleCandles, showKeltner]
  );

  const donchian = useMemo(
    () =>
      showDonchian && visibleCandles.length > 0
        ? computeDonchianChannel(visibleCandles)
        : null,
    [visibleCandles, showDonchian]
  );

  const squeezeData = useMemo(
    () =>
      showSqueeze && visibleCandles.length > 0
        ? computeSqueezeMomentum(visibleCandles)
        : null,
    [visibleCandles, showSqueeze]
  );

  const fairValueGaps = useMemo(
    () =>
      showFairValueGap && visibleCandles.length > 2
        ? computeFairValueGap(visibleCandles)
        : [],
    [visibleCandles, showFairValueGap]
  );

  const orderBlocks = useMemo(
    () =>
      showOrderBlock && visibleCandles.length > 10
        ? computeOrderBlock(visibleCandles)
        : [],
    [visibleCandles, showOrderBlock]
  );

  const fractals = useMemo(
    () =>
      showFractals && visibleCandles.length > 4
        ? computeFractals(visibleCandles)
        : null,
    [visibleCandles, showFractals]
  );

  const vwma = useMemo(
    () =>
      showVwma && visibleCandles.length > 0
        ? computeVWMA(visibleCandles)
        : null,
    [visibleCandles, showVwma]
  );

  const atrValues = useMemo(
    () =>
      showAtr && visibleCandles.length > 0 ? computeATR(visibleCandles) : null,
    [visibleCandles, showAtr]
  );

  const tdSequential = useMemo(
    () =>
      showTDSequential && visibleCandles.length > 4
        ? computeTDSequential(visibleCandles)
        : null,
    [visibleCandles, showTDSequential]
  );

  // ── Anchored VWAP computation ──────────────────────────────────────
  const anchoredVwap = useMemo(() => {
    const len = visibleCandles.length;
    if (!showAnchoredVwap || anchorIndex == null || anchorIndex < 0 || anchorIndex >= len) return null;
    const result: number[] = new Array(len).fill(0);
    let pv = 0;
    let vv = 0;
    for (let i = anchorIndex; i < len; i++) {
      const c = visibleCandles[i];
      const typical = (c.high + c.low + c.close) / 3;
      pv += typical * c.volume;
      vv += c.volume;
      result[i] = vv > 0 ? pv / vv : 0;
    }
    return result;
  }, [showAnchoredVwap, anchorIndex, visibleCandles]);

  // ── POC Trail computation ──────────────────────────────────────────
  const pocTrail = useMemo(() => {
    const len = visibleCandles.length;
    if (!showPocTrail || len < 26) return null;
    const result: number[] = new Array(len).fill(0);
    for (let i = 25; i < len; i++) {
      let minP = Infinity;
      let maxP = -Infinity;
      for (let j = i - 25; j <= i; j++) {
        if (visibleCandles[j].low < minP) minP = visibleCandles[j].low;
        if (visibleCandles[j].high > maxP) maxP = visibleCandles[j].high;
      }
      const bins = 24;
      const step = (maxP - minP) / bins || 1;
      const volAtLevel: number[] = new Array(bins).fill(0);
      for (let j = i - 25; j <= i; j++) {
        const c = visibleCandles[j];
        for (let b = 0; b < bins; b++) {
          const bL = minP + b * step;
          const bH = bL + step;
          if (c.high >= bL && c.low <= bH) volAtLevel[b] += c.volume;
        }
      }
      let maxVol = 0;
      let maxBin = 0;
      for (let b = 0; b < bins; b++) {
        if (volAtLevel[b] > maxVol) { maxVol = volAtLevel[b]; maxBin = b; }
      }
      result[i] = minP + (maxBin + 0.5) * step;
    }
    return result;
  }, [showPocTrail, visibleCandles]);

  // ── Volume MA (SMA-20) ────────────────────────────────────────────
  const volumeMa = useMemo(() => {
    const len = visibleCandles.length;
    if (!showVolumeMa || len < 20) return null;
    const result: number[] = new Array(len).fill(0);
    for (let i = 19; i < len; i++) {
      let sum = 0;
      for (let j = i - 19; j <= i; j++) sum += visibleCandles[j].volume;
      result[i] = sum / 20;
    }
    return result;
  }, [showVolumeMa, visibleCandles]);

  // ── Volume Nodes ──────────────────────────────────────────────────
  const volumeNodes = useMemo(() => {
    if (!showVolumeNodes || visibleCandles.length < 5) return [];
    let minP = Infinity;
    let maxP = -Infinity;
    for (const c of visibleCandles) {
      if (c.low < minP) minP = c.low;
      if (c.high > maxP) maxP = c.high;
    }
    const bins = 32;
    const step = (maxP - minP) / bins || 1;
    const profile: number[] = new Array(bins).fill(0);
    for (const c of visibleCandles) {
      for (let i = 0; i < bins; i++) {
        const bp = minP + i * step + step / 2;
        if (c.low <= bp && c.high >= bp) profile[i] += c.volume;
      }
    }
    const avgVol = profile.reduce((a, b) => a + b, 0) / bins;
    const threshold = avgVol * 1.5;
    const nodes: number[] = [];
    for (let i = 0; i < bins; i++) {
      if (profile[i] > threshold) nodes.push(minP + i * step + step / 2);
    }
    return nodes;
  }, [showVolumeNodes, visibleCandles]);

  // ── RVOL ──────────────────────────────────────────────────────────
  const rvol = useMemo(() => {
    const len = visibleCandles.length;
    if (len < 20) return null;
    let sum = 0;
    for (let i = len - 20; i < len; i++) sum += visibleCandles[i].volume;
    const avgVol = sum / 20;
    const curVol = visibleCandles[len - 1].volume;
    return avgVol > 0 ? curVol / avgVol : 1;
  }, [visibleCandles]);

  // ── Price range & scaling ──────────────────────────────────────────
  const priceRange = useMemo(() => {
    if (visibleCandles.length === 0) return { min: 0, max: 1 };
    let min = Infinity;
    let max = -Infinity;
    for (const c of visibleCandles) {
      if (c.low < min) min = c.low;
      if (c.high > max) max = c.high;
    }
    // Include bollinger
    for (let i = 0; i < boll.upper.length; i++) {
      if (boll.upper[i] != null && boll.upper[i]! > max) max = boll.upper[i]!;
      if (boll.lower[i] != null && boll.lower[i]! < min) min = boll.lower[i]!;
    }
    // Include hLines
    for (const h of hLines) {
      if (h.price > max) max = h.price;
      if (h.price < min) min = h.price;
    }
    // Include SuperTrend
    if (superTrend) {
      for (let i = 0; i < superTrend.value.length; i++) {
        if (superTrend.value[i] !== 0) {
          if (superTrend.value[i] > max) max = superTrend.value[i];
          if (superTrend.value[i] < min) min = superTrend.value[i];
        }
      }
    }
    // Include Ichimoku cloud
    if (ichimoku) {
      for (let i = 0; i < ichimoku.cloudTop.length; i++) {
        if (ichimoku.cloudTop[i] > max) max = ichimoku.cloudTop[i];
        if (ichimoku.cloudBottom[i] > 0 && ichimoku.cloudBottom[i] < min)
          min = ichimoku.cloudBottom[i];
      }
    }
    // Include Keltner
    if (keltner) {
      for (let i = 0; i < keltner.upper.length; i++) {
        if (keltner.upper[i] > max) max = keltner.upper[i];
        if (keltner.lower[i] > 0 && keltner.lower[i] < min)
          min = keltner.lower[i];
      }
    }
    // Include Donchian
    if (donchian) {
      for (let i = 0; i < donchian.upper.length; i++) {
        if (donchian.upper[i] > max) max = donchian.upper[i];
        if (donchian.lower[i] > 0 && donchian.lower[i] < min)
          min = donchian.lower[i];
      }
    }
    // Include Parabolic SAR
    if (parabolicSar) {
      for (let i = 0; i < parabolicSar.length; i++) {
        if (parabolicSar[i] > max) max = parabolicSar[i];
        if (parabolicSar[i] > 0 && parabolicSar[i] < min) min = parabolicSar[i];
      }
    }
    // Include VWMA
    if (vwma) {
      for (let i = 0; i < vwma.length; i++) {
        if (vwma[i] > 0) {
          if (vwma[i] > max) max = vwma[i];
          if (vwma[i] < min) min = vwma[i];
        }
      }
    }
    // Include Alligator
    if (alligator) {
      for (let i = 0; i < alligator.jaw.length; i++) {
        if (alligator.jaw[i] > 0) {
          if (alligator.jaw[i] > max) max = alligator.jaw[i];
          if (alligator.jaw[i] < min) min = alligator.jaw[i];
        }
        if (alligator.teeth[i] > 0) {
          if (alligator.teeth[i] > max) max = alligator.teeth[i];
          if (alligator.teeth[i] < min) min = alligator.teeth[i];
        }
        if (alligator.lips[i] > 0) {
          if (alligator.lips[i] > max) max = alligator.lips[i];
          if (alligator.lips[i] < min) min = alligator.lips[i];
        }
      }
    }
    // Include FVG zones
    for (const fvg of fairValueGaps) {
      if (fvg.high > max) max = fvg.high;
      if (fvg.low > 0 && fvg.low < min) min = fvg.low;
    }
    // Include Order Block zones
    for (const ob of orderBlocks) {
      if (ob.top > max) max = ob.top;
      if (ob.bottom > 0 && ob.bottom < min) min = ob.bottom;
    }
    // Include Anchored VWAP
    if (anchoredVwap) {
      for (let i = 0; i < anchoredVwap.length; i++) {
        if (anchoredVwap[i] > 0) {
          if (anchoredVwap[i] > max) max = anchoredVwap[i];
          if (anchoredVwap[i] < min) min = anchoredVwap[i];
        }
      }
    }
    // Include POC Trail
    if (pocTrail) {
      for (let i = 0; i < pocTrail.length; i++) {
        if (pocTrail[i] > 0) {
          if (pocTrail[i] > max) max = pocTrail[i];
          if (pocTrail[i] < min) min = pocTrail[i];
        }
      }
    }
    // Include Volume Nodes
    for (const nodePrice of volumeNodes) {
      if (nodePrice > max) max = nodePrice;
      if (nodePrice < min) min = nodePrice;
    }
    const pad = (max - min) * 0.06 || max * 0.002;
    return { min: min - pad, max: max + pad };
  }, [visibleCandles, boll, hLines, superTrend, ichimoku, keltner, donchian, parabolicSar, vwma, alligator, fairValueGaps, orderBlocks, anchoredVwap, pocTrail, volumeNodes]);

  const chartLeft = PAD_L;
  const chartRight = VW - PAD_R;
  const chartWidth = chartRight - chartLeft;
  const chartHeight = CHART_BOTTOM - PAD_T;
  const n = visibleCandles.length;

  const priceToY = useCallback(
    (price: number) => {
      const ratio = (price - priceRange.min) / (priceRange.max - priceRange.min || 1);
      return CHART_BOTTOM - ratio * chartHeight;
    },
    [priceRange, chartHeight]
  );

  const yToPrice = useCallback(
    (y: number) => {
      const ratio = (CHART_BOTTOM - y) / chartHeight;
      return priceRange.min + ratio * (priceRange.max - priceRange.min);
    },
    [priceRange, chartHeight]
  );

  const indexToX = useCallback(
    (idx: number) => {
      if (n <= 1) return chartLeft + chartWidth / 2;
      return chartLeft + (idx / (n - 1)) * chartWidth;
    },
    [n, chartLeft, chartWidth]
  );

  const xToIndex = useCallback(
    (x: number) => {
      const ratio = (x - chartLeft) / chartWidth;
      return Math.round(ratio * (n - 1));
    },
    [n, chartLeft, chartWidth]
  );

  // ── Grid lines ─────────────────────────────────────────────────────
  const gridLines = useMemo(() => {
    const lines: { y: number; label: string }[] = [];
    const range = priceRange.max - priceRange.min;
    const step = range / 8;
    for (let i = 0; i <= 8; i++) {
      const price = priceRange.min + step * i;
      lines.push({ y: priceToY(price), label: formatPrice(price) });
    }
    return lines;
  }, [priceRange, priceToY]);

  const timeGridLines = useMemo(() => {
    const lines: { x: number; label: string }[] = [];
    if (n === 0) return lines;
    const step = Math.max(1, Math.floor(n / 8));
    for (let i = 0; i < n; i += step) {
      lines.push({
        x: indexToX(i),
        label: formatTime(visibleCandles[i].time),
      });
    }
    return lines;
  }, [n, visibleCandles, indexToX]);

  // ── Volume range ───────────────────────────────────────────────────
  const volRange = useMemo(() => {
    if (visibleCandles.length === 0) return 1;
    if (volumeMode === 'delta') {
      return Math.max(...visibleCandles.map((c) => Math.abs(c.delta))) || 1;
    }
    return Math.max(...visibleCandles.map((c) => c.volume)) || 1;
  }, [visibleCandles, volumeMode]);

  // ── CVD range ──────────────────────────────────────────────────────
  const cvdValues = useMemo(() => {
    const vals: number[] = [];
    let cum = 0;
    for (const c of visibleCandles) {
      cum += c.delta;
      vals.push(cum);
    }
    return vals;
  }, [visibleCandles]);

  const cvdRange = useMemo(() => {
    if (cvdValues.length === 0) return { min: -1, max: 1 };
    const min = Math.min(...cvdValues);
    const max = Math.max(...cvdValues);
    const pad = (max - min) * 0.1 || 1;
    return { min: min - pad, max: max + pad };
  }, [cvdValues]);

  // ── EMA paths ──────────────────────────────────────────────────────
  const ema20Path = useMemo(() => {
    const xs: number[] = [];
    const ys: number[] = [];
    for (let i = 0; i < ema20.length; i++) {
      if (ema20[i] != null) {
        xs.push(indexToX(i));
        ys.push(priceToY(ema20[i]!));
      }
    }
    return pathFromSeries(xs, ys);
  }, [ema20, indexToX, priceToY]);

  const ema50Path = useMemo(() => {
    const xs: number[] = [];
    const ys: number[] = [];
    for (let i = 0; i < ema50.length; i++) {
      if (ema50[i] != null) {
        xs.push(indexToX(i));
        ys.push(priceToY(ema50[i]!));
      }
    }
    return pathFromSeries(xs, ys);
  }, [ema50, indexToX, priceToY]);

  // ── Bollinger paths ────────────────────────────────────────────────
  const bollPaths = useMemo(() => {
    const ux: number[] = [];
    const uy: number[] = [];
    const lx: number[] = [];
    const ly: number[] = [];
    const mx: number[] = [];
    const my: number[] = [];
    for (let i = 0; i < boll.upper.length; i++) {
      if (boll.upper[i] != null && boll.lower[i] != null) {
        ux.push(indexToX(i));
        uy.push(priceToY(boll.upper[i]!));
        lx.push(indexToX(i));
        ly.push(priceToY(boll.lower[i]!));
        if (boll.middle[i] != null) {
          mx.push(indexToX(i));
          my.push(priceToY(boll.middle[i]!));
        }
      }
    }
    return {
      upper: pathFromSeries(ux, uy),
      lower: pathFromSeries([...lx].reverse(), [...ly].reverse()),
      fill:
        pathFromSeries(ux, uy) +
        " L " +
        [...lx]
          .reverse()
          .map((x, i) => `${x.toFixed(2)} ${[...ly].reverse()[i].toFixed(2)}`)
          .join(" L ") +
        " Z",
      middle: pathFromSeries(mx, my),
    };
  }, [boll, indexToX, priceToY]);

  // ── Line chart path ────────────────────────────────────────────────
  const linePath = useMemo(() => {
    if (n === 0) return "";
    const xs = visibleCandles.map((_, i) => indexToX(i));
    const ys = visibleCandles.map((c) => priceToY(c.close));
    return pathFromSeries(xs, ys);
  }, [visibleCandles, n, indexToX, priceToY]);

  // ── Delta line path ────────────────────────────────────────────────
  const deltaPath = useMemo(() => {
    if (n === 0) return "";
    const xs: number[] = [];
    const ys: number[] = [];
    for (let i = 0; i < visibleCandles.length; i++) {
      xs.push(indexToX(i));
      const c = visibleCandles[i];
      if (c.delta >= 0) {
        ys.push(priceToY(c.high));
      } else {
        ys.push(priceToY(c.low));
      }
    }
    return pathFromSeries(xs, ys);
  }, [visibleCandles, n, indexToX, priceToY]);

  // ── VWAP Y ─────────────────────────────────────────────────────────
  const vwapY = useMemo(() => priceToY(vwap), [vwap, priceToY]);

  // ── Anchored VWAP path ────────────────────────────────────────────
  const anchoredVwapPath = useMemo(() => {
    if (!anchoredVwap || n === 0) return "";
    const xs: number[] = [];
    const ys: number[] = [];
    for (let i = 0; i < n; i++) {
      if (anchoredVwap[i] > 0) {
        xs.push(indexToX(i));
        ys.push(priceToY(anchoredVwap[i]));
      }
    }
    return pathFromSeries(xs, ys);
  }, [anchoredVwap, n, indexToX, priceToY]);

  // ── POC Trail path ────────────────────────────────────────────────
  const pocTrailPath = useMemo(() => {
    if (!pocTrail || n === 0) return "";
    const xs: number[] = [];
    const ys: number[] = [];
    for (let i = 0; i < n; i++) {
      if (pocTrail[i] > 0) {
        xs.push(indexToX(i));
        ys.push(priceToY(pocTrail[i]));
      }
    }
    return pathFromSeries(xs, ys);
  }, [pocTrail, n, indexToX, priceToY]);

  // ── SuperTrend paths (split by direction) ──────────────────────────
  const superTrendPaths = useMemo(() => {
    if (!superTrend || n === 0) return { up: [] as string[], down: [] as string[] };
    const upPaths: string[] = [];
    const downPaths: string[] = [];
    let curPath = "";
    let curDir: string | null = null;

    for (let i = 0; i < n; i++) {
      if (superTrend.value[i] === 0) continue;
      const x = indexToX(i).toFixed(2);
      const y = priceToY(superTrend.value[i]).toFixed(2);
      const pt = `${x} ${y}`;
      const dir = superTrend.direction[i];

      if (dir !== curDir) {
        if (curPath && curDir) {
          if (curDir === "up") upPaths.push(curPath);
          else downPaths.push(curPath);
        }
        curPath = `M ${pt}`;
        curDir = dir;
      } else {
        curPath += ` L ${pt}`;
      }
    }
    if (curPath && curDir) {
      if (curDir === "up") upPaths.push(curPath);
      else downPaths.push(curPath);
    }
    return { up: upPaths, down: downPaths };
  }, [superTrend, n, indexToX, priceToY]);

  // ── Ichimoku paths ─────────────────────────────────────────────────
  const ichimokuPaths = useMemo(() => {
    if (!ichimoku || n === 0)
      return { conversion: "", base: "" };
    const cx: number[] = [];
    const cy: number[] = [];
    const bx: number[] = [];
    const by: number[] = [];
    for (let i = 0; i < n; i++) {
      if (ichimoku.conversion[i] > 0) {
        cx.push(indexToX(i));
        cy.push(priceToY(ichimoku.conversion[i]));
      }
      if (ichimoku.base[i] > 0) {
        bx.push(indexToX(i));
        by.push(priceToY(ichimoku.base[i]));
      }
    }
    return {
      conversion: pathFromSeries(cx, cy),
      base: pathFromSeries(bx, by),
    };
  }, [ichimoku, n, indexToX, priceToY]);

  // ── Keltner paths ──────────────────────────────────────────────────
  const keltnerPaths = useMemo(() => {
    if (!keltner || n === 0)
      return { upper: "", middle: "", lower: "" };
    const ux: number[] = [];
    const uy: number[] = [];
    const mx: number[] = [];
    const my: number[] = [];
    const lx: number[] = [];
    const ly: number[] = [];
    for (let i = 0; i < n; i++) {
      if (keltner.upper[i] > 0) {
        ux.push(indexToX(i));
        uy.push(priceToY(keltner.upper[i]));
      }
      if (keltner.middle[i] > 0) {
        mx.push(indexToX(i));
        my.push(priceToY(keltner.middle[i]));
      }
      if (keltner.lower[i] > 0) {
        lx.push(indexToX(i));
        ly.push(priceToY(keltner.lower[i]));
      }
    }
    return {
      upper: pathFromSeries(ux, uy),
      middle: pathFromSeries(mx, my),
      lower: pathFromSeries(lx, ly),
    };
  }, [keltner, n, indexToX, priceToY]);

  // ── Donchian paths ─────────────────────────────────────────────────
  const donchianPaths = useMemo(() => {
    if (!donchian || n === 0)
      return { upper: "", middle: "", lower: "" };
    const ux: number[] = [];
    const uy: number[] = [];
    const mx: number[] = [];
    const my: number[] = [];
    const lx: number[] = [];
    const ly: number[] = [];
    for (let i = 0; i < n; i++) {
      if (donchian.upper[i] > 0) {
        ux.push(indexToX(i));
        uy.push(priceToY(donchian.upper[i]));
      }
      if (donchian.middle[i] > 0) {
        mx.push(indexToX(i));
        my.push(priceToY(donchian.middle[i]));
      }
      if (donchian.lower[i] > 0) {
        lx.push(indexToX(i));
        ly.push(priceToY(donchian.lower[i]));
      }
    }
    return {
      upper: pathFromSeries(ux, uy),
      middle: pathFromSeries(mx, my),
      lower: pathFromSeries(lx, ly),
    };
  }, [donchian, n, indexToX, priceToY]);

  // ── Alligator paths ────────────────────────────────────────────────
  const alligatorPaths = useMemo(() => {
    if (!alligator || n === 0)
      return { jaw: "", teeth: "", lips: "" };
    const jx: number[] = [];
    const jy: number[] = [];
    const tx: number[] = [];
    const ty: number[] = [];
    const lx: number[] = [];
    const ly: number[] = [];
    for (let i = 0; i < n; i++) {
      if (alligator.jaw[i] > 0) {
        jx.push(indexToX(i));
        jy.push(priceToY(alligator.jaw[i]));
      }
      if (alligator.teeth[i] > 0) {
        tx.push(indexToX(i));
        ty.push(priceToY(alligator.teeth[i]));
      }
      if (alligator.lips[i] > 0) {
        lx.push(indexToX(i));
        ly.push(priceToY(alligator.lips[i]));
      }
    }
    return {
      jaw: pathFromSeries(jx, jy),
      teeth: pathFromSeries(tx, ty),
      lips: pathFromSeries(lx, ly),
    };
  }, [alligator, n, indexToX, priceToY]);

  // ── VWMA path ──────────────────────────────────────────────────────
  const vwmaPath = useMemo(() => {
    if (!vwma || n === 0) return "";
    const xs: number[] = [];
    const ys: number[] = [];
    for (let i = 0; i < vwma.length; i++) {
      if (vwma[i] > 0) {
        xs.push(indexToX(i));
        ys.push(priceToY(vwma[i]));
      }
    }
    return pathFromSeries(xs, ys);
  }, [vwma, n, indexToX, priceToY]);

  // ── Sub-chart indicator (MACD / Stochastic / Squeeze) ──────────────
  const activeSubChart = useMemo(() => {
    if (showMacd && macdData) return "macd";
    if (showStochastic && stochasticData) return "stochastic";
    if (showSqueeze && squeezeData) return "squeeze";
    return null;
  }, [showMacd, showStochastic, showSqueeze, macdData, stochasticData, squeezeData]);

  const subChartRange = useMemo(() => {
    if (!activeSubChart) return { min: -1, max: 1 };
    if (activeSubChart === "macd" && macdData) {
      const all = [...macdData.macd, ...macdData.signal, ...macdData.histogram];
      const mn = Math.min(...all);
      const mx = Math.max(...all);
      const pad = (mx - mn) * 0.1 || 1;
      return { min: mn - pad, max: mx + pad };
    }
    if (activeSubChart === "stochastic") {
      return { min: 0, max: 100 };
    }
    if (activeSubChart === "squeeze" && squeezeData) {
      const mn = Math.min(...squeezeData.momentum);
      const mx = Math.max(...squeezeData.momentum);
      const pad = (mx - mn) * 0.1 || 1;
      return { min: mn - pad, max: mx + pad };
    }
    return { min: -1, max: 1 };
  }, [activeSubChart, macdData, stochasticData, squeezeData]);

  const subToY = useCallback(
    (value: number) => {
      const ratio =
        (value - subChartRange.min) / (subChartRange.max - subChartRange.min || 1);
      return SUB_BOTTOM - ratio * (SUB_BOTTOM - SUB_TOP);
    },
    [subChartRange]
  );

  // ── Current stats ──────────────────────────────────────────────────
  const lastCandle = visibleCandles[visibleCandles.length - 1];
  const lastEma20 = ema20[ema20.length - 1];
  const lastEma50 = ema50[ema50.length - 1];
  const lastRsi = rsi[rsi.length - 1];
  const lastAtr = atrValues ? atrValues[atrValues.length - 1] : null;

  // ── Heatmap data ───────────────────────────────────────────────────
  const heatmapBands = useMemo(() => {
    if (!showHeatmap || visibleCandles.length < 2) return [];
    const levels = 24;
    const step = (priceRange.max - priceRange.min) / levels;
    const bands: { y: number; h: number; intensity: number }[] = [];
    for (let i = 0; i < levels; i++) {
      const price = priceRange.min + i * step;
      const nextPrice = price + step;
      let buyVol = 0;
      let sellVol = 0;
      for (const c of visibleCandles) {
        if (c.low <= nextPrice && c.high >= price) {
          buyVol += c.buyVolume;
          sellVol += c.sellVolume;
        }
      }
      const total = buyVol + sellVol;
      const delta = total > 0 ? (buyVol - sellVol) / total : 0;
      bands.push({
        y: priceToY(nextPrice),
        h: priceToY(price) - priceToY(nextPrice),
        intensity: delta,
      });
    }
    return bands;
  }, [showHeatmap, visibleCandles, priceRange, priceToY]);

  // ── Mouse handlers ─────────────────────────────────────────────────
  const svgMousePos = useCallback(
    (e: React.MouseEvent<SVGSVGElement>) => {
      const svg = e.currentTarget;
      const rect = svg.getBoundingClientRect();
      const sx = VW / rect.width;
      const sy = VH / rect.height;
      return {
        x: (e.clientX - rect.left) * sx,
        y: (e.clientY - rect.top) * sy,
      };
    },
    []
  );

  const handleMouseMove = useCallback(
    (e: React.MouseEvent<SVGSVGElement>) => {
      const pos = svgMousePos(e);
      const idx = clamp(xToIndex(pos.x), 0, n - 1);
      if (pos.x >= chartLeft && pos.x <= chartRight) {
        setHover(idx, pos.x, pos.y);
      } else {
        setHover(null, pos.x, pos.y);
      }
    },
    [svgMousePos, xToIndex, n, chartLeft, chartRight, setHover]
  );

  const handleMouseLeave = useCallback(() => {
    setHover(null, 0, 0);
  }, [setHover]);

  const handleClick = useCallback(
    (e: React.MouseEvent<SVGSVGElement>) => {
      const pos = svgMousePos(e);
      if (pos.x < chartLeft || pos.x > chartRight) return;
      const idx = clamp(xToIndex(pos.x), 0, n - 1);
      const price = yToPrice(pos.y);

      if (anchorMode && showAnchoredVwap) {
        setAnchorIndex(idx);
        setAnchorMode(false);
        return;
      }
      if (tool === "hline") {
        addHLine({
          id: Date.now(),
          price,
          color: COL_HLINE,
          label: formatPrice(price),
        });
      } else if (tool === "trend" || tool === "fib") {
        if (!draftPoint) {
          setDraftPoint({ index: idx, price });
        } else {
          if (tool === "trend") {
            addTrendLine({
              id: Date.now(),
              start: draftPoint,
              end: { index: idx, price },
              color: "#f5c842",
              width: 1.5,
            });
          } else {
            addFibZone({
              id: Date.now(),
              start: draftPoint,
              end: { index: idx, price },
            });
          }
          setDraftPoint(null);
        }
      }
    },
    [
      svgMousePos,
      chartLeft,
      chartRight,
      xToIndex,
      n,
      yToPrice,
      tool,
      draftPoint,
      addHLine,
      addTrendLine,
      addFibZone,
      setDraftPoint,
      anchorMode,
      showAnchoredVwap,
      setAnchorIndex,
      setAnchorMode,
    ]
  );

  // ── Replay tick ────────────────────────────────────────────────────
  useEffect(() => {
    if (!showReplay || !isPlaying) return;
    const interval = Math.max(50, 800 / replaySpeed);
    const timer = setInterval(() => {
      const store = useTradingStore.getState();
      const cursor = clamp(store.replayCursor + 1, 1, store.candles.length);
      if (cursor >= store.candles.length) {
        useTradingStore.getState().setIsPlaying(false);
        return;
      }
      setReplayCursor(cursor);
    }, interval);
    return () => clearInterval(timer);
  }, [showReplay, isPlaying, replaySpeed, setReplayCursor]);

  // ── Hovered candle ─────────────────────────────────────────────────
  const hovCandle =
    hoverIndex != null && hoverIndex >= 0 && hoverIndex < n
      ? visibleCandles[hoverIndex]
      : null;

  // ─── Render ────────────────────────────────────────────────────────
  if (n === 0) {
    return (
      <div
        className="tpanel flex items-center justify-center w-full h-full text-xs"
        style={{ color: COL_GRID_TEXT }}
      >
        Loading chart data...
      </div>
    );
  }

  const candleW = n > 1 ? chartWidth / n : 8;
  const bodyW = Math.max(1, candleW * 0.65);

  return (
    <div className="relative w-full h-full tpanel" ref={containerRef}>
      {/* ── SVG Chart ──────────────────────────────────────────────── */}
      <svg
        width="100%"
        height="100%"
        viewBox={`0 0 ${VW} ${VH}`}
        preserveAspectRatio="xMidYMid meet"
        className="block select-none"
        style={{ background: "#0a0e17" }}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        onClick={handleClick}
      >
        {/* ── Grid ────────────────────────────────────────────────── */}
        <g>
          {gridLines.map((g, i) => (
            <line
              key={`gh-${i}`}
              x1={chartLeft}
              y1={g.y}
              x2={chartRight}
              y2={g.y}
              stroke={COL_GRID}
              strokeDasharray="3 3"
              strokeWidth={0.5}
            />
          ))}
          {timeGridLines.map((g, i) => (
            <line
              key={`gv-${i}`}
              x1={g.x}
              y1={PAD_T}
              x2={g.x}
              y2={CHART_BOTTOM}
              stroke={COL_GRID}
              strokeDasharray="3 3"
              strokeWidth={0.5}
            />
          ))}
        </g>

        {/* ── Grid labels (price) ─────────────────────────────────── */}
        <g fill={COL_GRID_TEXT} fontSize={9} fontFamily="monospace" textAnchor="end">
          {gridLines.map((g, i) => (
            <text key={`gl-${i}`} x={chartLeft - 4} y={g.y + 3}>
              {g.label}
            </text>
          ))}
        </g>

        {/* ── Grid labels (time) ──────────────────────────────────── */}
        <g fill={COL_GRID_TEXT} fontSize={8} fontFamily="monospace" textAnchor="middle">
          {timeGridLines.map((g, i) => (
            <text key={`gt-${i}`} x={g.x} y={CHART_BOTTOM + 12}>
              {g.label}
            </text>
          ))}
        </g>

        {/* ── Heatmap ─────────────────────────────────────────────── */}
        {heatmapBands.map((band, i) => {
          const color =
            band.intensity > 0
              ? `rgba(25,195,125,${Math.abs(band.intensity) * 0.2})`
              : `rgba(255,95,112,${Math.abs(band.intensity) * 0.2})`;
          return (
            <rect
              key={`hm-${i}`}
              x={chartLeft}
              y={band.y}
              width={chartWidth}
              height={band.h}
              fill={color}
            />
          );
        })}

        {/* ── Ichimoku Cloud fill ─────────────────────────────────── */}
        {showIchimoku &&
          ichimoku &&
          visibleCandles.map((_, i) => {
            if (ichimoku.cloudTop[i] === 0 && ichimoku.cloudBottom[i] === 0)
              return null;
            const kijun = 26;
            const shifted = i - kijun;
            if (shifted < 0) return null;
            const topY = priceToY(ichimoku.cloudTop[i]);
            const botY = priceToY(ichimoku.cloudBottom[i]);
            if (topY === botY) return null;
            const x = indexToX(i);
            const w = i < n - 1 ? indexToX(i + 1) - x + 0.5 : 2;
            const isBull =
              ichimoku.leadA[shifted] >= ichimoku.leadB[shifted];
            return (
              <rect
                key={`ich-cloud-${i}`}
                x={x}
                y={topY}
                width={w}
                height={botY - topY}
                fill={isBull ? COL_ICHIMOKU_BULL : COL_ICHIMOKU_BEAR}
              />
            );
          })}

        {/* ── Fair Value Gaps ─────────────────────────────────────── */}
        {showFairValueGap &&
          fairValueGaps.map((fvg, i) => {
            const x1 = indexToX(fvg.startIndex);
            const x2 = indexToX(Math.min(fvg.endIndex + 20, n - 1));
            const topY = priceToY(fvg.high);
            const botY = priceToY(fvg.low);
            return (
              <rect
                key={`fvg-${i}`}
                x={x1}
                y={topY}
                width={x2 - x1 + 2}
                height={botY - topY}
                fill={
                  fvg.type === "bullish"
                    ? fvg.closed
                      ? "rgba(25,195,125,0.05)"
                      : COL_FVG_BULL
                    : fvg.closed
                      ? "rgba(255,95,112,0.05)"
                      : COL_FVG_BEAR
                }
              />
            );
          })}

        {/* ── Order Blocks ────────────────────────────────────────── */}
        {showOrderBlock &&
          orderBlocks.map((ob, i) => {
            const x1 = indexToX(ob.index);
            const x2 = indexToX(Math.min(ob.index + 30, n - 1));
            const topY = priceToY(ob.top);
            const botY = priceToY(ob.bottom);
            return (
              <rect
                key={`ob-${i}`}
                x={x1}
                y={topY}
                width={x2 - x1 + 2}
                height={botY - topY}
                fill={
                  ob.type === "bullish"
                    ? ob.active
                      ? COL_OB_BULL
                      : "rgba(25,195,125,0.05)"
                    : ob.active
                      ? COL_OB_BEAR
                      : "rgba(255,95,112,0.05)"
                }
                stroke={
                  ob.type === "bullish"
                    ? "rgba(25,195,125,0.3)"
                    : "rgba(255,95,112,0.3)"
                }
                strokeWidth={0.5}
              />
            );
          })}

        {/* ── Bollinger Bands ─────────────────────────────────────── */}
        {showBollinger && bollPaths.fill && (
          <path d={bollPaths.fill} fill={COL_BB_FILL} stroke="none" />
        )}
        {showBollinger && bollPaths.upper && (
          <path d={bollPaths.upper} fill="none" stroke={COL_BB_LINE} strokeWidth={0.7} opacity={0.5} />
        )}
        {showBollinger && bollPaths.lower && (
          <path d={bollPaths.lower} fill="none" stroke={COL_BB_LINE} strokeWidth={0.7} opacity={0.5} />
        )}
        {showBollinger && bollPaths.middle && (
          <path d={bollPaths.middle} fill="none" stroke={COL_BB_LINE} strokeWidth={0.5} opacity={0.3} strokeDasharray="4 2" />
        )}

        {/* ── Keltner Channel ─────────────────────────────────────── */}
        {showKeltner && keltnerPaths.upper && (
          <path d={keltnerPaths.upper} fill="none" stroke={COL_KELTNER} strokeWidth={0.7} />
        )}
        {showKeltner && keltnerPaths.lower && (
          <path d={keltnerPaths.lower} fill="none" stroke={COL_KELTNER} strokeWidth={0.7} />
        )}
        {showKeltner && keltnerPaths.middle && (
          <path d={keltnerPaths.middle} fill="none" stroke={COL_KELTNER} strokeWidth={0.5} strokeDasharray="4 2" opacity={0.6} />
        )}

        {/* ── Donchian Channel ────────────────────────────────────── */}
        {showDonchian && donchianPaths.upper && (
          <path d={donchianPaths.upper} fill="none" stroke={COL_DONCHIAN} strokeWidth={0.7} />
        )}
        {showDonchian && donchianPaths.lower && (
          <path d={donchianPaths.lower} fill="none" stroke={COL_DONCHIAN} strokeWidth={0.7} />
        )}
        {showDonchian && donchianPaths.middle && (
          <path d={donchianPaths.middle} fill="none" stroke={COL_DONCHIAN} strokeWidth={0.5} strokeDasharray="4 2" opacity={0.6} />
        )}

        {/* ── EMA 20 ──────────────────────────────────────────────── */}
        {showEma && ema20Path && (
          <path d={ema20Path} fill="none" stroke={COL_EMA20} strokeWidth={1} opacity={0.8} />
        )}

        {/* ── EMA 50 ──────────────────────────────────────────────── */}
        {showEma && ema50Path && (
          <path d={ema50Path} fill="none" stroke={COL_EMA50} strokeWidth={1} opacity={0.8} />
        )}

        {/* ── Ichimoku Conversion / Base lines ────────────────────── */}
        {showIchimoku && ichimokuPaths.conversion && (
          <path d={ichimokuPaths.conversion} fill="none" stroke={COL_ICHIMOKU_CONV} strokeWidth={0.8} opacity={0.6} />
        )}
        {showIchimoku && ichimokuPaths.base && (
          <path d={ichimokuPaths.base} fill="none" stroke={COL_ICHIMOKU_BASE} strokeWidth={0.8} opacity={0.6} />
        )}

        {/* ── Candlesticks / Line / Delta ─────────────────────────── */}
        {chartType === "candle" &&
          visibleCandles.map((c, i) => {
            const x = indexToX(i);
            const isBull = c.close >= c.open;
            const col = isBull ? COL_BULL : COL_BEAR;
            const oY = priceToY(c.open);
            const cY = priceToY(c.close);
            const hY = priceToY(c.high);
            const lY = priceToY(c.low);
            const bodyTop = Math.min(oY, cY);
            const bodyH = Math.max(Math.abs(oY - cY), 1);
            return (
              <g key={`c-${i}`}>
                <line x1={x} y1={hY} x2={x} y2={lY} stroke={col} strokeWidth={Math.max(0.8, bodyW * 0.15)} />
                <rect
                  x={x - bodyW / 2}
                  y={bodyTop}
                  width={bodyW}
                  height={bodyH}
                  fill={isBull ? col : col}
                  stroke={col}
                  strokeWidth={0.5}
                  rx={0.5}
                />
              </g>
            );
          })}

        {chartType === "line" && (
          <path d={linePath} fill="none" stroke={COL_BULL} strokeWidth={1.5} />
        )}

        {chartType === "delta" &&
          visibleCandles.map((c, i) => {
            const x = indexToX(i);
            const isBull = c.delta >= 0;
            const col = isBull ? COL_BULL : COL_BEAR;
            const oY = priceToY(c.open);
            const cY = priceToY(c.close);
            const hY = priceToY(c.high);
            const lY = priceToY(c.low);
            const bodyTop = Math.min(oY, cY);
            const bodyH = Math.max(Math.abs(oY - cY), 1);
            const alpha = isBull
              ? clamp(c.delta / 800, 0.3, 1)
              : clamp(-c.delta / 800, 0.3, 1);
            return (
              <g key={`d-${i}`} opacity={alpha}>
                <line x1={x} y1={hY} x2={x} y2={lY} stroke={col} strokeWidth={Math.max(0.8, bodyW * 0.15)} />
                <rect
                  x={x - bodyW / 2}
                  y={bodyTop}
                  width={bodyW}
                  height={bodyH}
                  fill={col}
                  stroke={col}
                  strokeWidth={0.5}
                  rx={0.5}
                />
              </g>
            );
          })}

        {/* ── SuperTrend ──────────────────────────────────────────── */}
        {showSuperTrend &&
          superTrendPaths.up.map((d, i) => (
            <path key={`st-up-${i}`} d={d} fill="none" stroke={COL_SUPERTREND_UP} strokeWidth={1.2} />
          ))}
        {showSuperTrend &&
          superTrendPaths.down.map((d, i) => (
            <path key={`st-dn-${i}`} d={d} fill="none" stroke={COL_SUPERTREND_DN} strokeWidth={1.2} />
          ))}

        {/* ── Alligator ───────────────────────────────────────────── */}
        {showAlligator && alligatorPaths.jaw && (
          <path d={alligatorPaths.jaw} fill="none" stroke={COL_ALLIGATOR_JAW} strokeWidth={1} opacity={0.7} />
        )}
        {showAlligator && alligatorPaths.teeth && (
          <path d={alligatorPaths.teeth} fill="none" stroke={COL_ALLIGATOR_TEETH} strokeWidth={1} opacity={0.7} />
        )}
        {showAlligator && alligatorPaths.lips && (
          <path d={alligatorPaths.lips} fill="none" stroke={COL_ALLIGATOR_LIPS} strokeWidth={1} opacity={0.7} />
        )}

        {/* ── VWMA ────────────────────────────────────────────────── */}
        {showVwma && vwmaPath && (
          <path d={vwmaPath} fill="none" stroke={COL_VWMA} strokeWidth={1} opacity={0.7} />
        )}

        {/* ── Parabolic SAR ───────────────────────────────────────── */}
        {showParabolicSar &&
          parabolicSar &&
          visibleCandles.map((c, i) => {
            const val = parabolicSar[i];
            if (val === 0) return null;
            const x = indexToX(i);
            const y = priceToY(val);
            const isAbove = val > c.close;
            return (
              <circle
                key={`sar-${i}`}
                cx={x}
                cy={y}
                r={2}
                fill={COL_SAR}
                opacity={0.8}
              />
            );
          })}

        {/* ── Fractals ────────────────────────────────────────────── */}
        {showFractals &&
          fractals &&
          visibleCandles.map((c, i) => {
            const upVal = fractals.up[i];
            const dnVal = fractals.down[i];
            const x = indexToX(i);
            const elems: React.ReactNode[] = [];
            if (upVal != null) {
              const y = priceToY(upVal) - 4;
              elems.push(
                <polygon
                  key={`fr-up-${i}`}
                  points={`${x},${y + 7} ${x - 3},${y} ${x + 3},${y}`}
                  fill={COL_FRACTAL_UP}
                  opacity={0.8}
                />
              );
            }
            if (dnVal != null) {
              const y = priceToY(dnVal) + 4;
              elems.push(
                <polygon
                  key={`fr-dn-${i}`}
                  points={`${x},${y - 7} ${x - 3},${y} ${x + 3},${y}`}
                  fill={COL_FRACTAL_DN}
                  opacity={0.8}
                />
              );
            }
            return elems.length > 0 ? <g key={`fr-${i}`}>{elems}</g> : null;
          })}

        {/* ── TD Sequential ───────────────────────────────────────── */}
        {showTDSequential &&
          tdSequential &&
          visibleCandles.map((c, i) => {
            const buyC = tdSequential.buyCount[i];
            const sellC = tdSequential.sellCount[i];
            const x = indexToX(i);
            const elems: React.ReactNode[] = [];
            if (buyC >= 1 && buyC <= 9) {
              const y = priceToY(c.high) - 10;
              elems.push(
                <text
                  key={`td-buy-${i}`}
                  x={x}
                  y={y}
                  fill={COL_TD_SEQ}
                  fontSize={7}
                  fontFamily="monospace"
                  textAnchor="middle"
                  fontWeight={buyC === 9 ? "bold" : "normal"}
                >
                  {buyC}
                </text>
              );
            }
            if (sellC >= 1 && sellC <= 9) {
              const y = priceToY(c.low) + 14;
              elems.push(
                <text
                  key={`td-sell-${i}`}
                  x={x}
                  y={y}
                  fill={COL_TD_SEQ}
                  fontSize={7}
                  fontFamily="monospace"
                  textAnchor="middle"
                  fontWeight={sellC === 9 ? "bold" : "normal"}
                >
                  {sellC}
                </text>
              );
            }
            return elems.length > 0 ? <g key={`td-${i}`}>{elems}</g> : null;
          })}

        {/* ── VWAP ────────────────────────────────────────────────── */}
        {showVwap && (
          <line
            x1={chartLeft}
            y1={vwapY}
            x2={chartRight}
            y2={vwapY}
            stroke={COL_VWAP}
            strokeWidth={1}
            strokeDasharray="6 3"
            opacity={0.7}
          />
        )}
        {showVwap && (
          <text
            x={chartRight + 2}
            y={vwapY + 3}
            fill={COL_VWAP}
            fontSize={8}
            fontFamily="monospace"
          >
            VWAP
          </text>
        )}

        {/* ── Anchored VWAP ─────────────────────────────────────────── */}
        {showAnchoredVwap && anchoredVwapPath && (
          <path d={anchoredVwapPath} fill="none" stroke={COL_AVWAP} strokeWidth={1} strokeDasharray="6 3" opacity={0.8} />
        )}
        {showAnchoredVwap && anchoredVwap && anchorIndex != null && anchorIndex >= 0 && anchorIndex < n && (
          <>
            <polygon
              points={`${indexToX(anchorIndex)},${priceToY(anchoredVwap[anchorIndex] || visibleCandles[anchorIndex].close) - 6} ${indexToX(anchorIndex) - 4},${priceToY(anchoredVwap[anchorIndex] || visibleCandles[anchorIndex].close) + 2} ${indexToX(anchorIndex) + 4},${priceToY(anchoredVwap[anchorIndex] || visibleCandles[anchorIndex].close) + 2}`}
              fill={COL_AVWAP}
              opacity={0.9}
            />
            {anchoredVwap[n - 1] > 0 && (
              <text
                x={chartRight + 2}
                y={priceToY(anchoredVwap[n - 1]) + 3}
                fill={COL_AVWAP}
                fontSize={8}
                fontFamily="monospace"
              >
                AVWAP
              </text>
            )}
          </>
        )}

        {/* ── POC Trail ─────────────────────────────────────────────── */}
        {showPocTrail && pocTrailPath && (
          <path d={pocTrailPath} fill="none" stroke={COL_POC_TRAIL} strokeWidth={0.8} strokeDasharray="4 2" opacity={0.7} />
        )}
        {showPocTrail && pocTrail && pocTrail[n - 1] > 0 && (
          <text
            x={chartRight + 2}
            y={priceToY(pocTrail[n - 1]) + 3}
            fill={COL_POC_TRAIL}
            fontSize={8}
            fontFamily="monospace"
          >
            POC
          </text>
        )}

        {/* ── Volume Nodes ─────────────────────────────────────────── */}
        {showVolumeNodes && volumeNodes.map((price, i) => {
          const y = priceToY(price);
          return (
            <g key={`vn-${i}`}>
              <line
                x1={chartLeft}
                y1={y}
                x2={chartRight}
                y2={y}
                stroke={COL_VOL_NODES}
                strokeDasharray="3 3"
                strokeWidth={0.5}
              />
              <text
                x={chartRight + 2}
                y={y + 3}
                fill="rgba(246,180,70,0.6)"
                fontSize={7}
                fontFamily="monospace"
              >
                V
              </text>
            </g>
          );
        })}

        {/* ── Trend Lines ─────────────────────────────────────────── */}
        {trendLines.map((tl) => {
          const x1 = indexToX(tl.start.index);
          const y1 = priceToY(tl.start.price);
          const x2 = indexToX(tl.end.index);
          const y2 = priceToY(tl.end.price);
          return (
            <line
              key={`tl-${tl.id}`}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke={tl.color}
              strokeWidth={tl.width}
            />
          );
        })}

        {/* ── Fibonacci Zones ─────────────────────────────────────── */}
        {fibZones.map((fz) => {
          const x1 = indexToX(fz.start.index);
          const x2 = indexToX(fz.end.index);
          const pStart = fz.start.price;
          const pEnd = fz.end.price;
          const span = pEnd - pStart;
          return (
            <g key={`fib-${fz.id}`}>
              {FIB_LEVELS.map((level, li) => {
                const price = pStart + span * level;
                const y = priceToY(price);
                return (
                  <g key={`fibl-${li}`}>
                    <rect
                      x={x1}
                      y={y - (CHART_BOTTOM - PAD_T) * 0.005}
                      width={x2 - x1}
                      height={(CHART_BOTTOM - PAD_T) * 0.01}
                      fill={COL_FIB}
                    />
                    <text
                      x={x2 + 4}
                      y={y + 3}
                      fill={COL_GRID_TEXT}
                      fontSize={7}
                      fontFamily="monospace"
                    >
                      {(level * 100).toFixed(1)}% {formatPrice(price)}
                    </text>
                  </g>
                );
              })}
            </g>
          );
        })}

        {/* ── Horizontal Lines ────────────────────────────────────── */}
        {hLines.map((hl) => {
          const y = priceToY(hl.price);
          return (
            <g key={`hl-${hl.id}`}>
              <line
                x1={chartLeft}
                y1={y}
                x2={chartRight}
                y2={y}
                stroke={hl.color}
                strokeWidth={0.8}
                strokeDasharray="4 3"
              />
              <text
                x={chartRight + 2}
                y={y + 3}
                fill={COL_GRID_TEXT}
                fontSize={8}
                fontFamily="monospace"
              >
                {hl.label}
              </text>
            </g>
          );
        })}

        {/* ── Drawing preview (draft) ─────────────────────────────── */}
        {draftPoint && hoverIndex != null && (tool === "trend" || tool === "fib") && (
          <>
            <line
              x1={indexToX(draftPoint.index)}
              y1={priceToY(draftPoint.price)}
              x2={hoverX}
              y2={hoverY}
              stroke="rgba(245,200,66,0.5)"
              strokeWidth={1}
              strokeDasharray="4 2"
            />
          </>
        )}

        {/* ── Crosshair ───────────────────────────────────────────── */}
        {hoverIndex != null && hoverX >= chartLeft && hoverX <= chartRight && (
          <g pointerEvents="none">
            <line
              x1={hoverX}
              y1={PAD_T}
              x2={hoverX}
              y2={CHART_BOTTOM}
              stroke={COL_CROSSHAIR}
              strokeWidth={0.5}
            />
            <line
              x1={chartLeft}
              y1={hoverY}
              x2={chartRight}
              y2={hoverY}
              stroke={COL_CROSSHAIR}
              strokeWidth={0.5}
            />
            {/* Price label on y-axis */}
            <rect
              x={chartLeft - 2}
              y={hoverY - 7}
              width={chartLeft - 2}
              height={14}
              fill="#1e293b"
              rx={2}
            />
            <text
              x={chartLeft - 5}
              y={hoverY + 3}
              fill="#e2e8f0"
              fontSize={9}
              fontFamily="monospace"
              textAnchor="end"
            >
              {formatPrice(yToPrice(hoverY))}
            </text>
          </g>
        )}

        {/* ── Separator: volume area ──────────────────────────────── */}
        {showVolumeBars && (
          <line
            x1={chartLeft}
            y1={VOL_TOP - 2}
            x2={chartRight}
            y2={VOL_TOP - 2}
            stroke={COL_GRID}
            strokeWidth={0.5}
          />
        )}

        {/* ── Volume Bars (total mode) ─────────────────────────────── */}
        {showVolumeBars && volumeMode === 'total' &&
          visibleCandles.map((c, i) => {
            const x = indexToX(i);
            const isBull = c.close >= c.open;
            const barH = (c.volume / volRange) * (VOL_BOTTOM - VOL_TOP);
            return (
              <rect
                key={`vol-${i}`}
                x={x - bodyW / 2}
                y={VOL_BOTTOM - barH}
                width={bodyW}
                height={barH}
                fill={isBull ? COL_BULL_DIM : COL_BEAR_DIM}
                rx={0.3}
              />
            );
          })}

        {/* ── Volume Bars (split mode) ─────────────────────────────── */}
        {showVolumeBars && volumeMode === 'split' &&
          visibleCandles.map((c, i) => {
            const x = indexToX(i);
            const totalH = (c.volume / volRange) * (VOL_BOTTOM - VOL_TOP);
            const buyH = (c.buyVolume / volRange) * (VOL_BOTTOM - VOL_TOP);
            return (
              <g key={`vol-${i}`}>
                <rect
                  x={x - bodyW / 2}
                  y={VOL_BOTTOM - totalH}
                  width={bodyW}
                  height={totalH}
                  fill={COL_VOL_SPLIT_SELL}
                  rx={0.3}
                />
                <rect
                  x={x - bodyW / 2}
                  y={VOL_BOTTOM - buyH}
                  width={bodyW}
                  height={buyH}
                  fill={COL_VOL_SPLIT_BUY}
                  rx={0.3}
                />
              </g>
            );
          })}

        {/* ── Volume Bars (delta mode) ──────────────────────────────── */}
        {showVolumeBars && volumeMode === 'delta' &&
          visibleCandles.map((c, i) => {
            const x = indexToX(i);
            const isPos = c.delta >= 0;
            const barH = (Math.abs(c.delta) / volRange) * (VOL_BOTTOM - VOL_TOP);
            return (
              <rect
                key={`vol-${i}`}
                x={x - bodyW / 2}
                y={VOL_BOTTOM - barH}
                width={bodyW}
                height={barH}
                fill={isPos ? "rgba(25,195,125,0.5)" : "rgba(255,95,112,0.5)"}
                rx={0.3}
              />
            );
          })}

        {/* ── Volume MA overlay ─────────────────────────────────────── */}
        {showVolumeBars && showVolumeMa && volumeMa && (
          <path
            d={pathFromSeries(
              volumeMa.map((_, i) => indexToX(i)),
              volumeMa.map((v) => VOL_BOTTOM - (v / volRange) * (VOL_BOTTOM - VOL_TOP))
            )}
            fill="none"
            stroke={COL_VOL_MA}
            strokeWidth={0.8}
          />
        )}

        {/* ── Volume label ──────────────────────────────────────────── */}
        {showVolumeBars && (
          <text x={chartLeft + 2} y={VOL_TOP + 9} fill={COL_GRID_TEXT} fontSize={7} fontFamily="monospace">
            VOL
          </text>
        )}

        {/* ── Volume Mode Selector ──────────────────────────────────── */}
        {showVolumeBars && (
          <g>
            {(['total', 'split', 'delta'] as const).map((mode, mi) => {
              const bx = chartLeft + 28 + mi * 16;
              const by = VOL_TOP;
              return (
                <g key={`vmode-${mode}`} onClick={(e) => { e.stopPropagation(); setVolumeMode(mode); }} style={{ cursor: 'pointer' }}>
                  <rect
                    x={bx}
                    y={by}
                    width={14}
                    height={11}
                    rx={2}
                    fill={volumeMode === mode ? "rgba(255,255,255,0.12)" : "rgba(255,255,255,0.03)"}
                    stroke={volumeMode === mode ? "rgba(255,255,255,0.2)" : "none"}
                    strokeWidth={0.5}
                  />
                  <text
                    x={bx + 7}
                    y={by + 8.5}
                    fill={volumeMode === mode ? "#ccc" : "rgba(255,255,255,0.3)"}
                    fontSize={7}
                    fontFamily="monospace"
                    textAnchor="middle"
                    fontWeight={volumeMode === mode ? "bold" : "normal"}
                  >
                    {mode === 'total' ? 'T' : mode === 'split' ? 'S' : 'D'}
                  </text>
                </g>
              );
            })}
          </g>
        )}

        {/* ── Separator: CVD area ─────────────────────────────────── */}
        {showCVD && (
          <line
            x1={chartLeft}
            y1={CVD_TOP - 2}
            x2={chartRight}
            y2={CVD_TOP - 2}
            stroke={COL_GRID}
            strokeWidth={0.5}
          />
        )}

        {/* ── CVD Bars ────────────────────────────────────────────── */}
        {showCVD && (
          <g>
            {/* CVD zero line */}
            <line
              x1={chartLeft}
              y1={
                CVD_TOP +
                ((cvdRange.max - 0) / (cvdRange.max - cvdRange.min || 1)) *
                  (CVD_BOTTOM - CVD_TOP)
              }
              x2={chartRight}
              y2={
                CVD_TOP +
                ((cvdRange.max - 0) / (cvdRange.max - cvdRange.min || 1)) *
                  (CVD_BOTTOM - CVD_TOP)
              }
              stroke={COL_GRID}
              strokeWidth={0.5}
              strokeDasharray="2 2"
            />
            {cvdValues.map((val, i) => {
              const x = indexToX(i);
              const barH =
                (Math.abs(val) / (cvdRange.max - cvdRange.min || 1)) *
                (CVD_BOTTOM - CVD_TOP);
              const isPos = val >= 0;
              const zeroY =
                CVD_TOP +
                ((cvdRange.max - 0) / (cvdRange.max - cvdRange.min || 1)) *
                  (CVD_BOTTOM - CVD_TOP);
              return (
                <rect
                  key={`cvd-${i}`}
                  x={x - bodyW / 2}
                  y={isPos ? zeroY - barH : zeroY}
                  width={bodyW}
                  height={barH}
                  fill={isPos ? "rgba(25,195,125,0.45)" : "rgba(255,95,112,0.45)"}
                  rx={0.3}
                />
              );
            })}
            <text x={chartLeft + 2} y={CVD_TOP + 9} fill={COL_GRID_TEXT} fontSize={7} fontFamily="monospace">
              CVD
            </text>
          </g>
        )}

        {/* ── Separator: Sub-chart area ───────────────────────────── */}
        {activeSubChart && (
          <line
            x1={chartLeft}
            y1={SUB_TOP - 2}
            x2={chartRight}
            y2={SUB_TOP - 2}
            stroke={COL_GRID}
            strokeWidth={0.5}
          />
        )}

        {/* ── Sub-chart: MACD ─────────────────────────────────────── */}
        {activeSubChart === "macd" && macdData && (
          <g>
            {/* Zero line */}
            <line
              x1={chartLeft}
              y1={subToY(0)}
              x2={chartRight}
              y2={subToY(0)}
              stroke={COL_GRID}
              strokeWidth={0.5}
              strokeDasharray="2 2"
            />
            {/* Histogram */}
            {macdData.histogram.map((val, i) => {
              const x = indexToX(i);
              const barH =
                (Math.abs(val) / (subChartRange.max - subChartRange.min || 1)) *
                (SUB_BOTTOM - SUB_TOP);
              const isPos = val >= 0;
              const zeroY = subToY(0);
              return (
                <rect
                  key={`macd-h-${i}`}
                  x={x - bodyW / 2}
                  y={isPos ? zeroY - barH : zeroY}
                  width={bodyW}
                  height={barH}
                  fill={isPos ? "rgba(25,195,125,0.5)" : "rgba(255,95,112,0.5)"}
                  rx={0.3}
                />
              );
            })}
            {/* MACD line */}
            <path
              d={pathFromSeries(
                macdData.macd.map((_, i) => indexToX(i)),
                macdData.macd.map((v) => subToY(v))
              )}
              fill="none"
              stroke={COL_MACD_LINE}
              strokeWidth={0.8}
            />
            {/* Signal line */}
            <path
              d={pathFromSeries(
                macdData.signal.map((_, i) => indexToX(i)),
                macdData.signal.map((v) => subToY(v))
              )}
              fill="none"
              stroke="#d76dff"
              strokeWidth={0.8}
              opacity={0.7}
            />
            <text x={chartLeft + 2} y={SUB_TOP + 9} fill={COL_GRID_TEXT} fontSize={7} fontFamily="monospace">
              MACD
            </text>
          </g>
        )}

        {/* ── Sub-chart: Stochastic ───────────────────────────────── */}
        {activeSubChart === "stochastic" && stochasticData && (
          <g>
            {/* Reference lines */}
            <line x1={chartLeft} y1={subToY(80)} x2={chartRight} y2={subToY(80)} stroke={COL_GRID} strokeWidth={0.3} strokeDasharray="2 2" />
            <line x1={chartLeft} y1={subToY(50)} x2={chartRight} y2={subToY(50)} stroke={COL_GRID} strokeWidth={0.3} strokeDasharray="2 2" />
            <line x1={chartLeft} y1={subToY(20)} x2={chartRight} y2={subToY(20)} stroke={COL_GRID} strokeWidth={0.3} strokeDasharray="2 2" />
            {/* %K line */}
            <path
              d={pathFromSeries(
                stochasticData.k.map((_, i) => indexToX(i)),
                stochasticData.k.map((v) => subToY(v))
              )}
              fill="none"
              stroke={COL_STOCH_K}
              strokeWidth={0.8}
            />
            {/* %D line */}
            <path
              d={pathFromSeries(
                stochasticData.d.map((_, i) => indexToX(i)),
                stochasticData.d.map((v) => subToY(v))
              )}
              fill="none"
              stroke={COL_STOCH_D}
              strokeWidth={0.8}
              opacity={0.7}
            />
            <text x={chartLeft + 2} y={SUB_TOP + 9} fill={COL_GRID_TEXT} fontSize={7} fontFamily="monospace">
              STOCH
            </text>
          </g>
        )}

        {/* ── Sub-chart: Squeeze Momentum ─────────────────────────── */}
        {activeSubChart === "squeeze" && squeezeData && (
          <g>
            {/* Zero line */}
            <line
              x1={chartLeft}
              y1={subToY(0)}
              x2={chartRight}
              y2={subToY(0)}
              stroke={COL_GRID}
              strokeWidth={0.5}
              strokeDasharray="2 2"
            />
            {/* Momentum histogram */}
            {squeezeData.momentum.map((val, i) => {
              const x = indexToX(i);
              const barH =
                (Math.abs(val) / (subChartRange.max - subChartRange.min || 1)) *
                (SUB_BOTTOM - SUB_TOP);
              const isPos = val >= 0;
              const zeroY = subToY(0);
              return (
                <rect
                  key={`sq-h-${i}`}
                  x={x - bodyW / 2}
                  y={isPos ? zeroY - barH : zeroY}
                  width={bodyW}
                  height={barH}
                  fill={isPos ? "rgba(25,195,125,0.5)" : "rgba(255,95,112,0.5)"}
                  rx={0.3}
                />
              );
            })}
            {/* Squeeze dots */}
            {squeezeData.squeeze.map((s, i) => {
              if (s !== "on") return null;
              return (
                <circle
                  key={`sq-dot-${i}`}
                  cx={indexToX(i)}
                  cy={SUB_BOTTOM - 4}
                  r={2}
                  fill="#f6b446"
                  opacity={0.9}
                />
              );
            })}
            <text x={chartLeft + 2} y={SUB_TOP + 9} fill={COL_GRID_TEXT} fontSize={7} fontFamily="monospace">
              SQZ
            </text>
          </g>
        )}
      </svg>

      {/* ── Stats Overlay (top-left) ───────────────────────────────── */}
      <div
        className="absolute top-2 left-2 flex flex-col gap-0.5 pointer-events-none"
        style={{ maxWidth: 380 }}
      >
        <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[10px] font-mono leading-relaxed">
          {/* Symbol & price */}
          <span
            style={{
              color:
                lastCandle?.close >= lastCandle?.open ? COL_BULL : COL_BEAR,
            }}
          >
            {formatPrice(lastCandle?.close ?? 0)}
          </span>
          {showVwap && (
            <span style={{ color: COL_VWAP }}>
              VWAP {formatPrice(vwap)}
            </span>
          )}
          {showEma && lastEma20 != null && (
            <span style={{ color: COL_EMA20 }}>
              EMA20 {formatPrice(lastEma20)}
            </span>
          )}
          {showEma && lastEma50 != null && (
            <span style={{ color: COL_EMA50 }}>
              EMA50 {formatPrice(lastEma50)}
            </span>
          )}
          {showRsi && lastRsi != null && (
            <span
              style={{
                color:
                  lastRsi > 70 ? COL_BEAR : lastRsi < 30 ? COL_BULL : "#a0a0a0",
              }}
            >
              RSI {lastRsi.toFixed(1)}
            </span>
          )}
          {showAtr && lastAtr != null && lastAtr > 0 && (
            <span style={{ color: "#f6b446" }}>
              ATR {formatPrice(lastAtr)}
            </span>
          )}
          {showVwma && vwma && vwma[vwma.length - 1] > 0 && (
            <span style={{ color: COL_VWMA }}>
              VWMA {formatPrice(vwma[vwma.length - 1])}
            </span>
          )}
          <span style={{ color: cvd >= 0 ? COL_BULL : COL_BEAR }}>
            CVD {formatQty(cvd)}
          </span>
          <span style={{ color: "#888" }}>{n} bars</span>
          {rvol != null && (
            <span style={{ color: rvol > 1 ? COL_BULL : COL_BEAR }}>
              RVOL {rvol.toFixed(2)}x
            </span>
          )}
        </div>
      </div>

      {/* ── Tooltip (top-right) ────────────────────────────────────── */}
      {hovCandle && (
        <div
          className="absolute top-2 right-2 rounded-md px-2.5 py-1.5 text-[10px] font-mono leading-relaxed pointer-events-none"
          style={{
            background: "rgba(15,20,30,0.88)",
            border: "1px solid rgba(255,255,255,0.08)",
          }}
        >
          <div style={{ color: "#aab" }}>{formatTime(hovCandle.time)}</div>
          <div className="flex items-center gap-2 mt-0.5">
            <span style={{ color: "#888" }}>O</span>
            <span>{formatPrice(hovCandle.open)}</span>
            <span style={{ color: "#888" }}>H</span>
            <span style={{ color: COL_BULL }}>
              {formatPrice(hovCandle.high)}
            </span>
            <span style={{ color: "#888" }}>L</span>
            <span style={{ color: COL_BEAR }}>
              {formatPrice(hovCandle.low)}
            </span>
            <span style={{ color: "#888" }}>C</span>
            <span>{formatPrice(hovCandle.close)}</span>
          </div>
          <div className="flex items-center gap-2 mt-0.5">
            <span style={{ color: "#888" }}>Vol</span>
            <span>{formatQty(hovCandle.volume)}</span>
            <span style={{ color: "#888" }}>Δ</span>
            <span
              style={{
                color: hovCandle.delta >= 0 ? COL_BULL : COL_BEAR,
              }}
            >
              {formatQty(hovCandle.delta)}
            </span>
          </div>
        </div>
      )}

      {/* ── Replay Strip (bottom-left) ─────────────────────────────── */}
      {showReplay && (
        <div
          className="absolute bottom-2 left-2 flex items-center gap-2 rounded-md px-2 py-1"
          style={{
            background: "rgba(15,20,30,0.9)",
            border: "1px solid rgba(255,255,255,0.08)",
          }}
        >
          <button
            className="text-xs px-1.5 py-0.5 rounded"
            style={{
              color: isPlaying ? COL_BULL : "#888",
              background: "rgba(255,255,255,0.05)",
              border: "none",
              cursor: "pointer",
            }}
            onClick={() => setIsPlaying(!isPlaying)}
            title={isPlaying ? "Pause" : "Play"}
          >
            {isPlaying ? "⏸" : "▶"}
          </button>
          <button
            className="text-xs px-1.5 py-0.5 rounded"
            style={{
              color: "#888",
              background: "rgba(255,255,255,0.05)",
              border: "none",
              cursor: "pointer",
            }}
            onClick={() => {
              const newCursor = clamp(replayCursor - 1, 1, candles.length);
              setReplayCursor(newCursor);
            }}
            title="Step back"
          >
            ◀
          </button>
          <button
            className="text-xs px-1.5 py-0.5 rounded"
            style={{
              color: "#888",
              background: "rgba(255,255,255,0.05)",
              border: "none",
              cursor: "pointer",
            }}
            onClick={() => {
              const newCursor = clamp(replayCursor + 1, 1, candles.length);
              setReplayCursor(newCursor);
            }}
            title="Step forward"
          >
            ▶
          </button>
          <span className="text-[9px] font-mono" style={{ color: "#888" }}>
            {replayCursor}/{candles.length}
          </span>
          <button
            className="text-[9px] font-mono px-1.5 py-0.5 rounded"
            style={{
              color: replaySpeed >= 4 ? COL_BULL : "#888",
              background: "rgba(255,255,255,0.05)",
              border: "none",
              cursor: "pointer",
            }}
            onClick={() => setReplaySpeed(Math.min(replaySpeed + 1, 8))}
            title="Speed up"
          >
            {replaySpeed}x
          </button>
          {/* Progress bar */}
          <div
            className="relative"
            style={{
              width: 80,
              height: 4,
              background: "rgba(255,255,255,0.08)",
              borderRadius: 2,
            }}
          >
            <div
              style={{
                position: "absolute",
                left: 0,
                top: 0,
                height: "100%",
                width: `${(replayCursor / candles.length) * 100}%`,
                background: COL_VWAP,
                borderRadius: 2,
                transition: "width 0.15s",
              }}
            />
          </div>
        </div>
      )}

      {/* ── Anchor Mode Button ────────────────────────────────────── */}
      <button
        className="absolute text-[9px] font-mono px-2 py-1 rounded"
        style={{
          bottom: showReplay ? 34 : 8,
          left: 8,
          color: anchorMode ? COL_AVWAP : (showAnchoredVwap && anchorIndex != null ? "rgba(0,229,255,0.5)" : "#555"),
          background: "rgba(15,20,30,0.85)",
          border: `1px solid ${anchorMode ? "rgba(0,229,255,0.4)" : "rgba(255,255,255,0.06)"}`,
          cursor: "pointer",
        }}
        onClick={() => {
          if (!showAnchoredVwap) {
            useTradingStore.getState().toggleOverlay('showAnchoredVwap');
          }
          setAnchorMode(!anchorMode);
        }}
        title={anchorMode ? "Click a candle to set VWAP anchor" : "Toggle anchor mode for Anchored VWAP"}
      >
        {anchorMode ? "ANCHORING..." : (showAnchoredVwap && anchorIndex != null ? `AVWAP #${anchorIndex}` : "AVWAP")}
      </button>

      {/* ── Replay Toggle (bottom-right) ───────────────────────────── */}
      <button
        className="absolute bottom-2 right-2 text-[9px] font-mono px-2 py-1 rounded"
        style={{
          color: showReplay ? COL_VWAP : "#555",
          background: "rgba(15,20,30,0.85)",
          border: `1px solid ${
            showReplay
              ? "rgba(89,160,255,0.3)"
              : "rgba(255,255,255,0.06)"
          }`,
          cursor: "pointer",
        }}
        onClick={() => {
          if (!showReplay) {
            setReplay(true);
            setReplayCursor(Math.min(100, candles.length));
            setIsPlaying(true);
          } else {
            setReplay(false);
            setIsPlaying(true);
          }
        }}
        title="Toggle replay mode"
      >
        {showReplay ? "REPLAY ON" : "REPLAY"}
      </button>
    </div>
  );
});

export default ChartPanel;
