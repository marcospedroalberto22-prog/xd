"use client";

import { useEffect, useMemo } from "react";
import { useTradingStore } from "@/lib/trading-store";
import type { DataConnection, ConnectionStatus } from "@/lib/trading-types";
import { Plug, Unplug, Wifi, WifiOff } from "lucide-react";

export default function ConnectionsPanel() {
  const connections = useTradingStore((s) => s.connections);
  const toggleConnection = useTradingStore((s) => s.toggleConnection);

  // Simulate connection lifecycle changes for "connecting" -> "connected"
  // and random disconnects for "connected"
  useEffect(() => {
    const interval = setInterval(() => {
      const state = useTradingStore.getState();
      const now = Date.now();

      useTradingStore.setState((s) => ({
        connections: s.connections.map((conn: DataConnection) => {
          // Promote connecting -> connected after ~2s
          if (conn.status === "connecting") {
            const elapsed = now - conn.lastHeartbeat;
            if (elapsed > 2000) {
              return {
                ...conn,
                status: "connected" as ConnectionStatus,
                latency: 25 + Math.floor(Math.random() * 50),
                throughput: 800 + Math.floor(Math.random() * 1500),
                lastHeartbeat: now,
              };
            }
            return conn;
          }

          // Connected connections: fluctuate latency and throughput
          if (conn.status === "connected") {
            // Small random latency fluctuation
            const newLatency = Math.max(8, conn.latency + Math.floor((Math.random() - 0.5) * 10));
            const newThroughput = Math.max(200, conn.throughput + Math.floor((Math.random() - 0.5) * 200));
            // Rare random disconnect (~2% chance per tick)
            const shouldDrop = Math.random() < 0.02;
            if (shouldDrop) {
              return {
                ...conn,
                status: "disconnected" as ConnectionStatus,
                latency: 0,
                throughput: 0,
                reconnects: conn.reconnects + 1,
              };
            }
            return {
              ...conn,
              latency: newLatency,
              throughput: newThroughput,
              lastHeartbeat: now,
            };
          }

          return conn;
        }),
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const statusColor = (status: ConnectionStatus) => {
    switch (status) {
      case "connected": return "status-dot-connected";
      case "connecting": return "status-dot-connecting";
      case "disconnected": return "status-dot-disconnected";
    }
  };

  const statusLabel = (status: ConnectionStatus) => {
    switch (status) {
      case "connected": return "connected";
      case "connecting": return "connecting...";
      case "disconnected": return "offline";
    }
  };

  return (
    <div className="tpanel h-full flex flex-col">
      <div className="tpanel-header">
        <span>Connections</span>
        <span className="mono text-[10px]">
          {connections.filter((c) => c.status === "connected").length}/{connections.length}
        </span>
      </div>

      <div className="tpanel-body flex-1 p-0 flex flex-col">
        {/* Column headers */}
        <div className="flex items-center px-3 py-1.5 text-[10px] text-[#7489a1] uppercase tracking-wider border-b border-[#1b2b3f]">
          <span className="flex-1">Feed</span>
          <span className="w-16 text-center">Status</span>
          <span className="w-14 text-right">Latency</span>
          <span className="w-16 text-right">Msg/s</span>
          <span className="w-8" />
        </div>

        {/* Connection rows */}
        <div className="flex flex-col">
          {connections.map((conn) => {
            const isConnected = conn.status === "connected";
            const isConnecting = conn.status === "connecting";
            return (
              <div
                key={conn.id}
                className="flex items-center px-3 py-3 text-xs border-b border-[#1b2b3f50] hover:bg-[#11273f50] transition-colors"
              >
                {/* Feed name */}
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    {isConnected ? (
                      <Wifi className="w-3.5 h-3.5 text-[#19c37d]" />
                    ) : isConnecting ? (
                      <Plug className="w-3.5 h-3.5 text-[#f6b446]" />
                    ) : (
                      <WifiOff className="w-3.5 h-3.5 text-[#4a6178]" />
                    )}
                    <span className={`font-semibold text-[11px] ${isConnected ? "text-[#d8e0ea]" : "text-[#7489a1]"}`}>
                      {conn.label}
                    </span>
                  </div>
                  {conn.reconnects > 0 && (
                    <div className="flex items-center gap-1 mt-0.5 ml-5.5">
                      <span className="text-[9px] text-[#f6b44680]">
                        {conn.reconnects} reconnect{conn.reconnects > 1 ? "s" : ""}
                      </span>
                    </div>
                  )}
                </div>

                {/* Status */}
                <div className="w-16 flex items-center justify-center gap-1.5">
                  <span className={`status-dot ${statusColor(conn.status)}`} />
                  <span className={`text-[10px] ${
                    conn.status === "connected" ? "text-[#19c37d]" :
                    conn.status === "connecting" ? "text-[#f6b446]" :
                    "text-[#4a6178]"
                  }`}>
                    {statusLabel(conn.status)}
                  </span>
                </div>

                {/* Latency */}
                <span className={`w-14 text-right mono text-[11px] ${
                  conn.latency === 0 ? "text-[#2a4060]" :
                  conn.latency < 40 ? "text-[#19c37d]" :
                  conn.latency < 80 ? "text-[#f6b446]" :
                  "text-[#ff5f70]"
                }`}>
                  {conn.latency > 0 ? `${conn.latency}ms` : "--"}
                </span>

                {/* Throughput */}
                <span className={`w-16 text-right mono text-[11px] ${
                  conn.throughput === 0 ? "text-[#2a4060]" : "text-[#7489a1]"
                }`}>
                  {conn.throughput > 0 ? conn.throughput.toLocaleString() : "--"}
                </span>

                {/* Toggle button */}
                <button
                  onClick={() => toggleConnection(conn.id)}
                  className={`w-6 h-6 flex items-center justify-center rounded transition-all ${
                    isConnected
                      ? "text-[#4a6178] hover:text-[#ff5f70] hover:bg-[rgba(255,95,112,0.1)]"
                      : "text-[#4a6178] hover:text-[#19c37d] hover:bg-[rgba(25,195,125,0.1)]"
                  }`}
                  title={isConnected ? "Disconnect" : "Connect"}
                >
                  {isConnected ? (
                    <Unplug className="w-3.5 h-3.5" />
                  ) : (
                    <Plug className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            );
          })}
        </div>

        {/* Summary */}
        <div className="flex items-center justify-between px-3 py-2.5 bg-[#0e1723] border-t border-[#1b2b3f] mt-auto">
          <span className="text-[10px] text-[#4a6178]">
            Total throughput
          </span>
          <span className="mono text-[11px] text-[#7489a1]">
            {connections.reduce((sum, c) => sum + c.throughput, 0).toLocaleString()} msg/s
          </span>
        </div>
      </div>
    </div>
  );
}
