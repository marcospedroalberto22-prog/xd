"use client";

import { useMemo } from "react";
import { useTradingStore } from "@/lib/trading-store";
import { formatPrice, formatQty, formatTime } from "@/lib/trading-utils";
import { ScrollText } from "lucide-react";

export default function TapePanel() {
  const tape = useTradingStore((s) => s.tape);

  const stats = useMemo(() => {
    const buys = tape.filter((t) => t.side === "buy");
    const sells = tape.filter((t) => t.side === "sell");
    const blocks = tape.filter((t) => t.isBlock);
    const buyVol = buys.reduce((a, t) => a + t.size, 0);
    const sellVol = sells.reduce((a, t) => a + t.size, 0);
    return {
      buyCount: buys.length,
      sellCount: sells.length,
      blockCount: blocks.length,
      buyVol,
      sellVol,
      totalVol: buyVol + sellVol,
    };
  }, [tape]);

  return (
    <div className="tpanel h-full flex flex-col">
      <div className="tpanel-header">
        <div className="flex items-center gap-2">
          <ScrollText size={12} className="text-[#59a0ff]" />
          <span>TIME &amp; SALES</span>
        </div>
        <div className="flex items-center gap-3 text-[10px]">
          <span className="text-[#19c37d]">
            {stats.buyCount}B ({formatQty(stats.buyVol)})
          </span>
          <span className="text-[#ff5f70]">
            {stats.sellCount}S ({formatQty(stats.sellVol)})
          </span>
          {stats.blockCount > 0 && (
            <span className="text-amber-400">
              {stats.blockCount} blocks
            </span>
          )}
        </div>
      </div>

      <div className="tpanel-body flex-1 p-0">
        {/* Column headers */}
        <div className="flex items-center px-2 py-1 text-[9px] uppercase tracking-wider text-[#7489a1] border-b border-[#1b2b3f]/50 sticky top-0 bg-[#0a121d] z-10">
          <div className="w-[68px] text-left pl-1">Time</div>
          <div className="w-[76px] text-right pr-2">Price</div>
          <div className="w-[52px] text-right">Size</div>
          <div className="w-[28px] text-center">Side</div>
          <div className="flex-1" />
        </div>

        <div className="max-h-[300px] overflow-y-auto tape-scroll">
          {tape.length === 0 ? (
            <div className="flex items-center justify-center h-32 text-[#7489a1] text-xs">
              No trades
            </div>
          ) : (
            tape.map((trade, i) => {
              const isBuy = trade.side === "buy";
              const isBlock = trade.isBlock;

              return (
                <div
                  key={i}
                  className={`
                    flex items-center px-2 text-[11px] mono border-b border-[#1b2b3f]/20
                    ${isBlock ? "bg-amber-500/[0.06]" : ""}
                    ${isBuy ? "hover:bg-[#19c37d]/[0.04]" : "hover:bg-[#ff5f70]/[0.04]"}
                    transition-colors
                  `}
                >
                  {/* Time */}
                  <div className="w-[68px] text-left pl-1 text-[#7489a1] text-[10px]">
                    {formatTime(trade.time)}
                  </div>

                  {/* Price */}
                  <div
                    className={`w-[76px] text-right pr-2 font-medium ${
                      isBuy ? "text-[#19c37d]" : "text-[#ff5f70]"
                    }`}
                  >
                    {formatPrice(trade.price)}
                  </div>

                  {/* Size */}
                  <div
                    className={`w-[52px] text-right ${
                      isBlock
                        ? "text-amber-400 font-semibold"
                        : "text-[#d8e0ea]"
                    }`}
                  >
                    {formatQty(trade.size)}
                  </div>

                  {/* Side indicator */}
                  <div className="w-[28px] text-center">
                    {isBlock ? (
                      <span className="inline-block text-[8px] px-1 py-[1px] rounded bg-amber-500/15 text-amber-400 font-bold border border-amber-500/20">
                        ⬤
                      </span>
                    ) : (
                      <span
                        className={`inline-block w-[8px] h-[8px] rounded-full ${
                          isBuy ? "bg-[#19c37d]" : "bg-[#ff5f70]"
                        }`}
                      />
                    )}
                  </div>

                  <div className="flex-1" />
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
