"use client";

import React, { useState, useCallback, useEffect, useRef, useMemo } from "react";
import {
  TrendingUp,
  Gauge,
  Waves,
  BarChart3,
  GitBranch,
  Eye,
  ChevronDown,
  ChevronRight,
  X,
  Search,
  Activity,
  Layers,
  ArrowLeftRight,
  Brain,
  LineChart,
  Mountain,
  Target,
  Zap,
  Flame,
  Droplets,
  Database,
  Fingerprint,
  Scale,
  Box,
  GitMerge,
  Radio,
} from "lucide-react";
import { useTradingStore } from "@/lib/trading-store";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

// ─── Types ─────────────────────────────────────────────────────
interface IndicatorPanelProps {
  open: boolean;
  onClose: () => void;
}

interface IndicatorItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  storeKey?: string; // if backed by zustand store
}

interface IndicatorCategory {
  id: string;
  label: string;
  icon: React.ReactNode;
  color: string;
  indicators: IndicatorItem[];
}

// ─── Indicator Definitions ─────────────────────────────────────
const INDICATOR_CATEGORIES: IndicatorCategory[] = [
  {
    id: "trend",
    label: "Trend",
    icon: <TrendingUp className="w-3.5 h-3.5" />,
    color: "#59a0ff",
    indicators: [
      { id: "ema", label: "EMA", icon: <LineChart className="w-3 h-3" />, storeKey: "showEma" },
      { id: "sma", label: "SMA", icon: <Activity className="w-3 h-3" /> },
      { id: "alligator", label: "Alligator", icon: <Zap className="w-3 h-3" /> },
      { id: "ichimoku", label: "Ichimoku", icon: <Cloud className="w-3 h-3" /> },
      { id: "supertrend", label: "SuperTrend", icon: <TrendingUp className="w-3 h-3" /> },
      { id: "parabolicsar", label: "Parabolic SAR", icon: <Target className="w-3 h-3" /> },
      { id: "adx", label: "ADX", icon: <Gauge className="w-3 h-3" /> },
      { id: "qqe", label: "QQE", icon: <Waves className="w-3 h-3" /> },
      { id: "vwma", label: "VWMA", icon: <Mountain className="w-3 h-3" /> },
    ],
  },
  {
    id: "momentum",
    label: "Momentum",
    icon: <Gauge className="w-3.5 h-3.5" />,
    color: "#f6b446",
    indicators: [
      { id: "rsi", label: "RSI", icon: <Gauge className="w-3 h-3" />, storeKey: "showRsi" },
      { id: "macd", label: "MACD", icon: <Activity className="w-3 h-3" /> },
      { id: "stochastic", label: "Stochastic", icon: <Waves className="w-3 h-3" /> },
      { id: "cci", label: "CCI", icon: <BarChart3 className="w-3 h-3" /> },
      { id: "mfi", label: "MFI", icon: <Droplets className="w-3 h-3" /> },
      { id: "williamsr", label: "Williams %R", icon: <Activity className="w-3 h-3" /> },
      { id: "roc", label: "ROC", icon: <TrendingUp className="w-3 h-3" /> },
      { id: "wavetrend", label: "WaveTrend", icon: <Waves className="w-3 h-3" /> },
      { id: "tdsequential", label: "TD Sequential", icon: <Target className="w-3 h-3" /> },
    ],
  },
  {
    id: "volatility",
    label: "Volatility",
    icon: <Waves className="w-3.5 h-3.5" />,
    color: "#d76dff",
    indicators: [
      { id: "atr", label: "ATR", icon: <Activity className="w-3 h-3" /> },
      { id: "bollinger", label: "Bollinger Bands", icon: <BarChart3 className="w-3 h-3" />, storeKey: "showBollinger" },
      { id: "keltner", label: "Keltner Channel", icon: <Layers className="w-3 h-3" /> },
      { id: "donchian", label: "Donchian Channel", icon: <Scale className="w-3 h-3" /> },
      { id: "bollingersqueeze", label: "Bollinger Squeeze", icon: <Flame className="w-3 h-3" /> },
      { id: "squeezemomentum", label: "Squeeze Momentum", icon: <Zap className="w-3 h-3" /> },
    ],
  },
  {
    id: "volume",
    label: "Volume",
    icon: <BarChart3 className="w-3.5 h-3.5" />,
    color: "#19c37d",
    indicators: [
      { id: "vwap", label: "VWAP", icon: <LineChart className="w-3 h-3" />, storeKey: "showVwap" },
      { id: "obv", label: "OBV", icon: <BarChart3 className="w-3 h-3" /> },
      { id: "cmf", label: "CMF", icon: <Droplets className="w-3 h-3" /> },
      { id: "vzo", label: "VZO", icon: <Activity className="w-3 h-3" /> },
      { id: "cvd", label: "CVD", icon: <Database className="w-3 h-3" />, storeKey: "showCVD" },
    ],
  },
  {
    id: "orderflow",
    label: "Order Flow",
    icon: <GitBranch className="w-3.5 h-3.5" />,
    color: "#ff5f70",
    indicators: [
      { id: "footprint", label: "Footprint", icon: <Fingerprint className="w-3 h-3" />, storeKey: "showFootprint" },
      { id: "volumeprofile", label: "Volume Profile", icon: <BarChart3 className="w-3 h-3" />, storeKey: "showTpo" },
      { id: "imbalanceratio", label: "Imbalance Ratio", icon: <ArrowLeftRight className="w-3 h-3" /> },
      { id: "deltastrength", label: "Delta Strength", icon: <Activity className="w-3 h-3" /> },
      { id: "stackedimbalance", label: "Stacked Imbalance", icon: <Layers className="w-3 h-3" /> },
      { id: "unfinishedauction", label: "Unfinished Auction", icon: <Radio className="w-3 h-3" /> },
    ],
  },
  {
    id: "smartmoney",
    label: "Smart Money",
    icon: <Brain className="w-3.5 h-3.5" />,
    color: "#f6b446",
    indicators: [
      { id: "fairvaluegap", label: "Fair Value Gap", icon: <GitMerge className="w-3 h-3" /> },
      { id: "orderblock", label: "Order Block", icon: <Box className="w-3 h-3" /> },
      { id: "fractals", label: "Fractals", icon: <Target className="w-3 h-3" /> },
      { id: "cumulativedelta", label: "Cumulative Delta", icon: <Database className="w-3 h-3" /> },
    ],
  },
];

// ─── Cloud icon (used by Ichimoku) ─────────────────────────────
function Cloud({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z" />
    </svg>
  );
}

// ─── IndicatorPanel Component ──────────────────────────────────
export default function IndicatorPanel({ open, onClose }: IndicatorPanelProps) {
  const panelRef = useRef<HTMLDivElement>(null);

  // Store-backed overlay values
  const storeState = useTradingStore((s) => s);
  const toggleOverlay = useTradingStore((s) => s.toggleOverlay);

  // Local state for indicators not in the store
  const [localActive, setLocalActive] = useState<Set<string>>(new Set());
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState("");

  // Track active indicator count for badge
  const activeCount = useMemo(() => {
    let count = 0;
    for (const cat of INDICATOR_CATEGORIES) {
      for (const ind of cat.indicators) {
        if (ind.storeKey) {
          if ((storeState as Record<string, boolean>)[ind.storeKey]) count++;
        } else {
          if (localActive.has(ind.id)) count++;
        }
      }
    }
    return count;
  }, [storeState, localActive]);

  // Close on click outside
  useEffect(() => {
    if (!open) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) {
        onClose();
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [open, onClose]);

  // Close on Escape
  useEffect(() => {
    if (!open) return;
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleEsc);
    return () => document.removeEventListener("keydown", handleEsc);
  }, [open, onClose]);

  // Toggle an indicator
  const handleToggle = useCallback(
    (item: IndicatorItem) => {
      if (item.storeKey) {
        toggleOverlay(item.storeKey);
      } else {
        setLocalActive((prev) => {
          const next = new Set(prev);
          if (next.has(item.id)) {
            next.delete(item.id);
          } else {
            next.add(item.id);
          }
          return next;
        });
      }
    },
    [toggleOverlay]
  );

  // Toggle a category collapsed state
  const toggleCategory = useCallback((categoryId: string) => {
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(categoryId)) {
        next.delete(categoryId);
      } else {
        next.add(categoryId);
      }
      return next;
    });
  }, []);

  // Check if an indicator is active
  const isActive = useCallback(
    (item: IndicatorItem) => {
      if (item.storeKey) {
        return (storeState as Record<string, boolean>)[item.storeKey] ?? false;
      }
      return localActive.has(item.id);
    },
    [storeState, localActive]
  );

  // Filter categories/indicators by search
  const filteredCategories = useMemo(() => {
    if (!searchQuery.trim()) return INDICATOR_CATEGORIES;
    const q = searchQuery.toLowerCase().trim();
    return INDICATOR_CATEGORIES.map((cat) => ({
      ...cat,
      indicators: cat.indicators.filter(
        (ind) =>
          ind.label.toLowerCase().includes(q) ||
          ind.id.toLowerCase().includes(q) ||
          cat.label.toLowerCase().includes(q)
      ),
    })).filter((cat) => cat.indicators.length > 0);
  }, [searchQuery]);

  if (!open) return null;

  return (
    <div
      ref={panelRef}
      className="absolute top-full left-0 mt-1 z-50 w-[320px] rounded-lg border border-[#1b2b3f] bg-[#0a121d] shadow-2xl shadow-black/60"
      style={{ animation: "fadeIn 0.15s ease-out" }}
    >
      {/* ── Header ── */}
      <div className="tpanel-header rounded-t-lg">
        <div className="flex items-center gap-2">
          <Activity className="w-3.5 h-3.5 text-[#59a0ff]" />
          <span className="text-[11px] font-semibold uppercase tracking-wider text-[#7489a1]">
            Indicators
          </span>
          <Badge
            variant="secondary"
            className="ml-1 h-4 px-1.5 text-[9px] font-bold bg-[rgba(89,160,255,0.15)] text-[#59a0ff] border-0"
          >
            {activeCount}
          </Badge>
        </div>
        <button
          onClick={onClose}
          className="p-0.5 rounded hover:bg-[#1b2b3f] transition-colors text-[#7489a1] hover:text-[#d8e0ea]"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* ── Search ── */}
      <div className="px-2 py-1.5 border-b border-[#1b2b3f]">
        <div className="relative">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-[#7489a1]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search indicators..."
            className="tinput pl-7 py-1.5 text-[11px]"
            autoFocus
          />
        </div>
      </div>

      {/* ── Categories ── */}
      <div className="max-h-[420px] overflow-y-auto tpanel-body p-0">
        {filteredCategories.map((cat) => {
          const isCollapsed = collapsed.has(cat.id);
          const catActiveCount = cat.indicators.filter((ind) => isActive(ind)).length;

          return (
            <div key={cat.id} className="border-b border-[#1b2b3f] last:border-b-0">
              {/* Category header */}
              <button
                onClick={() => toggleCategory(cat.id)}
                className="flex items-center justify-between w-full px-3 py-2 hover:bg-[rgba(89,160,255,0.04)] transition-colors group"
              >
                <div className="flex items-center gap-2">
                  {isCollapsed ? (
                    <ChevronRight className="w-3 h-3 text-[#7489a1] group-hover:text-[#d8e0ea] transition-colors" />
                  ) : (
                    <ChevronDown className="w-3 h-3 text-[#7489a1] group-hover:text-[#d8e0ea] transition-colors" />
                  )}
                  <span className="text-[11px]" style={{ color: cat.color }}>
                    {cat.icon}
                  </span>
                  <span className="text-[11px] font-semibold text-[#d8e0ea] uppercase tracking-wide">
                    {cat.label}
                  </span>
                </div>
                {catActiveCount > 0 && (
                  <span
                    className="text-[9px] font-bold rounded-full px-1.5 py-0.5"
                    style={{
                      background: `${cat.color}20`,
                      color: cat.color,
                    }}
                  >
                    {catActiveCount}
                  </span>
                )}
              </button>

              {/* Indicators grid */}
              {!isCollapsed && (
                <div className="px-2 pb-2 grid grid-cols-2 gap-1">
                  {cat.indicators.map((item) => {
                    const active = isActive(item);
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleToggle(item)}
                        className={cn(
                          "flex items-center gap-1.5 px-2 py-1.5 rounded-md border transition-all duration-150 text-left group/indicator",
                          active
                            ? "bg-[rgba(89,160,255,0.08)] border-[#2f68ad] shadow-sm"
                            : "bg-transparent border-transparent hover:bg-[rgba(255,255,255,0.02)] hover:border-[#1b2b3f]"
                        )}
                      >
                        <span
                          className={cn(
                            "flex-shrink-0 transition-colors",
                            active ? "text-[#59a0ff]" : "text-[#7489a1] group-hover/indicator:text-[#9eb3ca]"
                          )}
                        >
                          {item.icon}
                        </span>
                        <span
                          className={cn(
                            "text-[10px] font-medium flex-1 truncate transition-colors",
                            active ? "text-[#dfeeff]" : "text-[#9eb3ca]"
                          )}
                        >
                          {item.label}
                        </span>
                        {/* Mini toggle dot */}
                        <span
                          className={cn(
                            "w-1.5 h-1.5 rounded-full flex-shrink-0 transition-all",
                            active
                              ? "bg-[#59a0ff] shadow-[0_0_4px_rgba(89,160,255,0.5)]"
                              : "bg-[#1b2b3f] group-hover/indicator:bg-[#2a4060]"
                          )}
                        />
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}

        {/* Empty state */}
        {filteredCategories.length === 0 && (
          <div className="flex flex-col items-center justify-center py-8 text-[#7489a1]">
            <Search className="w-5 h-5 mb-2 opacity-40" />
            <span className="text-[11px]">No indicators found</span>
          </div>
        )}
      </div>

      {/* ── Footer ── */}
      <div className="flex items-center justify-between px-3 py-1.5 border-t border-[#1b2b3f] bg-[rgba(14,23,35,0.5)]">
        <span className="text-[9px] text-[#7489a1]">
          {activeCount} indicator{activeCount !== 1 ? "s" : ""} active
        </span>
        <button
          onClick={() => {
            // Turn off all local indicators
            setLocalActive(new Set());
            // Turn off all store indicators
            const storeKeys = [
              "showEma", "showRsi", "showBollinger", "showVwap",
              "showCVD", "showFootprint", "showHeatmap", "showTpo",
              "showVolumeBars",
            ];
            storeKeys.forEach((key) => {
              if ((storeState as Record<string, boolean>)[key]) {
                toggleOverlay(key);
              }
            });
          }}
          className="text-[9px] text-[#7489a1] hover:text-[#ff5f70] transition-colors"
        >
          Clear All
        </button>
      </div>
    </div>
  );
}
