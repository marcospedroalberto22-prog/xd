"use client";

import { useMemo } from "react";
import { useTradingStore } from "@/lib/trading-store";
import { computeTpoRows } from "@/lib/trading-utils";
import { formatPrice } from "@/lib/trading-utils";
import { Braces } from "lucide-react";

export default function TpoPanel() {
  const candles = useTradingStore((s) => s.candles);
  const showReplay = useTradingStore((s) => s.showReplay);
  const replayCursor = useTradingStore((s) => s.replayCursor);

  const visibleCandles = useMemo(() => {
    if (candles.length === 0) return [];
    if (showReplay) {
      const idx = Math.min(replayCursor, candles.length - 1);
      return candles.slice(Math.max(0, idx - 100), idx + 1);
    }
    return candles;
  }, [candles, showReplay, replayCursor]);

  const rows = useMemo(() => {
    return computeTpoRows(visibleCandles);
  }, [visibleCandles]);

  const maxTpo = useMemo(
    () => Math.max(...rows.map((r) => r.tpoCount), 1),
    [rows]
  );

  const pocRow = useMemo(() => {
    if (rows.length === 0) return null;
    return rows.reduce((max, r) => (r.tpoCount > max.tpoCount ? r : max), rows[0]);
  }, [rows]);

  // Generate time period labels (A = first 30min, B = second 30min, etc.)
  const timePeriods = useMemo(() => {
    const periods: string[] = [];
    for (let i = 0; i < 13; i++) {
      periods.push(String.fromCharCode(65 + i)); // A-M
    }
    return periods;
  }, []);

  if (rows.length === 0) {
    return (
      <div className="tpanel h-full">
        <div className="tpanel-header">
          <span>TPO PROFILE</span>
        </div>
        <div className="tpanel-body flex items-center justify-center h-32 text-[#7489a1] text-xs">
          No data
        </div>
      </div>
    );
  }

  return (
    <div className="tpanel h-full flex flex-col">
      <div className="tpanel-header">
        <div className="flex items-center gap-2">
          <Braces size={12} className="text-[#59a0ff]" />
          <span>TPO PROFILE</span>
        </div>
        <div className="flex items-center gap-3 text-[10px]">
          {pocRow && (
            <span className="text-[#59a0ff]">POC {formatPrice(pocRow.price)} ({pocRow.tpoCount}x)</span>
          )}
          <span className="text-[#7489a1]">{rows.length} levels</span>
        </div>
      </div>

      <div className="tpanel-body flex-1 p-0">
        {/* Time period header */}
        <div className="flex items-center px-2 py-1 text-[9px] uppercase tracking-wider text-[#7489a1] border-b border-[#1b2b3f]/50">
          <div className="w-[72px] text-right pr-2">Price</div>
          <div className="flex-1 text-center">
            <div className="flex justify-center gap-[3px]">
              {timePeriods.map((p) => (
                <span key={p} className="w-[14px] text-center">{p}</span>
              ))}
            </div>
          </div>
          <div className="w-[28px] text-center">Cnt</div>
        </div>

        {rows.map((row, i) => {
          const isPoc = pocRow && row.price === pocRow.price;
          const letters = row.letters.split("");

          return (
            <div
              key={i}
              className={`
                flex items-center px-2 text-[11px] mono border-b border-[#1b2b3f]/20
                ${isPoc ? "bg-[#59a0ff]/8" : ""}
                hover:bg-[#142031]/50 transition-colors
              `}
            >
              {/* Price label */}
              <div className={`w-[72px] text-right pr-2 font-medium ${isPoc ? "text-[#59a0ff]" : "text-[#d8e0ea]"}`}>
                {formatPrice(row.price)}
              </div>

              {/* TPO letters */}
              <div className="flex-1 flex justify-center gap-[1px] py-[1px]">
                {timePeriods.map((period) => {
                  const active = letters.includes(period);
                  // Color letters based on time progression
                  const idx = period.charCodeAt(0) - 65;
                  const hue = 160 + idx * 12; // Green to blue range
                  return (
                    <span
                      key={period}
                      className={`
                        w-[14px] h-[16px] rounded-[2px] text-center text-[9px] font-semibold leading-[16px]
                        ${active ? "text-white" : "text-transparent"}
                      `}
                      style={{
                        backgroundColor: active
                          ? isPoc
                            ? `hsla(215, 85%, 52%, 0.4)`
                            : `hsla(${hue}, 60%, 45%, 0.3)`
                          : "transparent",
                        border: active
                          ? `1px solid ${isPoc ? "rgba(89, 160, 255, 0.3)" : `hsla(${hue}, 60%, 55%, 0.2)`}`
                          : "1px solid transparent",
                      }}
                    >
                      {period}
                    </span>
                  );
                })}
              </div>

              {/* Count */}
              <div className={`w-[28px] text-center text-[10px] ${isPoc ? "text-[#59a0ff] font-semibold" : "text-[#7489a1]"}`}>
                {row.tpoCount}
              </div>
            </div>
          );
        })}

        {/* Legend */}
        <div className="flex items-center gap-4 px-2 py-2 text-[9px] text-[#7489a1] border-t border-[#1b2b3f]/50 mt-auto">
          <span className="flex items-center gap-1">
            <Braces size={9} className="text-[#59a0ff]" />
            Each letter = 30min time period traded
          </span>
          <span className="flex items-center gap-1">
            <span className="inline-block w-2.5 h-2.5 rounded-sm bg-[#59a0ff]/40" />
            POC
          </span>
        </div>
      </div>
    </div>
  );
}
